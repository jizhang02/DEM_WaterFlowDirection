﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Collections;
using System.IO;
using System.Drawing ;
using System.ComponentModel;
using System.Data;
using System.Windows.Forms;
//增加文本框显示读取和写入文件位置的最近20条记录
namespace LengthSlope
{
    class AddCustomPath
    {
        ArrayList arrlist_inputfilename = new ArrayList();
        ArrayList arrlist_outputpath = new ArrayList();
        private int recordlength;
        //构造函数,用于读取文件里存储的路径；
        public  AddCustomPath(int set_Recordlength)
        {
            StreamReader sr1 = new StreamReader("recentopenfile.txt");
            string inputfilename="";
            inputfilename = sr1.ReadLine();
            while (inputfilename != null)
            {
                arrlist_inputfilename.Add(inputfilename);
                inputfilename = sr1.ReadLine(); 
            }

            StreamReader sr2 = new StreamReader("recentsavepath.txt");
            string outputpath = "";
            outputpath = sr2.ReadLine();
            while (outputpath != null)
            {
                arrlist_outputpath.Add(outputpath);
                outputpath = sr2.ReadLine();
            }
            sr1.Close();
            sr2.Close();
            recordlength = set_Recordlength;
        }
        public void addInputfilename(ref TextBox txbInput)
        {
            int inputfilenamelength = arrlist_inputfilename.Count;
            int i;
            txbInput.AutoCompleteCustomSource.Clear();
            for (i = 0; i < inputfilenamelength; i++)
            {
                    txbInput.AutoCompleteCustomSource.Add(arrlist_inputfilename[i].ToString());
             }
            
        }
        public void addInputfilename(string inputfilename,ref TextBox txbInput)
        {
           int inputfilenamelength =arrlist_inputfilename.Count;
           int i;
           for (i = 0; i < inputfilenamelength; i++)
           {
               if (inputfilename.Trim()==null || inputfilename == arrlist_inputfilename[i].ToString())
                   return;              
           }

           if (inputfilenamelength < recordlength)
           {
               arrlist_inputfilename.Add(inputfilename);
               txbInput.AutoCompleteCustomSource.Add(inputfilename);
           }
           else
           {               
               txbInput.AutoCompleteCustomSource.Clear();
               for (i = 0; i < inputfilenamelength - 1; i++)
               {
                   arrlist_inputfilename[i] = arrlist_inputfilename[i + 1];
                   txbInput.AutoCompleteCustomSource.Add(arrlist_inputfilename[i].ToString());
               }
               arrlist_inputfilename[i] = inputfilename;
               txbInput.AutoCompleteCustomSource.Add(arrlist_inputfilename[i].ToString());
           }
           
        }
        public void addOutputpath(ref TextBox txbOutput)
        {
            int Outputpathlength = arrlist_outputpath.Count;
               int i;
                txbOutput.AutoCompleteCustomSource.Clear();
                for (i = 0; i < Outputpathlength; i++)
                {
                   txbOutput.AutoCompleteCustomSource.Add(arrlist_outputpath[i].ToString());
                }              
        }
        
        public void addOutputpath(string outputpath, ref TextBox txbOutput)
        {
            int Outputpathlength = arrlist_outputpath.Count;
            int i;
            for (i = 0; i < Outputpathlength; i++)
            {
                if (outputpath.Trim()==null || outputpath == arrlist_outputpath[i].ToString())
                    return;
            }
            
            if (Outputpathlength < recordlength)
            {
                arrlist_outputpath.Add(outputpath);
                txbOutput.AutoCompleteCustomSource.Add(outputpath);
            }
            else
            {
                
                txbOutput.AutoCompleteCustomSource.Clear();
                for (i = 0; i < Outputpathlength - 1; i++)
                {
                    arrlist_outputpath[i] = arrlist_outputpath[i + 1];
                    txbOutput.AutoCompleteCustomSource.Add(arrlist_outputpath[i].ToString());
                }
                arrlist_outputpath[i] = outputpath;
                txbOutput.AutoCompleteCustomSource.Add(arrlist_outputpath[i].ToString());
            }
        }
        public void savefilerecord()
        {
            StreamWriter sw1 = new StreamWriter("recentopenfile.txt");
            StreamWriter sw2 = new StreamWriter("recentsavepath.txt");
            int i;
            int inputfilenamelength = arrlist_inputfilename.Count;
            int Outputpathlength = arrlist_outputpath.Count;
            for (i = 0; i < inputfilenamelength ; i++)
            {
                sw1.WriteLine(arrlist_inputfilename[i]);
            }
            for (i = 0; i < Outputpathlength ; i++)
            {
                sw2.WriteLine(arrlist_outputpath[i]);
            }
            sw1.Close();
            sw2.Close();
        }

    }
}
