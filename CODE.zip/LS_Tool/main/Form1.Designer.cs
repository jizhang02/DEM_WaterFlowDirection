﻿using System.Windows.Forms;

namespace LengthSlope
{
    partial class Form1
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.button_inputpath = new System.Windows.Forms.Button();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.groupBox_inputpath = new System.Windows.Forms.GroupBox();
            this.radioButton3 = new System.Windows.Forms.RadioButton();
            this.radioButton1 = new System.Windows.Forms.RadioButton();
            this.textBox_inputpath = new System.Windows.Forms.TextBox();
            this.button_cancel = new System.Windows.Forms.Button();
            this.button_start = new System.Windows.Forms.Button();
            this.groupBox_nodata_repair = new System.Windows.Forms.GroupBox();
            this.radioButton_nodata_repair_yes = new System.Windows.Forms.RadioButton();
            this.radioButton_nodata_repair_no = new System.Windows.Forms.RadioButton();
            this.groupBox_cutoff_set = new System.Windows.Forms.GroupBox();
            this.textBox_cutoff_slopegreat = new System.Windows.Forms.TextBox();
            this.textBox_cutoff_slopeless = new System.Windows.Forms.TextBox();
            this.label_cutoff_slopegreat = new System.Windows.Forms.Label();
            this.label_cutoff_slopeless = new System.Windows.Forms.Label();
            this.groupBox_profix = new System.Windows.Forms.GroupBox();
            this.label_profix = new System.Windows.Forms.Label();
            this.textBox_profix = new System.Windows.Forms.TextBox();
            this.groupBox_nodata_fill = new System.Windows.Forms.GroupBox();
            this.radioButton_fill_aver = new System.Windows.Forms.RadioButton();
            this.radioButton_fill_min = new System.Windows.Forms.RadioButton();
            this.groupBox_outputpath = new System.Windows.Forms.GroupBox();
            this.textBox_outputpath = new System.Windows.Forms.TextBox();
            this.button_outputpath = new System.Windows.Forms.Button();
            this.groupBox_channelcutoff = new System.Windows.Forms.GroupBox();
            this.radioButton_channel_no = new System.Windows.Forms.RadioButton();
            this.radioButton_channel_yes = new System.Windows.Forms.RadioButton();
            this.Timer_Before_Closed = new System.Windows.Forms.Timer(this.components);
            this.Timer_Cancel_Close = new System.Windows.Forms.Timer(this.components);
            this.Timer_Close = new System.Windows.Forms.Timer(this.components);
            this.groupBox_flowdir_select = new System.Windows.Forms.GroupBox();
            this.radioButton_flowdir_mul = new System.Windows.Forms.RadioButton();
            this.radioButton_flowdir_sgn = new System.Windows.Forms.RadioButton();
            this.groupBox_flowdirmul_select = new System.Windows.Forms.GroupBox();
            this.radioButton_Mul_Dinf = new System.Windows.Forms.RadioButton();
            this.radioButton_Mul_DEMON = new System.Windows.Forms.RadioButton();
            this.radioButton_Mul_FMFD = new System.Windows.Forms.RadioButton();
            this.radioButton_Mul_MS = new System.Windows.Forms.RadioButton();
            this.groupBox_flowdirsgn_select = new System.Windows.Forms.GroupBox();
            this.radioButton_Sgn_Rho = new System.Windows.Forms.RadioButton();
            this.radioButton_Sgn_Rho8 = new System.Windows.Forms.RadioButton();
            this.radioButton_Sgn_Rho4 = new System.Windows.Forms.RadioButton();
            this.radioButton_Sgn_D8 = new System.Windows.Forms.RadioButton();
            this.button_helpInfo = new System.Windows.Forms.Button();
            this.textBox_helpinfo = new System.Windows.Forms.TextBox();
            this.groupBox10 = new System.Windows.Forms.GroupBox();
            this.label_slope_exp = new System.Windows.Forms.Label();
            this.groupbox_slope_exp = new System.Windows.Forms.GroupBox();
            this.textBox_slope_exp = new System.Windows.Forms.TextBox();
            this.groupBox_cutoff = new System.Windows.Forms.GroupBox();
            this.radioButton_cutoff_yes = new System.Windows.Forms.RadioButton();
            this.radioButton_cutoff_no = new System.Windows.Forms.RadioButton();
            this.groupBox_sink_fill = new System.Windows.Forms.GroupBox();
            this.radioButton_sinkfill_yes = new System.Windows.Forms.RadioButton();
            this.radioButton_sinkfill_no = new System.Windows.Forms.RadioButton();
            this.groupBox_threshold = new System.Windows.Forms.GroupBox();
            this.label_threshold = new System.Windows.Forms.Label();
            this.textBox_threshold = new System.Windows.Forms.TextBox();
            this.button_language = new System.Windows.Forms.Button();
            this.radioButton2 = new System.Windows.Forms.RadioButton();
            this.checkBox_Save_SlopLength = new System.Windows.Forms.CheckBox();
            this.checkBox_Save_SlopAngle = new System.Windows.Forms.CheckBox();
            this.checkBox_Save_LengthFactor = new System.Windows.Forms.CheckBox();
            this.checkBox_Save_SlopFactor = new System.Windows.Forms.CheckBox();
            this.checkBox_Save_LSFactor = new System.Windows.Forms.CheckBox();
            this.checkBox_Save_SelectAll = new System.Windows.Forms.CheckBox();
            this.groupBox_save = new System.Windows.Forms.GroupBox();
            this.groupBox_Cumulated_Way = new System.Windows.Forms.GroupBox();
            this.radioButton_Cumulated_Total = new System.Windows.Forms.RadioButton();
            this.radioButton_Cumulated_Max = new System.Windows.Forms.RadioButton();
            this.groupBox_modeling = new System.Windows.Forms.GroupBox();
            this.radioButton_model_CSLE = new System.Windows.Forms.RadioButton();
            this.radioButton_model_RUSLE = new System.Windows.Forms.RadioButton();
            this.contextMenuStrip1.SuspendLayout();
            this.groupBox_inputpath.SuspendLayout();
            this.groupBox_nodata_repair.SuspendLayout();
            this.groupBox_cutoff_set.SuspendLayout();
            this.groupBox_profix.SuspendLayout();
            this.groupBox_nodata_fill.SuspendLayout();
            this.groupBox_outputpath.SuspendLayout();
            this.groupBox_channelcutoff.SuspendLayout();
            this.groupBox_flowdir_select.SuspendLayout();
            this.groupBox_flowdirmul_select.SuspendLayout();
            this.groupBox_flowdirsgn_select.SuspendLayout();
            this.groupBox10.SuspendLayout();
            this.groupbox_slope_exp.SuspendLayout();
            this.groupBox_cutoff.SuspendLayout();
            this.groupBox_sink_fill.SuspendLayout();
            this.groupBox_threshold.SuspendLayout();
            this.groupBox_save.SuspendLayout();
            this.groupBox_Cumulated_Way.SuspendLayout();
            this.groupBox_modeling.SuspendLayout();
            this.SuspendLayout();
            // 
            // button_inputpath
            // 
            this.button_inputpath.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button_inputpath.ContextMenuStrip = this.contextMenuStrip1;
            this.button_inputpath.Location = new System.Drawing.Point(372, 33);
            this.button_inputpath.Name = "button_inputpath";
            this.button_inputpath.Size = new System.Drawing.Size(112, 23);
            this.button_inputpath.TabIndex = 0;
            this.button_inputpath.Text = "DEM路径及文件名";
            this.button_inputpath.UseVisualStyleBackColor = true;
            this.button_inputpath.Click += new System.EventHandler(this.button1_Click);
            this.button_inputpath.MouseHover += new System.EventHandler(this.button1_MouseHover);
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ToolStripMenuItem});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(137, 26);
            this.contextMenuStrip1.Text = "这是什么？";
            // 
            // ToolStripMenuItem
            // 
            this.ToolStripMenuItem.Image = global::aaaaaaa.Properties.Resources.Help_Blue_Button;
            this.ToolStripMenuItem.Name = "ToolStripMenuItem";
            this.ToolStripMenuItem.Size = new System.Drawing.Size(136, 22);
            this.ToolStripMenuItem.Text = "这是什么？";
            this.ToolStripMenuItem.Click += new System.EventHandler(this.ToolStripMenuItem_Click);
            // 
            // groupBox_inputpath
            // 
            this.groupBox_inputpath.ContextMenuStrip = this.contextMenuStrip1;
            this.groupBox_inputpath.Controls.Add(this.radioButton3);
            this.groupBox_inputpath.Controls.Add(this.radioButton1);
            this.groupBox_inputpath.Controls.Add(this.textBox_inputpath);
            this.groupBox_inputpath.Controls.Add(this.button_inputpath);
            this.groupBox_inputpath.Location = new System.Drawing.Point(15, 3);
            this.groupBox_inputpath.Name = "groupBox_inputpath";
            this.groupBox_inputpath.Size = new System.Drawing.Size(516, 62);
            this.groupBox_inputpath.TabIndex = 2;
            this.groupBox_inputpath.TabStop = false;
            this.groupBox_inputpath.Text = "源文件位置";
            this.groupBox_inputpath.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // radioButton3
            // 
            this.radioButton3.AutoSize = true;
            this.radioButton3.Location = new System.Drawing.Point(236, 14);
            this.radioButton3.Name = "radioButton3";
            this.radioButton3.Size = new System.Drawing.Size(101, 16);
            this.radioButton3.TabIndex = 5;
            this.radioButton3.Text = "投影坐标（m）";
            this.radioButton3.UseVisualStyleBackColor = true;
            // 
            // radioButton1
            // 
            this.radioButton1.AutoSize = true;
            this.radioButton1.Checked = true;
            this.radioButton1.Location = new System.Drawing.Point(76, 14);
            this.radioButton1.Name = "radioButton1";
            this.radioButton1.Size = new System.Drawing.Size(107, 16);
            this.radioButton1.TabIndex = 4;
            this.radioButton1.TabStop = true;
            this.radioButton1.Text = "地理坐标（°）";
            this.radioButton1.UseVisualStyleBackColor = true;
            // 
            // textBox_inputpath
            // 
            this.textBox_inputpath.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.textBox_inputpath.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.textBox_inputpath.ContextMenuStrip = this.contextMenuStrip1;
            this.textBox_inputpath.Location = new System.Drawing.Point(9, 36);
            this.textBox_inputpath.Name = "textBox_inputpath";
            this.textBox_inputpath.Size = new System.Drawing.Size(339, 21);
            this.textBox_inputpath.TabIndex = 3;
            this.textBox_inputpath.Click += new System.EventHandler(this.radioButton_Sgn_D8_Click);
            this.textBox_inputpath.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            this.textBox_inputpath.MouseHover += new System.EventHandler(this.textBox1_MouseHover);
            // 
            // button_cancel
            // 
            this.button_cancel.ContextMenuStrip = this.contextMenuStrip1;
            this.button_cancel.Location = new System.Drawing.Point(303, 435);
            this.button_cancel.Name = "button_cancel";
            this.button_cancel.Size = new System.Drawing.Size(104, 23);
            this.button_cancel.TabIndex = 5;
            this.button_cancel.Text = "退出(&X)";
            this.button_cancel.UseVisualStyleBackColor = true;
            this.button_cancel.Click += new System.EventHandler(this.button4_Click);
            // 
            // button_start
            // 
            this.button_start.ContextMenuStrip = this.contextMenuStrip1;
            this.button_start.Enabled = false;
            this.button_start.Location = new System.Drawing.Point(170, 435);
            this.button_start.Name = "button_start";
            this.button_start.Size = new System.Drawing.Size(104, 23);
            this.button_start.TabIndex = 3;
            this.button_start.Text = "开始计算(&C)";
            this.button_start.UseVisualStyleBackColor = true;
            this.button_start.Click += new System.EventHandler(this.button3_Click);
            // 
            // groupBox_nodata_repair
            // 
            this.groupBox_nodata_repair.ContextMenuStrip = this.contextMenuStrip1;
            this.groupBox_nodata_repair.Controls.Add(this.radioButton_nodata_repair_yes);
            this.groupBox_nodata_repair.Controls.Add(this.radioButton_nodata_repair_no);
            this.groupBox_nodata_repair.Location = new System.Drawing.Point(15, 214);
            this.groupBox_nodata_repair.Name = "groupBox_nodata_repair";
            this.groupBox_nodata_repair.Size = new System.Drawing.Size(82, 77);
            this.groupBox_nodata_repair.TabIndex = 7;
            this.groupBox_nodata_repair.TabStop = false;
            this.groupBox_nodata_repair.Text = "无值点";
            this.groupBox_nodata_repair.MouseHover += new System.EventHandler(this.groupBox_nodata_repair_MouseHover);
            // 
            // radioButton_nodata_repair_yes
            // 
            this.radioButton_nodata_repair_yes.AutoSize = true;
            this.radioButton_nodata_repair_yes.Checked = true;
            this.radioButton_nodata_repair_yes.ContextMenuStrip = this.contextMenuStrip1;
            this.radioButton_nodata_repair_yes.Location = new System.Drawing.Point(9, 24);
            this.radioButton_nodata_repair_yes.Name = "radioButton_nodata_repair_yes";
            this.radioButton_nodata_repair_yes.Size = new System.Drawing.Size(47, 16);
            this.radioButton_nodata_repair_yes.TabIndex = 12;
            this.radioButton_nodata_repair_yes.TabStop = true;
            this.radioButton_nodata_repair_yes.Text = "修复";
            this.radioButton_nodata_repair_yes.UseVisualStyleBackColor = true;
            this.radioButton_nodata_repair_yes.CheckedChanged += new System.EventHandler(this.radioButton_nodata_repair_no_CheckedChanged);
            this.radioButton_nodata_repair_yes.Click += new System.EventHandler(this.radioButton_Sgn_D8_Click);
            this.radioButton_nodata_repair_yes.MouseHover += new System.EventHandler(this.groupBox_nodata_repair_MouseHover);
            // 
            // radioButton_nodata_repair_no
            // 
            this.radioButton_nodata_repair_no.AutoSize = true;
            this.radioButton_nodata_repair_no.ContextMenuStrip = this.contextMenuStrip1;
            this.radioButton_nodata_repair_no.Location = new System.Drawing.Point(9, 48);
            this.radioButton_nodata_repair_no.Name = "radioButton_nodata_repair_no";
            this.radioButton_nodata_repair_no.Size = new System.Drawing.Size(59, 16);
            this.radioButton_nodata_repair_no.TabIndex = 2;
            this.radioButton_nodata_repair_no.TabStop = true;
            this.radioButton_nodata_repair_no.Text = "不修复";
            this.radioButton_nodata_repair_no.UseVisualStyleBackColor = true;
            this.radioButton_nodata_repair_no.CheckedChanged += new System.EventHandler(this.radioButton_nodata_repair_no_CheckedChanged);
            this.radioButton_nodata_repair_no.Click += new System.EventHandler(this.radioButton_Sgn_D8_Click);
            this.radioButton_nodata_repair_no.MouseHover += new System.EventHandler(this.groupBox_nodata_repair_MouseHover);
            // 
            // groupBox_cutoff_set
            // 
            this.groupBox_cutoff_set.ContextMenuStrip = this.contextMenuStrip1;
            this.groupBox_cutoff_set.Controls.Add(this.textBox_cutoff_slopegreat);
            this.groupBox_cutoff_set.Controls.Add(this.textBox_cutoff_slopeless);
            this.groupBox_cutoff_set.Controls.Add(this.label_cutoff_slopegreat);
            this.groupBox_cutoff_set.Controls.Add(this.label_cutoff_slopeless);
            this.groupBox_cutoff_set.Location = new System.Drawing.Point(7, 302);
            this.groupBox_cutoff_set.Name = "groupBox_cutoff_set";
            this.groupBox_cutoff_set.Size = new System.Drawing.Size(144, 116);
            this.groupBox_cutoff_set.TabIndex = 8;
            this.groupBox_cutoff_set.TabStop = false;
            this.groupBox_cutoff_set.Text = "截断因子设置";
            // 
            // textBox_cutoff_slopegreat
            // 
            this.textBox_cutoff_slopegreat.ContextMenuStrip = this.contextMenuStrip1;
            this.textBox_cutoff_slopegreat.Location = new System.Drawing.Point(16, 79);
            this.textBox_cutoff_slopegreat.Name = "textBox_cutoff_slopegreat";
            this.textBox_cutoff_slopegreat.Size = new System.Drawing.Size(76, 21);
            this.textBox_cutoff_slopegreat.TabIndex = 7;
            this.textBox_cutoff_slopegreat.Text = "0.5";
            this.textBox_cutoff_slopegreat.Click += new System.EventHandler(this.radioButton_Sgn_D8_Click);
            this.textBox_cutoff_slopegreat.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox4_KeyPress);
            this.textBox_cutoff_slopegreat.MouseHover += new System.EventHandler(this.textBox3_MouseHover);
            // 
            // textBox_cutoff_slopeless
            // 
            this.textBox_cutoff_slopeless.ContextMenuStrip = this.contextMenuStrip1;
            this.textBox_cutoff_slopeless.Location = new System.Drawing.Point(16, 38);
            this.textBox_cutoff_slopeless.Name = "textBox_cutoff_slopeless";
            this.textBox_cutoff_slopeless.Size = new System.Drawing.Size(76, 21);
            this.textBox_cutoff_slopeless.TabIndex = 6;
            this.textBox_cutoff_slopeless.Text = "0.7";
            this.textBox_cutoff_slopeless.Click += new System.EventHandler(this.radioButton_Sgn_D8_Click);
            this.textBox_cutoff_slopeless.TextChanged += new System.EventHandler(this.textBox3_TextChanged);
            this.textBox_cutoff_slopeless.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox3_KeyPress);
            this.textBox_cutoff_slopeless.MouseHover += new System.EventHandler(this.textBox3_MouseHover);
            // 
            // label_cutoff_slopegreat
            // 
            this.label_cutoff_slopegreat.AutoSize = true;
            this.label_cutoff_slopegreat.ContextMenuStrip = this.contextMenuStrip1;
            this.label_cutoff_slopegreat.Location = new System.Drawing.Point(14, 63);
            this.label_cutoff_slopegreat.Name = "label_cutoff_slopegreat";
            this.label_cutoff_slopegreat.Size = new System.Drawing.Size(125, 12);
            this.label_cutoff_slopegreat.TabIndex = 1;
            this.label_cutoff_slopegreat.Text = "坡度 ≥ 2.75°（5%）";
            // 
            // label_cutoff_slopeless
            // 
            this.label_cutoff_slopeless.AutoSize = true;
            this.label_cutoff_slopeless.ContextMenuStrip = this.contextMenuStrip1;
            this.label_cutoff_slopeless.Location = new System.Drawing.Point(14, 21);
            this.label_cutoff_slopeless.Name = "label_cutoff_slopeless";
            this.label_cutoff_slopeless.Size = new System.Drawing.Size(119, 12);
            this.label_cutoff_slopeless.TabIndex = 0;
            this.label_cutoff_slopeless.Text = "坡度 < 2.75°（5%）";
            // 
            // groupBox_profix
            // 
            this.groupBox_profix.ContextMenuStrip = this.contextMenuStrip1;
            this.groupBox_profix.Controls.Add(this.label_profix);
            this.groupBox_profix.Controls.Add(this.textBox_profix);
            this.groupBox_profix.Location = new System.Drawing.Point(15, 127);
            this.groupBox_profix.Name = "groupBox_profix";
            this.groupBox_profix.Size = new System.Drawing.Size(84, 81);
            this.groupBox_profix.TabIndex = 10;
            this.groupBox_profix.TabStop = false;
            this.groupBox_profix.Text = "设置前缀";
            // 
            // label_profix
            // 
            this.label_profix.AutoSize = true;
            this.label_profix.ContextMenuStrip = this.contextMenuStrip1;
            this.label_profix.Location = new System.Drawing.Point(4, 23);
            this.label_profix.Name = "label_profix";
            this.label_profix.Size = new System.Drawing.Size(53, 12);
            this.label_profix.TabIndex = 1;
            this.label_profix.Text = "文件前缀";
            this.label_profix.Click += new System.EventHandler(this.label3_Click);
            // 
            // textBox_profix
            // 
            this.textBox_profix.ContextMenuStrip = this.contextMenuStrip1;
            this.textBox_profix.Location = new System.Drawing.Point(6, 44);
            this.textBox_profix.Name = "textBox_profix";
            this.textBox_profix.Size = new System.Drawing.Size(71, 21);
            this.textBox_profix.TabIndex = 0;
            this.textBox_profix.Text = "LS";
            this.textBox_profix.Click += new System.EventHandler(this.radioButton_Sgn_D8_Click);
            this.textBox_profix.MouseHover += new System.EventHandler(this.textBox5_MouseHover);
            // 
            // groupBox_nodata_fill
            // 
            this.groupBox_nodata_fill.ContextMenuStrip = this.contextMenuStrip1;
            this.groupBox_nodata_fill.Controls.Add(this.radioButton_fill_aver);
            this.groupBox_nodata_fill.Controls.Add(this.radioButton_fill_min);
            this.groupBox_nodata_fill.Location = new System.Drawing.Point(111, 215);
            this.groupBox_nodata_fill.Name = "groupBox_nodata_fill";
            this.groupBox_nodata_fill.Size = new System.Drawing.Size(94, 77);
            this.groupBox_nodata_fill.TabIndex = 11;
            this.groupBox_nodata_fill.TabStop = false;
            this.groupBox_nodata_fill.Text = "无值点填充";
            this.groupBox_nodata_fill.MouseHover += new System.EventHandler(this.groupBox_nodata_fill_MouseHover);
            // 
            // radioButton_fill_aver
            // 
            this.radioButton_fill_aver.AutoSize = true;
            this.radioButton_fill_aver.ContextMenuStrip = this.contextMenuStrip1;
            this.radioButton_fill_aver.Location = new System.Drawing.Point(16, 24);
            this.radioButton_fill_aver.Name = "radioButton_fill_aver";
            this.radioButton_fill_aver.Size = new System.Drawing.Size(59, 16);
            this.radioButton_fill_aver.TabIndex = 1;
            this.radioButton_fill_aver.Text = "平均值";
            this.radioButton_fill_aver.UseVisualStyleBackColor = true;
            this.radioButton_fill_aver.Click += new System.EventHandler(this.radioButton_Sgn_D8_Click);
            this.radioButton_fill_aver.MouseHover += new System.EventHandler(this.groupBox_nodata_repair_MouseHover);
            // 
            // radioButton_fill_min
            // 
            this.radioButton_fill_min.AutoSize = true;
            this.radioButton_fill_min.Checked = true;
            this.radioButton_fill_min.ContextMenuStrip = this.contextMenuStrip1;
            this.radioButton_fill_min.Location = new System.Drawing.Point(16, 47);
            this.radioButton_fill_min.Name = "radioButton_fill_min";
            this.radioButton_fill_min.Size = new System.Drawing.Size(59, 16);
            this.radioButton_fill_min.TabIndex = 0;
            this.radioButton_fill_min.TabStop = true;
            this.radioButton_fill_min.Text = "最小值";
            this.radioButton_fill_min.UseVisualStyleBackColor = true;
            this.radioButton_fill_min.Click += new System.EventHandler(this.radioButton_Sgn_D8_Click);
            this.radioButton_fill_min.MouseHover += new System.EventHandler(this.groupBox_nodata_repair_MouseHover);
            // 
            // groupBox_outputpath
            // 
            this.groupBox_outputpath.ContextMenuStrip = this.contextMenuStrip1;
            this.groupBox_outputpath.Controls.Add(this.textBox_outputpath);
            this.groupBox_outputpath.Controls.Add(this.button_outputpath);
            this.groupBox_outputpath.Location = new System.Drawing.Point(15, 71);
            this.groupBox_outputpath.Name = "groupBox_outputpath";
            this.groupBox_outputpath.Size = new System.Drawing.Size(516, 50);
            this.groupBox_outputpath.TabIndex = 13;
            this.groupBox_outputpath.TabStop = false;
            this.groupBox_outputpath.Text = "输出文件位置";
            // 
            // textBox_outputpath
            // 
            this.textBox_outputpath.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textBox_outputpath.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.textBox_outputpath.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.textBox_outputpath.ContextMenuStrip = this.contextMenuStrip1;
            this.textBox_outputpath.Location = new System.Drawing.Point(9, 20);
            this.textBox_outputpath.Name = "textBox_outputpath";
            this.textBox_outputpath.Size = new System.Drawing.Size(339, 21);
            this.textBox_outputpath.TabIndex = 6;
            this.textBox_outputpath.Click += new System.EventHandler(this.radioButton_Sgn_D8_Click);
            this.textBox_outputpath.MouseHover += new System.EventHandler(this.textBox2_MouseHover);
            // 
            // button_outputpath
            // 
            this.button_outputpath.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.button_outputpath.ContextMenuStrip = this.contextMenuStrip1;
            this.button_outputpath.Location = new System.Drawing.Point(370, 18);
            this.button_outputpath.Name = "button_outputpath";
            this.button_outputpath.Size = new System.Drawing.Size(116, 23);
            this.button_outputpath.TabIndex = 5;
            this.button_outputpath.Text = "结果保存位置";
            this.button_outputpath.UseVisualStyleBackColor = true;
            this.button_outputpath.Click += new System.EventHandler(this.button2_Click);
            this.button_outputpath.MouseHover += new System.EventHandler(this.button2_MouseHover);
            // 
            // groupBox_channelcutoff
            // 
            this.groupBox_channelcutoff.ContextMenuStrip = this.contextMenuStrip1;
            this.groupBox_channelcutoff.Controls.Add(this.radioButton_channel_no);
            this.groupBox_channelcutoff.Controls.Add(this.radioButton_channel_yes);
            this.groupBox_channelcutoff.Location = new System.Drawing.Point(214, 215);
            this.groupBox_channelcutoff.Name = "groupBox_channelcutoff";
            this.groupBox_channelcutoff.Size = new System.Drawing.Size(84, 77);
            this.groupBox_channelcutoff.TabIndex = 14;
            this.groupBox_channelcutoff.TabStop = false;
            this.groupBox_channelcutoff.Text = "沟道截断";
            this.groupBox_channelcutoff.MouseHover += new System.EventHandler(this.groupBox_accuway_MouseHover);
            // 
            // radioButton_channel_no
            // 
            this.radioButton_channel_no.AutoSize = true;
            this.radioButton_channel_no.Location = new System.Drawing.Point(17, 48);
            this.radioButton_channel_no.Name = "radioButton_channel_no";
            this.radioButton_channel_no.Size = new System.Drawing.Size(35, 16);
            this.radioButton_channel_no.TabIndex = 1;
            this.radioButton_channel_no.Text = "否";
            this.radioButton_channel_no.UseVisualStyleBackColor = true;
            this.radioButton_channel_no.CheckedChanged += new System.EventHandler(this.radioButton_channel_yes_CheckedChanged);
            this.radioButton_channel_no.Click += new System.EventHandler(this.radioButton_Sgn_D8_Click);
            this.radioButton_channel_no.MouseHover += new System.EventHandler(this.groupBox_accuway_MouseHover);
            // 
            // radioButton_channel_yes
            // 
            this.radioButton_channel_yes.AutoSize = true;
            this.radioButton_channel_yes.Checked = true;
            this.radioButton_channel_yes.Location = new System.Drawing.Point(17, 26);
            this.radioButton_channel_yes.Name = "radioButton_channel_yes";
            this.radioButton_channel_yes.Size = new System.Drawing.Size(35, 16);
            this.radioButton_channel_yes.TabIndex = 0;
            this.radioButton_channel_yes.TabStop = true;
            this.radioButton_channel_yes.Text = "是";
            this.radioButton_channel_yes.UseVisualStyleBackColor = true;
            this.radioButton_channel_yes.CheckedChanged += new System.EventHandler(this.radioButton_channel_yes_CheckedChanged);
            this.radioButton_channel_yes.Click += new System.EventHandler(this.radioButton_Sgn_D8_Click);
            this.radioButton_channel_yes.MouseHover += new System.EventHandler(this.groupBox_accuway_MouseHover);
            // 
            // Timer_Before_Closed
            // 
            this.Timer_Before_Closed.Interval = 5;
            this.Timer_Before_Closed.Tick += new System.EventHandler(this.Timer_Before_Closed_Tick);
            // 
            // Timer_Cancel_Close
            // 
            this.Timer_Cancel_Close.Interval = 5;
            this.Timer_Cancel_Close.Tick += new System.EventHandler(this.Timer_Cancel_Close_Tick);
            // 
            // Timer_Close
            // 
            this.Timer_Close.Interval = 20;
            this.Timer_Close.Tick += new System.EventHandler(this.Timer_Close_Tick);
            // 
            // groupBox_flowdir_select
            // 
            this.groupBox_flowdir_select.ContextMenuStrip = this.contextMenuStrip1;
            this.groupBox_flowdir_select.Controls.Add(this.radioButton_flowdir_mul);
            this.groupBox_flowdir_select.Controls.Add(this.radioButton_flowdir_sgn);
            this.groupBox_flowdir_select.Location = new System.Drawing.Point(164, 302);
            this.groupBox_flowdir_select.Name = "groupBox_flowdir_select";
            this.groupBox_flowdir_select.Size = new System.Drawing.Size(163, 54);
            this.groupBox_flowdir_select.TabIndex = 15;
            this.groupBox_flowdir_select.TabStop = false;
            this.groupBox_flowdir_select.Text = "流向算法选择";
            this.groupBox_flowdir_select.MouseHover += new System.EventHandler(this.groupBox_flowdir_select_MouseHover);
            // 
            // radioButton_flowdir_mul
            // 
            this.radioButton_flowdir_mul.AutoSize = true;
            this.radioButton_flowdir_mul.ContextMenuStrip = this.contextMenuStrip1;
            this.radioButton_flowdir_mul.Location = new System.Drawing.Point(96, 25);
            this.radioButton_flowdir_mul.Name = "radioButton_flowdir_mul";
            this.radioButton_flowdir_mul.Size = new System.Drawing.Size(59, 16);
            this.radioButton_flowdir_mul.TabIndex = 1;
            this.radioButton_flowdir_mul.Text = "多流向";
            this.radioButton_flowdir_mul.UseVisualStyleBackColor = true;
            this.radioButton_flowdir_mul.CheckedChanged += new System.EventHandler(this.radioButton_mul_dir_CheckedChanged);
            this.radioButton_flowdir_mul.Click += new System.EventHandler(this.radioButton_Sgn_D8_Click);
            // 
            // radioButton_flowdir_sgn
            // 
            this.radioButton_flowdir_sgn.AutoSize = true;
            this.radioButton_flowdir_sgn.Checked = true;
            this.radioButton_flowdir_sgn.ContextMenuStrip = this.contextMenuStrip1;
            this.radioButton_flowdir_sgn.Location = new System.Drawing.Point(14, 25);
            this.radioButton_flowdir_sgn.Name = "radioButton_flowdir_sgn";
            this.radioButton_flowdir_sgn.Size = new System.Drawing.Size(59, 16);
            this.radioButton_flowdir_sgn.TabIndex = 0;
            this.radioButton_flowdir_sgn.TabStop = true;
            this.radioButton_flowdir_sgn.Text = "单流向";
            this.radioButton_flowdir_sgn.UseVisualStyleBackColor = true;
            this.radioButton_flowdir_sgn.CheckedChanged += new System.EventHandler(this.radioButton_sgl_dir_CheckedChanged);
            this.radioButton_flowdir_sgn.Click += new System.EventHandler(this.radioButton_Sgn_D8_Click);
            // 
            // groupBox_flowdirmul_select
            // 
            this.groupBox_flowdirmul_select.BackColor = System.Drawing.Color.Transparent;
            this.groupBox_flowdirmul_select.ContextMenuStrip = this.contextMenuStrip1;
            this.groupBox_flowdirmul_select.Controls.Add(this.radioButton_Mul_Dinf);
            this.groupBox_flowdirmul_select.Controls.Add(this.radioButton_Mul_DEMON);
            this.groupBox_flowdirmul_select.Controls.Add(this.radioButton_Mul_FMFD);
            this.groupBox_flowdirmul_select.Controls.Add(this.radioButton_Mul_MS);
            this.groupBox_flowdirmul_select.Location = new System.Drawing.Point(338, 302);
            this.groupBox_flowdirmul_select.Name = "groupBox_flowdirmul_select";
            this.groupBox_flowdirmul_select.Size = new System.Drawing.Size(193, 116);
            this.groupBox_flowdirmul_select.TabIndex = 16;
            this.groupBox_flowdirmul_select.TabStop = false;
            this.groupBox_flowdirmul_select.Text = "多流向算法选择";
            this.groupBox_flowdirmul_select.Visible = false;
            // 
            // radioButton_Mul_Dinf
            // 
            this.radioButton_Mul_Dinf.AutoSize = true;
            this.radioButton_Mul_Dinf.Location = new System.Drawing.Point(23, 91);
            this.radioButton_Mul_Dinf.Name = "radioButton_Mul_Dinf";
            this.radioButton_Mul_Dinf.Size = new System.Drawing.Size(131, 16);
            this.radioButton_Mul_Dinf.TabIndex = 0;
            this.radioButton_Mul_Dinf.Text = "Dinf（无穷方向法）";
            this.radioButton_Mul_Dinf.UseVisualStyleBackColor = true;
            this.radioButton_Mul_Dinf.Click += new System.EventHandler(this.radioButton_Sgn_D8_Click);
            // 
            // radioButton_Mul_DEMON
            // 
            this.radioButton_Mul_DEMON.AutoSize = true;
            this.radioButton_Mul_DEMON.Enabled = false;
            this.radioButton_Mul_DEMON.Location = new System.Drawing.Point(23, 69);
            this.radioButton_Mul_DEMON.Name = "radioButton_Mul_DEMON";
            this.radioButton_Mul_DEMON.Size = new System.Drawing.Size(113, 16);
            this.radioButton_Mul_DEMON.TabIndex = 0;
            this.radioButton_Mul_DEMON.Text = "DEMON（流管法）";
            this.radioButton_Mul_DEMON.UseVisualStyleBackColor = true;
            this.radioButton_Mul_DEMON.Click += new System.EventHandler(this.radioButton_Sgn_D8_Click);
            // 
            // radioButton_Mul_FMFD
            // 
            this.radioButton_Mul_FMFD.AutoSize = true;
            this.radioButton_Mul_FMFD.Location = new System.Drawing.Point(23, 47);
            this.radioButton_Mul_FMFD.Name = "radioButton_Mul_FMFD";
            this.radioButton_Mul_FMFD.Size = new System.Drawing.Size(143, 16);
            this.radioButton_Mul_FMFD.TabIndex = 0;
            this.radioButton_Mul_FMFD.Text = "FMFD（基于坡度指数）";
            this.radioButton_Mul_FMFD.UseVisualStyleBackColor = true;
            this.radioButton_Mul_FMFD.CheckedChanged += new System.EventHandler(this.radioButton_Mul_FMFD_CheckedChanged);
            this.radioButton_Mul_FMFD.Click += new System.EventHandler(this.radioButton_Sgn_D8_Click);
            // 
            // radioButton_Mul_MS
            // 
            this.radioButton_Mul_MS.AutoSize = true;
            this.radioButton_Mul_MS.Checked = true;
            this.radioButton_Mul_MS.Location = new System.Drawing.Point(23, 25);
            this.radioButton_Mul_MS.Name = "radioButton_Mul_MS";
            this.radioButton_Mul_MS.Size = new System.Drawing.Size(107, 16);
            this.radioButton_Mul_MS.TabIndex = 0;
            this.radioButton_Mul_MS.TabStop = true;
            this.radioButton_Mul_MS.Text = "MS（基于坡度）";
            this.radioButton_Mul_MS.UseVisualStyleBackColor = true;
            this.radioButton_Mul_MS.CheckedChanged += new System.EventHandler(this.radioButton_Mul_MS_CheckedChanged);
            // 
            // groupBox_flowdirsgn_select
            // 
            this.groupBox_flowdirsgn_select.BackColor = System.Drawing.Color.Transparent;
            this.groupBox_flowdirsgn_select.ContextMenuStrip = this.contextMenuStrip1;
            this.groupBox_flowdirsgn_select.Controls.Add(this.radioButton_Sgn_Rho);
            this.groupBox_flowdirsgn_select.Controls.Add(this.radioButton_Sgn_Rho8);
            this.groupBox_flowdirsgn_select.Controls.Add(this.radioButton_Sgn_Rho4);
            this.groupBox_flowdirsgn_select.Controls.Add(this.radioButton_Sgn_D8);
            this.groupBox_flowdirsgn_select.Location = new System.Drawing.Point(338, 302);
            this.groupBox_flowdirsgn_select.Name = "groupBox_flowdirsgn_select";
            this.groupBox_flowdirsgn_select.Size = new System.Drawing.Size(193, 116);
            this.groupBox_flowdirsgn_select.TabIndex = 23;
            this.groupBox_flowdirsgn_select.TabStop = false;
            this.groupBox_flowdirsgn_select.Text = "单流向算法选择";
            // 
            // radioButton_Sgn_Rho
            // 
            this.radioButton_Sgn_Rho.AutoSize = true;
            this.radioButton_Sgn_Rho.Enabled = false;
            this.radioButton_Sgn_Rho.Location = new System.Drawing.Point(23, 91);
            this.radioButton_Sgn_Rho.Name = "radioButton_Sgn_Rho";
            this.radioButton_Sgn_Rho.Size = new System.Drawing.Size(95, 16);
            this.radioButton_Sgn_Rho.TabIndex = 0;
            this.radioButton_Sgn_Rho.Text = "流向驱动算法";
            this.radioButton_Sgn_Rho.UseVisualStyleBackColor = true;
            // 
            // radioButton_Sgn_Rho8
            // 
            this.radioButton_Sgn_Rho8.AutoSize = true;
            this.radioButton_Sgn_Rho8.Enabled = false;
            this.radioButton_Sgn_Rho8.Location = new System.Drawing.Point(23, 69);
            this.radioButton_Sgn_Rho8.Name = "radioButton_Sgn_Rho8";
            this.radioButton_Sgn_Rho8.Size = new System.Drawing.Size(143, 16);
            this.radioButton_Sgn_Rho8.TabIndex = 0;
            this.radioButton_Sgn_Rho8.Text = "Rho8（随机八方向法）";
            this.radioButton_Sgn_Rho8.UseVisualStyleBackColor = true;
            // 
            // radioButton_Sgn_Rho4
            // 
            this.radioButton_Sgn_Rho4.AutoSize = true;
            this.radioButton_Sgn_Rho4.Enabled = false;
            this.radioButton_Sgn_Rho4.Location = new System.Drawing.Point(23, 47);
            this.radioButton_Sgn_Rho4.Name = "radioButton_Sgn_Rho4";
            this.radioButton_Sgn_Rho4.Size = new System.Drawing.Size(143, 16);
            this.radioButton_Sgn_Rho4.TabIndex = 0;
            this.radioButton_Sgn_Rho4.Text = "Rho4（随机四方向法）";
            this.radioButton_Sgn_Rho4.UseVisualStyleBackColor = true;
            // 
            // radioButton_Sgn_D8
            // 
            this.radioButton_Sgn_D8.AutoSize = true;
            this.radioButton_Sgn_D8.Checked = true;
            this.radioButton_Sgn_D8.Location = new System.Drawing.Point(23, 25);
            this.radioButton_Sgn_D8.Name = "radioButton_Sgn_D8";
            this.radioButton_Sgn_D8.Size = new System.Drawing.Size(119, 16);
            this.radioButton_Sgn_D8.TabIndex = 0;
            this.radioButton_Sgn_D8.TabStop = true;
            this.radioButton_Sgn_D8.Text = "D8（最大坡降法）";
            this.radioButton_Sgn_D8.UseVisualStyleBackColor = true;
            // 
            // button_helpInfo
            // 
            this.button_helpInfo.ContextMenuStrip = this.contextMenuStrip1;
            this.button_helpInfo.Location = new System.Drawing.Point(428, 435);
            this.button_helpInfo.Name = "button_helpInfo";
            this.button_helpInfo.Size = new System.Drawing.Size(84, 22);
            this.button_helpInfo.TabIndex = 19;
            this.button_helpInfo.Text = "Help>>";
            this.button_helpInfo.UseVisualStyleBackColor = true;
            this.button_helpInfo.Click += new System.EventHandler(this.button_helpInfo_Click);
            // 
            // textBox_helpinfo
            // 
            this.textBox_helpinfo.Font = new System.Drawing.Font("SimSun", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.textBox_helpinfo.Location = new System.Drawing.Point(17, 13);
            this.textBox_helpinfo.Multiline = true;
            this.textBox_helpinfo.Name = "textBox_helpinfo";
            this.textBox_helpinfo.Size = new System.Drawing.Size(208, 466);
            this.textBox_helpinfo.TabIndex = 18;
            this.textBox_helpinfo.TextChanged += new System.EventHandler(this.textBox_helpinfo_TextChanged);
            // 
            // groupBox10
            // 
            this.groupBox10.Controls.Add(this.textBox_helpinfo);
            this.groupBox10.Location = new System.Drawing.Point(544, -10);
            this.groupBox10.Name = "groupBox10";
            this.groupBox10.Size = new System.Drawing.Size(239, 518);
            this.groupBox10.TabIndex = 20;
            this.groupBox10.TabStop = false;
            // 
            // label_slope_exp
            // 
            this.label_slope_exp.AutoSize = true;
            this.label_slope_exp.Location = new System.Drawing.Point(12, 27);
            this.label_slope_exp.Name = "label_slope_exp";
            this.label_slope_exp.Size = new System.Drawing.Size(53, 12);
            this.label_slope_exp.TabIndex = 21;
            this.label_slope_exp.Text = "坡度指数";
            // 
            // groupbox_slope_exp
            // 
            this.groupbox_slope_exp.Controls.Add(this.textBox_slope_exp);
            this.groupbox_slope_exp.Controls.Add(this.label_slope_exp);
            this.groupbox_slope_exp.Enabled = false;
            this.groupbox_slope_exp.Location = new System.Drawing.Point(164, 362);
            this.groupbox_slope_exp.Name = "groupbox_slope_exp";
            this.groupbox_slope_exp.Size = new System.Drawing.Size(163, 56);
            this.groupbox_slope_exp.TabIndex = 22;
            this.groupbox_slope_exp.TabStop = false;
            this.groupbox_slope_exp.Text = "坡度指数设置";
            // 
            // textBox_slope_exp
            // 
            this.textBox_slope_exp.Location = new System.Drawing.Point(71, 24);
            this.textBox_slope_exp.Name = "textBox_slope_exp";
            this.textBox_slope_exp.Size = new System.Drawing.Size(86, 21);
            this.textBox_slope_exp.TabIndex = 22;
            this.textBox_slope_exp.Text = "1.1";
            // 
            // groupBox_cutoff
            // 
            this.groupBox_cutoff.Controls.Add(this.radioButton_cutoff_yes);
            this.groupBox_cutoff.Controls.Add(this.radioButton_cutoff_no);
            this.groupBox_cutoff.Location = new System.Drawing.Point(193, 127);
            this.groupBox_cutoff.Name = "groupBox_cutoff";
            this.groupBox_cutoff.Size = new System.Drawing.Size(67, 81);
            this.groupBox_cutoff.TabIndex = 7;
            this.groupBox_cutoff.TabStop = false;
            this.groupBox_cutoff.Text = "截断？";
            this.groupBox_cutoff.MouseHover += new System.EventHandler(this.groupBox_cutoff_MouseHover);
            // 
            // radioButton_cutoff_yes
            // 
            this.radioButton_cutoff_yes.AutoSize = true;
            this.radioButton_cutoff_yes.Checked = true;
            this.radioButton_cutoff_yes.Location = new System.Drawing.Point(15, 26);
            this.radioButton_cutoff_yes.Name = "radioButton_cutoff_yes";
            this.radioButton_cutoff_yes.Size = new System.Drawing.Size(35, 16);
            this.radioButton_cutoff_yes.TabIndex = 12;
            this.radioButton_cutoff_yes.TabStop = true;
            this.radioButton_cutoff_yes.Text = "是";
            this.radioButton_cutoff_yes.UseVisualStyleBackColor = true;
            this.radioButton_cutoff_yes.Click += new System.EventHandler(this.radioButton_Sgn_D8_Click);
            this.radioButton_cutoff_yes.MouseHover += new System.EventHandler(this.groupBox_cutoff_MouseHover);
            // 
            // radioButton_cutoff_no
            // 
            this.radioButton_cutoff_no.AutoSize = true;
            this.radioButton_cutoff_no.Location = new System.Drawing.Point(15, 50);
            this.radioButton_cutoff_no.Name = "radioButton_cutoff_no";
            this.radioButton_cutoff_no.Size = new System.Drawing.Size(35, 16);
            this.radioButton_cutoff_no.TabIndex = 2;
            this.radioButton_cutoff_no.TabStop = true;
            this.radioButton_cutoff_no.Text = "否";
            this.radioButton_cutoff_no.UseVisualStyleBackColor = true;
            this.radioButton_cutoff_no.CheckedChanged += new System.EventHandler(this.radioButton_flowcutno_CheckedChanged);
            this.radioButton_cutoff_no.Click += new System.EventHandler(this.radioButton_Sgn_D8_Click);
            this.radioButton_cutoff_no.MouseHover += new System.EventHandler(this.groupBox_cutoff_MouseHover);
            // 
            // groupBox_sink_fill
            // 
            this.groupBox_sink_fill.Controls.Add(this.radioButton_sinkfill_yes);
            this.groupBox_sink_fill.Controls.Add(this.radioButton_sinkfill_no);
            this.groupBox_sink_fill.Location = new System.Drawing.Point(266, 127);
            this.groupBox_sink_fill.Name = "groupBox_sink_fill";
            this.groupBox_sink_fill.Size = new System.Drawing.Size(80, 81);
            this.groupBox_sink_fill.TabIndex = 7;
            this.groupBox_sink_fill.TabStop = false;
            this.groupBox_sink_fill.Text = "洼地填充？";
            this.groupBox_sink_fill.MouseHover += new System.EventHandler(this.groupBox_sink_fill_MouseHover);
            // 
            // radioButton_sinkfill_yes
            // 
            this.radioButton_sinkfill_yes.AutoSize = true;
            this.radioButton_sinkfill_yes.Location = new System.Drawing.Point(25, 26);
            this.radioButton_sinkfill_yes.Name = "radioButton_sinkfill_yes";
            this.radioButton_sinkfill_yes.Size = new System.Drawing.Size(35, 16);
            this.radioButton_sinkfill_yes.TabIndex = 12;
            this.radioButton_sinkfill_yes.Text = "是";
            this.radioButton_sinkfill_yes.UseVisualStyleBackColor = true;
            this.radioButton_sinkfill_yes.Click += new System.EventHandler(this.radioButton_Sgn_D8_Click);
            this.radioButton_sinkfill_yes.MouseHover += new System.EventHandler(this.groupBox_sink_fill_MouseHover);
            // 
            // radioButton_sinkfill_no
            // 
            this.radioButton_sinkfill_no.AutoSize = true;
            this.radioButton_sinkfill_no.Checked = true;
            this.radioButton_sinkfill_no.Location = new System.Drawing.Point(25, 50);
            this.radioButton_sinkfill_no.Name = "radioButton_sinkfill_no";
            this.radioButton_sinkfill_no.Size = new System.Drawing.Size(35, 16);
            this.radioButton_sinkfill_no.TabIndex = 2;
            this.radioButton_sinkfill_no.TabStop = true;
            this.radioButton_sinkfill_no.Text = "否";
            this.radioButton_sinkfill_no.UseVisualStyleBackColor = true;
            this.radioButton_sinkfill_no.CheckedChanged += new System.EventHandler(this.radioButton_flowcutno_CheckedChanged);
            this.radioButton_sinkfill_no.Click += new System.EventHandler(this.radioButton_Sgn_D8_Click);
            this.radioButton_sinkfill_no.MouseHover += new System.EventHandler(this.groupBox_sink_fill_MouseHover);
            // 
            // groupBox_threshold
            // 
            this.groupBox_threshold.Controls.Add(this.label_threshold);
            this.groupBox_threshold.Controls.Add(this.textBox_threshold);
            this.groupBox_threshold.Location = new System.Drawing.Point(304, 215);
            this.groupBox_threshold.Name = "groupBox_threshold";
            this.groupBox_threshold.Size = new System.Drawing.Size(103, 77);
            this.groupBox_threshold.TabIndex = 10;
            this.groupBox_threshold.TabStop = false;
            this.groupBox_threshold.Text = "河网阈值";
            this.groupBox_threshold.MouseHover += new System.EventHandler(this.groupBox_threshold_MouseHover);
            // 
            // label_threshold
            // 
            this.label_threshold.AutoSize = true;
            this.label_threshold.Location = new System.Drawing.Point(6, 26);
            this.label_threshold.Name = "label_threshold";
            this.label_threshold.Size = new System.Drawing.Size(53, 12);
            this.label_threshold.TabIndex = 1;
            this.label_threshold.Text = "阈值(㎡)";
            this.label_threshold.Click += new System.EventHandler(this.label3_Click);
            // 
            // textBox_threshold
            // 
            this.textBox_threshold.Location = new System.Drawing.Point(8, 50);
            this.textBox_threshold.Name = "textBox_threshold";
            this.textBox_threshold.Size = new System.Drawing.Size(90, 21);
            this.textBox_threshold.TabIndex = 0;
            this.textBox_threshold.Text = "8000";
            this.textBox_threshold.Click += new System.EventHandler(this.radioButton_Sgn_D8_Click);
            this.textBox_threshold.MouseHover += new System.EventHandler(this.groupBox_threshold_MouseHover);
            // 
            // button_language
            // 
            this.button_language.Location = new System.Drawing.Point(43, 435);
            this.button_language.Name = "button_language";
            this.button_language.Size = new System.Drawing.Size(83, 23);
            this.button_language.TabIndex = 3;
            this.button_language.Text = "English";
            this.button_language.UseVisualStyleBackColor = true;
            this.button_language.Click += new System.EventHandler(this.button_language_Click);
            // 
            // radioButton2
            // 
            this.radioButton2.AutoSize = true;
            this.radioButton2.Checked = true;
            this.radioButton2.ContextMenuStrip = this.contextMenuStrip1;
            this.radioButton2.Location = new System.Drawing.Point(236, 51);
            this.radioButton2.Name = "radioButton2";
            this.radioButton2.Size = new System.Drawing.Size(35, 16);
            this.radioButton2.TabIndex = 1;
            this.radioButton2.TabStop = true;
            this.radioButton2.Text = "否";
            this.radioButton2.UseVisualStyleBackColor = true;
            this.radioButton2.Visible = false;
            // 
            // checkBox_Save_SlopLength
            // 
            this.checkBox_Save_SlopLength.AutoSize = true;
            this.checkBox_Save_SlopLength.Location = new System.Drawing.Point(56, 20);
            this.checkBox_Save_SlopLength.Name = "checkBox_Save_SlopLength";
            this.checkBox_Save_SlopLength.Size = new System.Drawing.Size(48, 16);
            this.checkBox_Save_SlopLength.TabIndex = 12;
            this.checkBox_Save_SlopLength.Text = "坡度";
            this.checkBox_Save_SlopLength.UseVisualStyleBackColor = true;
            this.checkBox_Save_SlopLength.CheckedChanged += new System.EventHandler(this.checkBox_SlopLength_CheckedChanged);
            this.checkBox_Save_SlopLength.Click += new System.EventHandler(this.radioButton_Sgn_D8_Click);
            this.checkBox_Save_SlopLength.MouseHover += new System.EventHandler(this.checkBox_SlopLength_MouseHover);
            // 
            // checkBox_Save_SlopAngle
            // 
            this.checkBox_Save_SlopAngle.AutoSize = true;
            this.checkBox_Save_SlopAngle.Location = new System.Drawing.Point(56, 39);
            this.checkBox_Save_SlopAngle.Name = "checkBox_Save_SlopAngle";
            this.checkBox_Save_SlopAngle.Size = new System.Drawing.Size(48, 16);
            this.checkBox_Save_SlopAngle.TabIndex = 12;
            this.checkBox_Save_SlopAngle.Text = "坡长";
            this.checkBox_Save_SlopAngle.UseVisualStyleBackColor = true;
            this.checkBox_Save_SlopAngle.CheckedChanged += new System.EventHandler(this.checkBox_SlopLength_CheckedChanged);
            this.checkBox_Save_SlopAngle.Click += new System.EventHandler(this.radioButton_Sgn_D8_Click);
            this.checkBox_Save_SlopAngle.MouseHover += new System.EventHandler(this.checkBox_SlopAngle_MouseHover);
            // 
            // checkBox_Save_LengthFactor
            // 
            this.checkBox_Save_LengthFactor.AutoSize = true;
            this.checkBox_Save_LengthFactor.Location = new System.Drawing.Point(103, 20);
            this.checkBox_Save_LengthFactor.Name = "checkBox_Save_LengthFactor";
            this.checkBox_Save_LengthFactor.Size = new System.Drawing.Size(72, 16);
            this.checkBox_Save_LengthFactor.TabIndex = 12;
            this.checkBox_Save_LengthFactor.Text = "坡度因子";
            this.checkBox_Save_LengthFactor.UseVisualStyleBackColor = true;
            this.checkBox_Save_LengthFactor.CheckedChanged += new System.EventHandler(this.checkBox_SlopLength_CheckedChanged);
            this.checkBox_Save_LengthFactor.Click += new System.EventHandler(this.radioButton_Sgn_D8_Click);
            this.checkBox_Save_LengthFactor.MouseHover += new System.EventHandler(this.checkBox_LengthFactor_MouseHover);
            // 
            // checkBox_Save_SlopFactor
            // 
            this.checkBox_Save_SlopFactor.AutoSize = true;
            this.checkBox_Save_SlopFactor.Location = new System.Drawing.Point(103, 39);
            this.checkBox_Save_SlopFactor.Name = "checkBox_Save_SlopFactor";
            this.checkBox_Save_SlopFactor.Size = new System.Drawing.Size(72, 16);
            this.checkBox_Save_SlopFactor.TabIndex = 12;
            this.checkBox_Save_SlopFactor.Text = "坡长因子";
            this.checkBox_Save_SlopFactor.UseVisualStyleBackColor = true;
            this.checkBox_Save_SlopFactor.CheckedChanged += new System.EventHandler(this.checkBox_SlopLength_CheckedChanged);
            this.checkBox_Save_SlopFactor.Click += new System.EventHandler(this.radioButton_Sgn_D8_Click);
            this.checkBox_Save_SlopFactor.MouseHover += new System.EventHandler(this.checkBox_SlopFactor_MouseHover);
            // 
            // checkBox_Save_LSFactor
            // 
            this.checkBox_Save_LSFactor.AutoSize = true;
            this.checkBox_Save_LSFactor.Checked = true;
            this.checkBox_Save_LSFactor.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBox_Save_LSFactor.Location = new System.Drawing.Point(56, 59);
            this.checkBox_Save_LSFactor.Name = "checkBox_Save_LSFactor";
            this.checkBox_Save_LSFactor.Size = new System.Drawing.Size(96, 16);
            this.checkBox_Save_LSFactor.TabIndex = 12;
            this.checkBox_Save_LSFactor.Text = "坡度坡长因子";
            this.checkBox_Save_LSFactor.UseVisualStyleBackColor = true;
            this.checkBox_Save_LSFactor.CheckedChanged += new System.EventHandler(this.checkBox_SlopLength_CheckedChanged);
            this.checkBox_Save_LSFactor.MouseHover += new System.EventHandler(this.checkBox_LSFactor_MouseHover);
            // 
            // checkBox_Save_SelectAll
            // 
            this.checkBox_Save_SelectAll.AutoSize = true;
            this.checkBox_Save_SelectAll.Location = new System.Drawing.Point(4, 19);
            this.checkBox_Save_SelectAll.Name = "checkBox_Save_SelectAll";
            this.checkBox_Save_SelectAll.Size = new System.Drawing.Size(48, 16);
            this.checkBox_Save_SelectAll.TabIndex = 12;
            this.checkBox_Save_SelectAll.Text = "全选";
            this.checkBox_Save_SelectAll.UseVisualStyleBackColor = true;
            this.checkBox_Save_SelectAll.CheckedChanged += new System.EventHandler(this.checkBox_SelectAll_CheckedChanged);
            this.checkBox_Save_SelectAll.Click += new System.EventHandler(this.radioButton_Sgn_D8_Click);
            this.checkBox_Save_SelectAll.MouseHover += new System.EventHandler(this.checkBox_SelectAll_MouseHover);
            // 
            // groupBox_save
            // 
            this.groupBox_save.ContextMenuStrip = this.contextMenuStrip1;
            this.groupBox_save.Controls.Add(this.checkBox_Save_SelectAll);
            this.groupBox_save.Controls.Add(this.checkBox_Save_LSFactor);
            this.groupBox_save.Controls.Add(this.checkBox_Save_SlopFactor);
            this.groupBox_save.Controls.Add(this.checkBox_Save_LengthFactor);
            this.groupBox_save.Controls.Add(this.checkBox_Save_SlopAngle);
            this.groupBox_save.Controls.Add(this.checkBox_Save_SlopLength);
            this.groupBox_save.Controls.Add(this.radioButton2);
            this.groupBox_save.Location = new System.Drawing.Point(352, 127);
            this.groupBox_save.Name = "groupBox_save";
            this.groupBox_save.Size = new System.Drawing.Size(179, 81);
            this.groupBox_save.TabIndex = 6;
            this.groupBox_save.TabStop = false;
            this.groupBox_save.Text = "保存文件选择";
            // 
            // groupBox_Cumulated_Way
            // 
            this.groupBox_Cumulated_Way.Controls.Add(this.radioButton_Cumulated_Total);
            this.groupBox_Cumulated_Way.Controls.Add(this.radioButton_Cumulated_Max);
            this.groupBox_Cumulated_Way.Location = new System.Drawing.Point(413, 215);
            this.groupBox_Cumulated_Way.Name = "groupBox_Cumulated_Way";
            this.groupBox_Cumulated_Way.Size = new System.Drawing.Size(118, 77);
            this.groupBox_Cumulated_Way.TabIndex = 26;
            this.groupBox_Cumulated_Way.TabStop = false;
            this.groupBox_Cumulated_Way.Text = "累积方式";
            this.groupBox_Cumulated_Way.MouseHover += new System.EventHandler(this.groupBox_Cumulated_Way_MouseHover);
            // 
            // radioButton_Cumulated_Total
            // 
            this.radioButton_Cumulated_Total.AutoSize = true;
            this.radioButton_Cumulated_Total.Location = new System.Drawing.Point(27, 48);
            this.radioButton_Cumulated_Total.Name = "radioButton_Cumulated_Total";
            this.radioButton_Cumulated_Total.Size = new System.Drawing.Size(71, 16);
            this.radioButton_Cumulated_Total.TabIndex = 11;
            this.radioButton_Cumulated_Total.Text = "全部流入";
            this.radioButton_Cumulated_Total.UseVisualStyleBackColor = true;
            this.radioButton_Cumulated_Total.MouseHover += new System.EventHandler(this.groupBox_Cumulated_Way_MouseHover);
            // 
            // radioButton_Cumulated_Max
            // 
            this.radioButton_Cumulated_Max.AutoSize = true;
            this.radioButton_Cumulated_Max.Checked = true;
            this.radioButton_Cumulated_Max.ContextMenuStrip = this.contextMenuStrip1;
            this.radioButton_Cumulated_Max.Location = new System.Drawing.Point(27, 22);
            this.radioButton_Cumulated_Max.Name = "radioButton_Cumulated_Max";
            this.radioButton_Cumulated_Max.Size = new System.Drawing.Size(59, 16);
            this.radioButton_Cumulated_Max.TabIndex = 11;
            this.radioButton_Cumulated_Max.TabStop = true;
            this.radioButton_Cumulated_Max.Text = "最大值";
            this.radioButton_Cumulated_Max.UseVisualStyleBackColor = true;
            this.radioButton_Cumulated_Max.MouseHover += new System.EventHandler(this.groupBox_Cumulated_Way_MouseHover);
            // 
            // groupBox_modeling
            // 
            this.groupBox_modeling.Controls.Add(this.radioButton_model_CSLE);
            this.groupBox_modeling.Controls.Add(this.radioButton_model_RUSLE);
            this.groupBox_modeling.Location = new System.Drawing.Point(111, 127);
            this.groupBox_modeling.Name = "groupBox_modeling";
            this.groupBox_modeling.Size = new System.Drawing.Size(74, 80);
            this.groupBox_modeling.TabIndex = 27;
            this.groupBox_modeling.TabStop = false;
            this.groupBox_modeling.Text = "模型";
            // 
            // radioButton_model_CSLE
            // 
            this.radioButton_model_CSLE.AutoSize = true;
            this.radioButton_model_CSLE.Location = new System.Drawing.Point(12, 26);
            this.radioButton_model_CSLE.Name = "radioButton_model_CSLE";
            this.radioButton_model_CSLE.Size = new System.Drawing.Size(47, 16);
            this.radioButton_model_CSLE.TabIndex = 14;
            this.radioButton_model_CSLE.Text = "CSLE";
            this.radioButton_model_CSLE.UseVisualStyleBackColor = true;
            // 
            // radioButton_model_RUSLE
            // 
            this.radioButton_model_RUSLE.AutoSize = true;
            this.radioButton_model_RUSLE.Checked = true;
            this.radioButton_model_RUSLE.Location = new System.Drawing.Point(12, 50);
            this.radioButton_model_RUSLE.Name = "radioButton_model_RUSLE";
            this.radioButton_model_RUSLE.Size = new System.Drawing.Size(53, 16);
            this.radioButton_model_RUSLE.TabIndex = 13;
            this.radioButton_model_RUSLE.TabStop = true;
            this.radioButton_model_RUSLE.Text = "RUSLE";
            this.radioButton_model_RUSLE.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(539, 472);
            this.Controls.Add(this.groupBox_modeling);
            this.Controls.Add(this.groupBox_Cumulated_Way);
            this.Controls.Add(this.groupBox10);
            this.Controls.Add(this.groupbox_slope_exp);
            this.Controls.Add(this.button_helpInfo);
            this.Controls.Add(this.groupBox_flowdirsgn_select);
            this.Controls.Add(this.groupBox_flowdirmul_select);
            this.Controls.Add(this.groupBox_flowdir_select);
            this.Controls.Add(this.groupBox_outputpath);
            this.Controls.Add(this.groupBox_cutoff_set);
            this.Controls.Add(this.groupBox_channelcutoff);
            this.Controls.Add(this.groupBox_threshold);
            this.Controls.Add(this.groupBox_profix);
            this.Controls.Add(this.groupBox_inputpath);
            this.Controls.Add(this.button_cancel);
            this.Controls.Add(this.groupBox_save);
            this.Controls.Add(this.groupBox_cutoff);
            this.Controls.Add(this.groupBox_sink_fill);
            this.Controls.Add(this.button_language);
            this.Controls.Add(this.button_start);
            this.Controls.Add(this.groupBox_nodata_fill);
            this.Controls.Add(this.groupBox_nodata_repair);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "区域LS因子计算工具";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_FormClosing);
            this.Load += new System.EventHandler(this.Form1_Load);
            this.contextMenuStrip1.ResumeLayout(false);
            this.groupBox_inputpath.ResumeLayout(false);
            this.groupBox_inputpath.PerformLayout();
            this.groupBox_nodata_repair.ResumeLayout(false);
            this.groupBox_nodata_repair.PerformLayout();
            this.groupBox_cutoff_set.ResumeLayout(false);
            this.groupBox_cutoff_set.PerformLayout();
            this.groupBox_profix.ResumeLayout(false);
            this.groupBox_profix.PerformLayout();
            this.groupBox_nodata_fill.ResumeLayout(false);
            this.groupBox_nodata_fill.PerformLayout();
            this.groupBox_outputpath.ResumeLayout(false);
            this.groupBox_outputpath.PerformLayout();
            this.groupBox_channelcutoff.ResumeLayout(false);
            this.groupBox_channelcutoff.PerformLayout();
            this.groupBox_flowdir_select.ResumeLayout(false);
            this.groupBox_flowdir_select.PerformLayout();
            this.groupBox_flowdirmul_select.ResumeLayout(false);
            this.groupBox_flowdirmul_select.PerformLayout();
            this.groupBox_flowdirsgn_select.ResumeLayout(false);
            this.groupBox_flowdirsgn_select.PerformLayout();
            this.groupBox10.ResumeLayout(false);
            this.groupBox10.PerformLayout();
            this.groupbox_slope_exp.ResumeLayout(false);
            this.groupbox_slope_exp.PerformLayout();
            this.groupBox_cutoff.ResumeLayout(false);
            this.groupBox_cutoff.PerformLayout();
            this.groupBox_sink_fill.ResumeLayout(false);
            this.groupBox_sink_fill.PerformLayout();
            this.groupBox_threshold.ResumeLayout(false);
            this.groupBox_threshold.PerformLayout();
            this.groupBox_save.ResumeLayout(false);
            this.groupBox_save.PerformLayout();
            this.groupBox_Cumulated_Way.ResumeLayout(false);
            this.groupBox_Cumulated_Way.PerformLayout();
            this.groupBox_modeling.ResumeLayout(false);
            this.groupBox_modeling.PerformLayout();
            this.ResumeLayout(false);

        }



        private System.Windows.Forms.Button button_inputpath;
        private System.Windows.Forms.GroupBox groupBox_inputpath;
        private System.Windows.Forms.Button button_cancel;
        private System.Windows.Forms.Button button_start;
        private System.Windows.Forms.TextBox textBox_inputpath;
        private System.Windows.Forms.GroupBox groupBox_nodata_repair;
        private System.Windows.Forms.GroupBox groupBox_cutoff_set;
        private System.Windows.Forms.Label label_cutoff_slopegreat;
        private System.Windows.Forms.Label label_cutoff_slopeless;
        private System.Windows.Forms.TextBox textBox_cutoff_slopegreat;
        private System.Windows.Forms.TextBox textBox_cutoff_slopeless;
        private System.Windows.Forms.RadioButton radioButton_nodata_repair_no;
        private System.Windows.Forms.GroupBox groupBox_profix;
        private System.Windows.Forms.Label label_profix;
        private System.Windows.Forms.TextBox textBox_profix;
        private RadioButton radioButton_nodata_repair_yes;
        private GroupBox groupBox_nodata_fill;
        private RadioButton radioButton_fill_aver;
        private RadioButton radioButton_fill_min;
        private GroupBox groupBox_outputpath;
        private TextBox textBox_outputpath;
        private Button button_outputpath;
        private ContextMenuStrip contextMenuStrip1;
        private ToolStripMenuItem ToolStripMenuItem;
        private Timer Timer_Before_Closed;
        private Timer Timer_Cancel_Close;
        private Timer Timer_Close;
        private GroupBox groupBox_channelcutoff;
        private RadioButton radioButton_channel_no;
        private RadioButton radioButton_channel_yes;
        private GroupBox groupBox_flowdir_select;
        private RadioButton radioButton_flowdir_mul;
        private RadioButton radioButton_flowdir_sgn;
        private GroupBox groupBox_flowdirmul_select;
        private RadioButton radioButton_Mul_DEMON;
        private RadioButton radioButton_Mul_FMFD;
        private RadioButton radioButton_Mul_MS;
        private RadioButton radioButton_Mul_Dinf;
        private Button button_helpInfo;
        private TextBox textBox_helpinfo;
        private GroupBox groupBox10;
        private Label label_slope_exp;
        private GroupBox groupbox_slope_exp;
        private TextBox textBox_slope_exp;
        private GroupBox groupBox_flowdirsgn_select;
        private RadioButton radioButton_Sgn_Rho;
        private RadioButton radioButton_Sgn_Rho8;
        private RadioButton radioButton_Sgn_Rho4;
        private RadioButton radioButton_Sgn_D8;
        private GroupBox groupBox_cutoff;
        private RadioButton radioButton_cutoff_yes;
        private RadioButton radioButton_cutoff_no;
        private GroupBox groupBox_sink_fill;
        private RadioButton radioButton_sinkfill_yes;
        private RadioButton radioButton_sinkfill_no;
        private GroupBox groupBox_threshold;
        private Label label_threshold;
        private TextBox textBox_threshold;
        private Button button_language;
        private RadioButton radioButton2;
        private CheckBox checkBox_Save_SlopLength;
        private CheckBox checkBox_Save_SlopAngle;
        private CheckBox checkBox_Save_LengthFactor;
        private CheckBox checkBox_Save_SlopFactor;
        private CheckBox checkBox_Save_LSFactor;
        private CheckBox checkBox_Save_SelectAll;
        private GroupBox groupBox_save;
        private GroupBox groupBox_Cumulated_Way;
        private RadioButton radioButton_Cumulated_Total;
        private RadioButton radioButton_Cumulated_Max;
        private GroupBox groupBox_modeling;
        private RadioButton radioButton_model_CSLE;
        private RadioButton radioButton_model_RUSLE;
        private RadioButton radioButton3;
        private RadioButton radioButton1;
    }
    }

 
