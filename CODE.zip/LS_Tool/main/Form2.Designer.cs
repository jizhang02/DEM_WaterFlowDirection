﻿namespace LengthSlope
{
    partial class Form2
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.progressBar = new System.Windows.Forms.ProgressBar();
            this.progressTextBox = new System.Windows.Forms.Label();
            this.button_form2_ok = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // progressBar
            // 
            this.progressBar.Location = new System.Drawing.Point(12, 53);
            this.progressBar.Maximum = 28;
            this.progressBar.Name = "progressBar";
            this.progressBar.Size = new System.Drawing.Size(433, 15);
            this.progressBar.TabIndex = 2;
            // 
            // progressTextBox
            // 
            this.progressTextBox.AutoSize = true;
            this.progressTextBox.Location = new System.Drawing.Point(10, 30);
            this.progressTextBox.Name = "progressTextBox";
            this.progressTextBox.Size = new System.Drawing.Size(0, 12);
            this.progressTextBox.TabIndex = 3;
            // 
            // button_form2_ok
            // 
            this.button_form2_ok.Location = new System.Drawing.Point(171, 89);
            this.button_form2_ok.Name = "button_form2_ok";
            this.button_form2_ok.Size = new System.Drawing.Size(90, 25);
            this.button_form2_ok.TabIndex = 4;
            this.button_form2_ok.Text = "&OK";
            this.button_form2_ok.UseVisualStyleBackColor = true;
            this.button_form2_ok.Visible = false;
            this.button_form2_ok.Click += new System.EventHandler(this.button1_Click);
            // 
            // Form2
            // 
            this.AcceptButton = this.button_form2_ok;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(452, 138);
            this.Controls.Add(this.button_form2_ok);
            this.Controls.Add(this.progressTextBox);
            this.Controls.Add(this.progressBar);
            this.ForeColor = System.Drawing.SystemColors.ControlText;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Form2";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "正在计算 Calculating Now";
            this.Load += new System.EventHandler(this.Form2_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        public System.Windows.Forms.ProgressBar progressBar;
        public System.Windows.Forms.Label progressTextBox;
        public System.Windows.Forms.Button button_form2_ok;
    }
}