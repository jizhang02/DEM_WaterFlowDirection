using System;
using System.Collections.Generic;
using System.Text;

namespace LengthSlope
{
    class Helponline
    {


    }
}
