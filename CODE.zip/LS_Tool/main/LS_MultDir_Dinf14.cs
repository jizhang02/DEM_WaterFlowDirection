//20141025����ҵ������������Dinf�㷨�ļ���

using System;
using System.Collections.Generic;
using System.Text;
using System.IO;

using System.Collections;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Data;

//using System.Drawing;
//using System.Drawing.Printing;
using System.Windows.Forms;
using System.Threading;
using System.Diagnostics;
namespace LengthSlope
{
    class LS_MultDir_DINF14Class
    {
        private bool debug = true;

        public void LSBegin(string inPath, string outPath, string prefix, bool ifRepair, 
            float lessThan5, float above5, bool unit, bool fillWay, bool flowcut, 
            bool fillsink, float threshold, bool CumulatedWay, 
            int RUSLE_CSLE, bool Channel_Consider, bool ExportAll, CheckBox[] MyCheckBox, Object form)
        {
            Form1 form1 = form as Form1;
            form1.form2.progressTextBox.Text = "׼���������� Loading DEM����";
            form1.form2.progressBar.Visible = true;
            form1.form2.progressBar.Value = 0;
            form1.form2.progressTextBox.Update();
            form1.form2.progressBar.Value++;

            DemData demData = new DemData();
            demData.fillWay = fillWay;
            demData.inPath = inPath;
            demData.flowcut = flowcut;
            demData.threshold = threshold;

            //��������Դ������Ϣ
            form1.form2.progressTextBox.Text = "��ȡ����Դ������Ϣ Reading basic information����";
            form1.form2.progressTextBox.Update();
            LoadDEMHeaderData(demData.inPath, ref demData);
            demData.preOutPath = outPath + prefix;

            demData.scf_lt5 = lessThan5;
            demData.scf_ge5 = above5;

            demData.meterOrFeet = unit;
            demData.ifRepair = ifRepair;// �Ƿ��޸�
            string logFilePath = String.Concat(outPath, "\\", prefix, "LogFile.txt");//��־�ļ�·��
            //����־�ļ�
            OpenLogFile(logFilePath);
            LogStartUp(demData);
            LogDemHeader(demData);
            form1.form2.progressBar.Value++;
            form1.form2.progressTextBox.Text = "�����ڴ�ռ� Appling memery......";
            form1.form2.progressTextBox.Update();

            FreeMemory();

            //���ٿռ�
            float[] demMap = new float[demData.imagNrows * demData.imagNcols];
            bool[] noDataMap = new bool[demData.imagNrows * demData.imagNcols];
            //Console.WriteLine("3");
            //���ٿռ�ʧ�ܣ�д����־�ļ������˳�����
            if (demMap.Length == 0)
                LogFailedExit(demData.imagNcols * demData.imagNrows, 4, "float", "DEM_Map"); //д����־�ļ�
            if (noDataMap.Length == 0)
                LogFailedExit(demData.imagNcols * demData.imagNrows, 1, "bool", "NODATA Grid Map"); //д����־�ļ�

            //�������������Ϊ��ֵ
            #region FillAroundCell
            {
                int c = 0;
                for (int i = 0; i < demData.imagNrows; i++)
                    for (int j = 0; j < demData.imagNcols; j++)
                    {
                        noDataMap[c] = true;
                        if (i < 2 || i > (demData.imagNrows - 3))
                        {
                            c = i * demData.imagNcols + j;
                            if (demData.noDateType)
                            {
                                demMap[c] = demData.floatNoData;
                            }
                            else
                            {
                                demMap[c] = demData.intNoData;
                            }
                            // zhangjie.2010.07.26ע������
                            // noDataMap[c] = true;//�����ֵ��
                        }
                        else
                        {
                            //���ǵ�һ�к����һ��
                            if (j < 2 || (j > demData.imagNcols - 3))
                            {
                                c = i * demData.imagNcols + j;
                                if (demData.noDateType)
                                {
                                    demMap[c] = demData.floatNoData;
                                }
                                else
                                {
                                    demMap[c] = demData.intNoData;
                                }
                                // zhangjie.2010.07.26ע������
                                // noDataMap[c] = true;
                            }
                        }
                        // zhangjie.2010.07.26ע������������
                        // noDataMap[c] = true;
                    }
            }
            #endregion
            form1.form2.progressTextBox.Text = "��ȡDEM Checking DEM......";
            form1.form2.progressTextBox.Update();
            form1.form2.progressBar.Value++;


            ReadDEMElevations(ref demData, ref demMap, ref noDataMap); //��ȡDEM
            FreeMemory();

            //Console.WriteLine("4");
            form1.form2.progressTextBox.Text = "�˲�DEM���������� Checking value types......";
            form1.form2.progressTextBox.Update();
            form1.form2.progressBar.Value++;
            demData.floatOrInt = VerifyDEMDataType(ref demData); //��ʵDEM����������
            LogDataTypeDEM(demData); // ����������д����־�ļ�

            form1.form2.progressTextBox.Text = "����ڲ���ֵ��Fill nodata area......";
            form1.form2.progressTextBox.Update();
            form1.form2.progressBar.Value++;

            FreeMemory();
            //����ڲ���ֵ��
            LocateInteriorNODATACells(demData, ref noDataMap, ref demMap);

            if (ExportAll)//if (demData.ifExcessFile)            
            {
                form1.form2.progressBar.Value++;
                form1.form2.progressBar.Maximum++;
                form1.form2.progressTextBox.Text = "��д�޶����DEM���� Rewriting DEM......";
                form1.form2.progressTextBox.Update();

                string pathFileName = String.Concat(outPath, "\\", prefix, "orig_dem.txt");
                if (debug)
                {
                    WriteDEMGrid(pathFileName, demData, noDataMap, demMap); //��һ���ļ���дDEM
                }
                LogWroteDEM(pathFileName); //д��־�ļ�
            }

            form1.form2.progressTextBox.Text = "�ݵ���䣬������Χ8����Filling sinks......";
            form1.form2.progressTextBox.Update();
            form1.form2.progressBar.Value++;

            FreeMemory();

            //s�����Ƿ�����ݵ���� 
            bool sf = true;
            bool af = true;
            if (fillsink == false)
            {
                sf = false;
                af = false;
            }
            while (sf && af)
            {
                sf = FillSinks(demData, ref noDataMap, ref demMap); //����ݵ���Χ8����
                af = AnnulusFill(demData, ref noDataMap, ref demMap); //��价����Χ16����
                //Debug.WriteLine("sf = " + sf.ToString() + "af = " + af.ToString());
            }

            form1.form2.progressTextBox.Update();
            form1.form2.progressBar.Value++;

            if (ExportAll)//if (demData.ifExcessFile)            
            {
                form1.form2.progressTextBox.Text = "д������DEM����Writing new DEM......";
                form1.form2.progressTextBox.Update();
                form1.form2.progressBar.Value++;
                form1.form2.progressBar.Maximum++;
                string demFill = String.Concat(outPath, "\\", prefix, "DemFill.txt");
                if (debug) 
                {
                    WriteDEMGrid(demFill, demData, noDataMap, demMap); //д������DEM����
                }
                LogWroteDEM(demFill); //д��־�ļ�
            }
            form1.form2.progressBar.Value++;
            form1.form2.progressTextBox.Text = "�����ڴ�ռ�Applying for new memery......";
            form1.form2.progressTextBox.Update();

            FreeMemory();

            //int Aspect = 0;//ˮ���ķ���
            float[] slopeAng = new float[demData.imagNcols * demData.imagNrows];//�¶�
            if (slopeAng == null)
                LogFailedExit(demData.imagNcols * demData.imagNrows, 4, "float", "slope angle");
            int[] slopeAspect = new int[demData.imagNcols * demData.imagNrows];//����
            if (slopeAspect == null)
                LogFailedExit(demData.imagNcols * demData.imagNrows, 4, "float", "slope aspect");
            float[] slopeLen = new float[demData.imagNcols * demData.imagNrows];//�³�
            if (slopeLen == null)
                LogFailedExit(demData.imagNcols * demData.imagNrows, 4, "float", "slope Lenth");
            byte[] inFlow = new byte[demData.imagNcols * demData.imagNrows];//����
            if (inFlow == null)
                LogFailedExit(demData.imagNcols * demData.imagNrows, 1, "FLOWTYPE", "inflow direction");
            // zhangjie.2010.06.14ע��
            // byte[] outFlow = new byte[demData.imagNcols * demData.imagNrows];//����
             //if (outFlow == null)
             // LogFailedExit(demData.imagNcols * demData.imagNrows, 1, "FLOWTYPE", "outflow direction");
            //  bool[] flowFlag = new bool[demData.imagNcols * demData.imagNrows];//����
            // if (flowFlag == null)
            //  LogFailedExit(demData.imagNcols * demData.imagNrows, 1, "bool", "flow cutoff rrid map");

            // zhangjie 2010.06.14 Ϊ����Ȩ�ط���ռ�
            OutFlow[] outFlow = new OutFlow[demData.imagNcols * demData.imagNrows];
            if (outFlow == null)
                LogFailedExit(demData.imagNcols * demData.imagNrows, 1, "OutFlow", "outFlow weigth");

            form1.form2.progressBar.Value++;
            form1.form2.progressTextBox.Text = "�����ݽ��л���������Bufferring......";
            form1.form2.progressTextBox.Update();

            //��ʼ����������
            #region
            {
                int c = 0;
                for (int i = 0; i < demData.imagNrows; i++)
                    for (int j = 0; j < demData.imagNcols; j++)
                    {
                        c = i * demData.imagNcols + j;
                        if (i < 2 || i > (demData.imagNrows - 3))
                        {
                            slopeAng[c] = (float)0.0;
                            inFlow[c] = (byte)0;
                            // flowFlag[c] = false;
                        }
                        else if (j < 2 || j > (demData.imagNcols - 3))
                        {
                            slopeAng[c] = (float)0.0;
                            inFlow[c] = (byte)0;
                            // flowFlag[c] = false;
                        }
                        outFlow[c] = new OutFlow();
                    }
            }
            #endregion
            form1.form2.progressBar.Value++;
            form1.form2.progressTextBox.Text = "��ȡ�¶ȣ�Ȩֵ������Calculating slope angle, weight, slope aspect......";
            form1.form2.progressTextBox.Update();

            // zhangjie,2010.06.14�޸�
            // downSlope(demData, noDataMap, demMap, ref slopeAng, ref slopeLen, ref outFlow); //��ȡ�¶ȣ��³�������
            // zhangjie.2010.08.06 ʹ�á����ײ���Ȩ��֡�
            //�ź���2010.08.13ʹ�����׷�����ƽ��Ȩ���
            downAng(demData, noDataMap, demMap, ref slopeAng, ref slopeAspect, ref slopeLen); // �����¶�

            FreeMemory();

            if (flowcut == false)//���������ض�
            {
                downWeight(demData, noDataMap, demMap, ref outFlow, ref slopeAspect); // ����Ȩֵ
            }
            else//�������ض�
            {
                downWeight(demData, noDataMap, demMap, ref outFlow, ref slopeAng, flowcut);//flowcut������Ϊ�˺Ͳ����ǽضϵ�downweight�ĺ���������
                //�������
                form1.form2.progressTextBox.Text = "���ڻ�ȡ����Canculating channel networks......";
                form1.form2.progressTextBox.Update();
                form1.form2.progressBar.Value++;
                if (Channel_Consider)
                {
                    float[] ChannelNetworks = new float[demData.imagNcols * demData.imagNrows];
                    CalcChannelNetworks(demData, ref ChannelNetworks, outFlow, noDataMap);
                    //���������ݺ���ֵ���ص�Ȩ���ļ��У���������ʡ��������ռ�õĴ����ڴ�
                    RedownWeight(demData, threshold, ChannelNetworks, ref outFlow, noDataMap);//��������Ȩֵ
                    if (ExportAll)//if (demData.ifExcessFile)            
                    {
                        form1.form2.progressTextBox.Text = "д��������Saving channel netwoks data......";
                        form1.form2.progressTextBox.Update();
                        form1.form2.progressBar.Value++;
                        form1.form2.progressBar.Maximum++;
                        string Channel = String.Concat(outPath, "\\", prefix, "flowaccu.txt");
                        if (debug)
                        {
                            WriteDEMGrid(Channel, demData, noDataMap, ChannelNetworks); //д��������
                        }
                        LogWroteDEM(Channel); //д��־�ļ�
                    }
                    ChannelNetworks = new float[1];
                    ChannelNetworks = null;
                    FreeMemory();
                }
            }

            FreeMemory();

            if (ExportAll)//if (demData.ifExcessFile)            
            {
                // zhangjie,2010.06.15�ģ���ǰΪ����³�����Ϊ���Ȩֵ
                form1.form2.progressBar.Value++;
                form1.form2.progressBar.Maximum++;
                form1.form2.progressTextBox.Text = "дȨֵ�ļ�Saving weight data......";
                form1.form2.progressTextBox.Update();
                // ��Ȩֵ���
                string weight_filename = String.Concat(outPath, "\\", prefix, "weight.txt");
                if (debug)
                {
                    WriteWeightFile(weight_filename, ref demData, ref noDataMap, ref outFlow);
                }
                LogWroteDEM(weight_filename); //д��־�ļ�

                form1.form2.progressBar.Value++;
                form1.form2.progressBar.Maximum++;
                form1.form2.progressTextBox.Text = "д�¶��ļ�Saving slope angle data......";
                form1.form2.progressTextBox.Update();
                string slp_ang = String.Concat(outPath, "\\", prefix, "slp_ang.txt");
                //�򿪲�д�¶��ļ���Ȼ��ر�
                if (debug)
                {
                    WriteSlopeAngFile(slp_ang, demData, noDataMap, slopeAng);
                }
                //����0.5��0.7��λ�ã�
                form1.form2.progressBar.Value++;
                form1.form2.progressBar.Maximum++;
                form1.form2.progressTextBox.Text = "д�¶������ļ�Saving S factor data......";
                form1.form2.progressTextBox.Update();
                string slp_fac = String.Concat(outPath, "\\", prefix, "slp_fac.txt");
                if (debug)
                {
                    WriteSlopeFactorFile(slp_fac, demData, noDataMap, slopeAng); //д�¶�����
                }
                LogWroteDEM(slp_fac); //д��־�ļ�
            }

            FreeMemory();

            if (MyCheckBox[1].Checked && !ExportAll)
            {
                form1.form2.progressBar.Value++;
                form1.form2.progressBar.Maximum++;
                form1.form2.progressTextBox.Text = "д�¶��ļ�Saving slope angle data......";
                form1.form2.progressTextBox.Update();
                string slp_ang = String.Concat(outPath, "\\", prefix, "slp_ang.txt");
                if (debug)
                {
                    WriteSlopeAngFile(slp_ang, demData, noDataMap, slopeAng); //�򿪲�д�¶��ļ���Ȼ��ر�
                }
                LogWroteDEM(slp_ang); //д��־�ļ�
            }

            form1.form2.progressBar.Value++;
            form1.form2.progressTextBox.Text = "��������Calculating inflow......";
            form1.form2.progressTextBox.Update();

            FreeMemory();

            SetInFlowByWeigth(demData, ref noDataMap, ref outFlow, ref  inFlow);

            FreeMemory();

            // SetInFlow(demData, ref noDataMap, ref outFlow, ref inFlow); //��������
            //Console.WriteLine("6");
            if (ExportAll)//if (demData.ifExcessFile)            
            {
                form1.form2.progressBar.Value++;
                form1.form2.progressBar.Maximum++;
                form1.form2.progressTextBox.Text = "д��������Saving slope aspect......";
                form1.form2.progressTextBox.Update();
                string in_flow = String.Concat(outPath, "\\", prefix, "inflow.txt");
                if (debug)
                {
                    WriteDirectionArray(in_flow, ref demData, ref noDataMap, ref inFlow); //д��������
                }
                LogWroteDEM(in_flow); //д��־�ļ�
            }

            form1.form2.progressBar.Value++;
            form1.form2.progressTextBox.Text = "�����ڴ�ռ�Applying for new memory......";
            form1.form2.progressTextBox.Update();

            FreeMemory();

            float[] cumlen = new float[demData.imagNcols * demData.imagNrows];
            float[] inicumlen = new float[demData.imagNcols * demData.imagNrows];
            

            if (cumlen == null)
            {
                LogFailedExit(demData.imagNcols * demData.imagNrows, 4, "float", "cumulative Length"); //�����ڴ�ռ�ʧ��д��־
            }
            form1.form2.progressBar.Value++;
            form1.form2.progressTextBox.Text = "���û�����Bufferring......";
            form1.form2.progressTextBox.Update();
            //��Χ���
            #region FillAround
            {
                int c = 0;
                for (int i = 0; i < demData.imagNrows; i++)
                {
                    for (int j = 0; j < demData.imagNcols; j++)
                    {
                        c = i * demData.imagNcols + j;
                        if (i < 2 || i > demData.imagNrows - 3)
                        {
                            cumlen[c] = (float)0.0;
                        }
                        else if (j < 2 || j > demData.imagNcols - 3)
                        {
                            cumlen[c] = (float)0.0;
                        }
                    }
                }
            }
            for (int i = 2; i < demData.imagNrows - 2; i++)
            {
                for (int j = 2; j < demData.imagNcols - 2; j++)
                {

                    cumlen[i * demData.imagNcols + j] = inicumlen[i * demData.imagNcols + j] = slopeLen[i * demData.imagNcols + j];
                }
            }

            #endregion
            form1.form2.progressBar.Value++;
            form1.form2.progressTextBox.Text = "��ʼ���ۻ��³��ļ�Calculating cell slope length......";
            form1.form2.progressTextBox.Update();
            // zhangjie,2010.06.16 �� 
            // InitCumulativeLength(demData, inFlow, outFlow, noDataMap, slopeLen, cumlen); //��ʼ���ۻ��³��ļ�
            // slopeLen = null;
            // zhangjie,2010.08.04��
            // �õ�����ķ��������ʼ�����ۼ��³�
            //InitCumulativeLength(demData, demMap, noDataMap, ref cumlen, ref inicumlen, inFlow, flowcut); 2014 9 21 wang chengye
            // InitCumulativeLength(demData, inFlow, outFlow, noDataMap, cumlen);
            //ǿ���ͷ��ڴ�

            //demMap = new float[1];
           // demMap = null;
            //inFlow = new byte[1];
            //inFlow = null;

            FreeMemory();

            if (ExportAll)//if (demData.ifExcessFile)            
            {
                form1.form2.progressBar.Value++;
                form1.form2.progressTextBox.Text = "д��ʼ���ۻ��³��ļ�Saving cell slope length......";
                form1.form2.progressTextBox.Update();
                form1.form2.progressBar.Maximum++;

                string init_len = String.Concat(outPath, "\\", prefix, "init_len.txt");
                if (debug)
                {
                    WriteSlopeLenFile(init_len, ref demData, ref noDataMap, ref slopeLen); //д�³��ļ�
                }
                LogWroteDEM(init_len); //д��־�ļ�
            }

            form1.form2.progressBar.Value++;
            form1.form2.progressTextBox.Text = "�����ۻ��³�Calculating slope length......";
            form1.form2.progressTextBox.Update();

            FreeMemory();
            CalcCumulativeLength(demData,demMap ,outFlow, noDataMap, ref cumlen, inicumlen); //������ۼ��³�!!!!!!!
            
            FreeMemory();

            if (MyCheckBox[2].Checked)
            {
                form1.form2.progressBar.Value++;
                form1.form2.progressTextBox.Text = "д�ۻ��³��ļ�Saving slope length......";
                form1.form2.progressTextBox.Update();
                form1.form2.progressBar.Maximum++;
                string slp_len = String.Concat(outPath, "\\", prefix, "slp_len.txt");
                if (debug)
                {
                    WriteSlopeLenFile(slp_len, ref demData, ref noDataMap, ref cumlen); //д�³��ļ�
                }
                LogWroteDEM(slp_len); //д��־�ļ�
            }
            outFlow = new OutFlow[1];
            outFlow = null;
            FreeMemory();


            form1.form2.progressBar.Value++;
            form1.form2.progressTextBox.Text = "�����ڴ�ռ�Applying for new memory......";
            form1.form2.progressTextBox.Update();
            //20110129ȥ��Ӣ��ת��
            //float[] slp_lgth_ft = new float[demData.imagNcols * demData.imagNrows];
            //if (slp_lgth_ft == null)
            //{
            //    LogFailedExit(demData.imagNcols * demData.imagNrows, 4, "float", "cumulative Length in Feet");
            //}
            if (!demData.meterOrFeet)
            {
                form1.form2.progressTextBox.Text = "���е�λת��......";
                form1.form2.progressTextBox.Update();
                form1.form2.progressBar.Value++;
                form1.form2.progressBar.Maximum++;
                //20110129ȥ��Ӣ��ת��
                //ConvertLengthToFeet(demData, cumlen, slp_lgth_ft); //��ǰֵ����0.3048�ı任meter->feet�ı仯
                //if(ExportAll)
                if (demData.ifExcessFile)
                {
                    form1.form2.progressTextBox.Text = "д�³�(feet)......";
                    form1.form2.progressTextBox.Update();
                    form1.form2.progressBar.Value++;
                    form1.form2.progressBar.Maximum++;
                    //20110129ȥ��Ӣ��ת��
                    //string slp_in_ft = String.Concat(outPath, "\\", prefix, "slp_in_ft.txt");
                    //WriteSlopeLenFeet(slp_in_ft, demData, noDataMap, slp_lgth_ft); //д�³�����λfeet��
                    //LogWroteDEM(slp_in_ft); //д��־�ļ�
                }
                //cumlen = null;
            }
            FreeMemory();

            float[] ruslel = new float[1];
            if (MyCheckBox[4].Checked || MyCheckBox[5].Checked)
            {
                form1.form2.progressTextBox.Text = "�����ڴ�ռ�(L)Applying for new memory......";
                form1.form2.progressTextBox.Update();
                form1.form2.progressBar.Value++;

                ruslel = new float[demData.imagNcols * demData.imagNrows];
                if (ruslel == null)
                {
                    if (RUSLE_CSLE == 1)
                        LogFailedExit(demData.imagNcols * demData.imagNrows, 4, "float", "CSLE L "); //�����ڴ浥Ԫʧ�ܺ�д��־�ļ�
                    else
                        LogFailedExit(demData.imagNcols * demData.imagNrows, 4, "float", "RUSLE L ");

                }
                form1.form2.progressTextBox.Text = "���û�����Bufferring......";
                form1.form2.progressTextBox.Update();
                form1.form2.progressBar.Value++;
                //��Χ��ֵ
                #region
                {
                    int c = 0;
                    for (int i = 0; i < demData.imagNrows; i++)
                        for (int j = 0; j < demData.imagNcols; j++)
                        {
                            c = i * demData.imagNcols + j;
                            if (i < 2 || i > demData.imagNrows - 3)
                                ruslel[c] = (float)0.0;
                            else if (j < 2 || j > demData.imagNcols - 3)
                                ruslel[c] = (float)0.0;
                        }
                }
                #endregion
                if (!demData.meterOrFeet)
                {
                    form1.form2.progressTextBox.Text = "����(feet)......";
                    form1.form2.progressTextBox.Update();
                    form1.form2.progressBar.Value++;
                    //20110129ȥ��Ӣ��ת��
                    //Calculate_CLSE_L_Feet(demData, slopeAng, slp_lgth_ft, ruslel); //����rusle(feet)
                }
                else
                {
                    form1.form2.progressTextBox.Text = "�����³�����Calculating L factor......";
                    form1.form2.progressTextBox.Update();
                    form1.form2.progressBar.Value++;
                    Calculate_L(demData, slopeAng, cumlen, ruslel, RUSLE_CSLE); //����rusle(meter)
                }
                cumlen = new float[0];
                cumlen = null;
                FreeMemory();

                form1.form2.progressTextBox.Text = "д�³������ļ�Saving L factor......";
                form1.form2.progressTextBox.Update();
                form1.form2.progressBar.Value++;
                form1.form2.progressBar.Maximum++;
                string rusle_l;
                if (RUSLE_CSLE == 1)
                    rusle_l = String.Concat(outPath, "\\", prefix, "CSLE_L.txt");
                else
                    rusle_l = String.Concat(outPath, "\\", prefix, "RUSLE_L.txt");
                if (debug)
                {
                    Write_FloatGrid(rusle_l, demData, noDataMap, ruslel); //��rusle1����Ϊ������
                }
                LogWroteDEM(rusle_l); //д��־�ļ�
            }
            //Console.WriteLine("8");            
            float[] rusles = new float[1];
            FreeMemory();
            form1.form2.progressBar.Value++;
            form1.form2.progressTextBox.Text = "�����ڴ�ռ�(S)Applying for new memory......";
            form1.form2.progressTextBox.Update();
            if (MyCheckBox[3].Checked || MyCheckBox[5].Checked)
            {             

                rusles = new float[demData.imagNcols * demData.imagNrows];
                if (rusles == null)
                {
                    if (RUSLE_CSLE == 1)
                        LogFailedExit(demData.imagNcols * demData.imagNrows, 4, "float", "CLSE S "); //�����ڴ�ռ�ʧ��д��־
                    else
                        LogFailedExit(demData.imagNcols * demData.imagNrows, 4, "float", "RUSLE S "); //�����ڴ�ռ�ʧ��д��־
                }
                form1.form2.progressBar.Value++;
                form1.form2.progressTextBox.Text = "���û�����Bufferring......";
                form1.form2.progressTextBox.Update();
                //��Χ���
                #region
                {
                    int c = 0;
                    for (int i = 0; i < demData.imagNrows; i++)
                        for (int j = 0; j < demData.imagNcols; j++)
                        {
                            c = i * demData.imagNcols + j;
                            if (i < 2 || i > demData.imagNrows - 3)
                                rusles[c] = (float)0.0;
                            else if (j < 2 || j > demData.imagNcols - 3)
                                rusles[c] = (float)0.0;
                        }
                }
                #endregion
                form1.form2.progressBar.Value++;
                form1.form2.progressTextBox.Text = "�����¶�����Calculating S factor......";
                form1.form2.progressTextBox.Update();
                Calculate_S(demData, slopeAng, rusles, RUSLE_CSLE); //
                //ǿ���ͷ��ڴ�
                slopeAng = new float[0];
                slopeAng = null;
                FreeMemory();

                form1.form2.progressTextBox.Text = "д�¶������ļ�Saving S factor......";
                form1.form2.progressTextBox.Update();
                form1.form2.progressBar.Value++;
                form1.form2.progressBar.Maximum++;
                string rusle_s;
                if (RUSLE_CSLE == 1)
                    rusle_s = String.Concat(outPath, "\\", prefix, "CSLE_S.txt");
                else
                    rusle_s = String.Concat(outPath, "\\", prefix, "RUSLE_S.txt");
                if (debug)
                {
                    Write_FloatGrid(rusle_s, demData, noDataMap, rusles); //��rusle1����Ϊ������
                }
                LogWroteDEM(rusle_s); //д��־�ļ�
            }
            FreeMemory();

            form1.form2.progressBar.Value++;
            form1.form2.progressTextBox.Text = "�����ڴ�ռ�Applying for new memory......";
            form1.form2.progressTextBox.Update();
            if (MyCheckBox[5].Checked)
            {                
                float[] ruslels = new float[demData.imagNcols * demData.imagNrows];

                if (ruslels == null)
                {
                    if (RUSLE_CSLE == 1)
                        LogFailedExit(demData.imagNcols * demData.imagNrows, 4, "float", "CSLE LS "); //�����ڴ�ռ�ʧ��д��־
                    else
                        LogFailedExit(demData.imagNcols * demData.imagNrows, 4, "float", "RUSLE LS ");
                }
                form1.form2.progressBar.Value++;
                form1.form2.progressTextBox.Text = "���û�����Bufferring......";
                form1.form2.progressTextBox.Update();

                //��Χ���
                #region
                {
                    int c = 0;
                    for (int i = 0; i < demData.imagNrows; i++)
                        for (int j = 0; j < demData.imagNcols; j++)
                        {
                            c = i * demData.imagNcols + j;
                            if (i < 2 || i > demData.imagNrows - 3)
                                ruslels[c] = (float)0.0;
                            else if (j < 2 || j > demData.imagNcols - 3)
                                ruslels[c] = (float)0.0;
                        }
                }
                #endregion
                form1.form2.progressTextBox.Text = "�����¶��³�Calculating LS factor......";
                form1.form2.progressTextBox.Update();
                form1.form2.progressBar.Value++;

                Calculate_CSLE_LS2(demData, ruslel, rusles, ruslels); //��rusle2����
                ruslel = new float[0];
                ruslel = null;
                rusles = new float[0];
                rusles = null;
                FreeMemory();

                form1.form2.progressTextBox.Text = "д�¶��³��ļ�Saving S factor......";
                form1.form2.progressTextBox.Update();
                form1.form2.progressBar.Value++;
                string ruslels2;
                if (RUSLE_CSLE == 1)
                    ruslels2 = String.Concat(outPath, "\\", prefix, "CSLE_LS.txt");
                else
                    ruslels2 = String.Concat(outPath, "\\", prefix, "RUSLE_LS.txt");
                if (debug)
                {
                    Write_LS2(ruslels2, demData, noDataMap, ruslels);
                }
                LogWroteDEM(ruslels2);
                form1.form2.progressBar.Value++;
                form1.form2.progressTextBox.Text = "�������Calculation Over";
                form1.form2.progressTextBox.Update();
                Debug.WriteLine("form1.form2.progressBar.Value = " + form1.form2.progressBar.Value);
                Log_CLSE_LSWarning(RUSLE_CSLE);
            }
            CloseLogFile();
            if (ExportAll == false)
            {
                DeleteLogFile(logFilePath);
            }
            form1.form2.progressBar.Value = form1.form2.progressBar.Maximum;
            FreeMemory();
        }

        //##############################################

        //                   InData

        //##############################################
        #region InData
        private StreamReader demFile;
        private int BarMaxNum;//���ڴ�Ž��������ֵ  BarMaxNum = demData.nrows;

        public void LoadDEMHeaderData(string inFileName, ref DemData demData)
        {
            //�����ļ��Ƿ����
            if (!File.Exists(inFileName))
            {
                throw (new FileNotFoundException(inFileName + " does not exist!"));
            }
            string line;
            demFile = new StreamReader(inFileName);

            //��ֵncols
            line = demFile.ReadLine().Trim();
            Debug.WriteLine(line);
            int tmpLastIndex = line.LastIndexOf(' ');
            demData.ncols = int.Parse(line.Substring(tmpLastIndex + 1));

            //��ֵnrows
            line = demFile.ReadLine().Trim();
            tmpLastIndex = line.LastIndexOf(' ');//����ֵΪ��������ֵ
            demData.nrows = int.Parse(line.Substring(tmpLastIndex + 1));
            BarMaxNum = demData.nrows;
            Debug.WriteLine(line);
            //��ֵxllcorner
            line = demFile.ReadLine().Trim();
            tmpLastIndex = line.LastIndexOf(' ');
            demData.xllcorner = double.Parse(line.Substring(tmpLastIndex + 1));
            Debug.WriteLine(line);
            //��ֵyllcorner
            line = demFile.ReadLine().Trim();
            tmpLastIndex = line.LastIndexOf(' ');
            demData.yllcorner = double.Parse(line.Substring(tmpLastIndex + 1));
            Debug.WriteLine(line);
            //��ֵcellsize
            line = demFile.ReadLine().Trim();
            tmpLastIndex = line.LastIndexOf(' ');
            char[] numPart = line.Substring(tmpLastIndex + 1).ToCharArray();//��դ��ĳ���ת�����ַ�����Ŀ����Ϊ���ж��Ƿ�Ϊ������
            Debug.WriteLine(line);
            demData.cellType = false;
            bool tmpFlag = false;
            //ͨ��'.'���ж��Ƿ�Ϊ������
            for (int i = 0; i < numPart.Length; i++)
            {
                if (numPart[i] == '.')
                {
                    demData.cellType = true;
                }
            }
            demData.cellSize = float.Parse(line.Substring(tmpLastIndex + 1));

            //��ֵNOTDATA
            line = demFile.ReadLine().Trim();
            tmpLastIndex = line.LastIndexOf(' ');
            numPart = line.Substring(tmpLastIndex + 1).ToCharArray();//��ͬ�ķ���������
            for (int i = 0; i < numPart.Length; i++)
            {
                if (numPart[i] == '.')
                {
                    tmpFlag = true;
                }
            }
            demData.noDateType = tmpFlag;
            demData.floatNoData = float.Parse(line.Substring(tmpLastIndex + 1));
            Debug.WriteLine(demData.floatNoData);

            demData.intNoData = (int)demData.floatNoData;//09.12.01�޸�
            //demData.intNoData = int.Parse(line.Substring(tmpLastIndex + 1));
            demData.imagNcols = demData.ncols + 4;
            demData.imagNrows = demData.nrows + 4;

            /*demData.F_DEM_Flag = tmpFlag;
            demData.NODATA = float.Parse(line.Substring(tmpLastIndex + 1));
            demData.F_NODATA = float.Parse(line.Substring(tmpLastIndex + 1));
            demData.D_NODATA = int.Parse(line.Substring(tmpLastIndex + 1));*/
        }

        public void ReadDEMElevations(ref DemData demData, ref float[] demMap, ref bool[] noDataMap)
        {
            string[] tmp = new string[demData.ncols];
            float[] tmp1 = new float[demData.nrows * demData.ncols];
            //int mark = 0;
            //for (int i = 0; i < demData.nrows; i++)
            //{
            //    tmp = demFile.ReadLine().Split(' ');//�������txt��head����ʣ�µĲ���
            //    for (int j = 0; j < demData.ncols; j++)
            //    {
            //        tmp1[mark] = float.Parse(tmp[j]);
            //        mark++;
            //    }
            //}
            /****************************/
            string aString;
            int count = 0;
            while ((aString = demFile.ReadLine()) != null)
            {
                string[] sArray = aString.Split(' ');
                int i = 0;
                while (i < sArray.Length)
                {
                    //Debug.WriteLine("the string:" + sArray [i]);
                    //tmp1[count] = float.Parse(sArray[i]);
                    if (sArray[i] != "")
                    {
                        tmp1[count] = Convert.ToSingle(sArray[i]);
                        count++;
                        i++;
                    }
                    else
                    {
                        i++;
                    }

                }
                sArray = null;
                if (count == demData.nrows * demData.ncols)
                    break;
                //Debug.WriteLine(count.ToString());
                //Debug.WriteLine(demData.ncols * demData.nrows);

            }
            /****************************/
            int real = 0;
            int imag = 0;
            for (int i = 2; i < demData.imagNrows - 2; i++)
                for (int j = 2; j < demData.imagNcols - 2; j++)
                {
                    imag = i * demData.imagNcols + j;
                    real = (i - 2) * demData.ncols + (j - 2);

                    if (tmp1[real] != demData.floatNoData)
                        demMap[imag] = tmp1[real];
                    else
                        demMap[imag] = (float)32767.0;//Դ�ļ��д˴���32767����#GlobalConstants��limit.h��,����ô���⣿��
                    noDataMap[imag] = (tmp1[real] == demData.floatNoData);
                    if (demMap[imag] < 0.0)
                    {
                        LogNegativeDEM(i - 2, j - 2, tmp1[real]);
                    }
                }
            tmp1 = null;
            tmp = null;
            demFile.Close();

            FreeMemory();
        }

        public bool VerifyDEMDataType(ref DemData demData)
        {
            StreamReader demFileBack = new StreamReader(demData.inPath);
            //��ȡ���У��չ��ļ�����ʼ����
            demFileBack.ReadLine();
            demFileBack.ReadLine();
            demFileBack.ReadLine();
            demFileBack.ReadLine();
            demFileBack.ReadLine();
            string aString;
            bool fpFlag = false;
            int tPrecision = 0;
            demData.dataPrecision = 0;

            while ((aString = demFileBack.ReadLine()) != null)
            {
                string[] sArray = aString.Split(' ');
                int j = 0;
                while (j < sArray.Length)
                {
                    char[] array = sArray[j].ToCharArray();
                    for (int i = 0; i < array.Length; i++)
                    {

                        tPrecision = 0;
                        if (array[i] == '.')
                        {
                            fpFlag = true;
                            //tPrecision = array.Length - i-2;
                            tPrecision = array.Length - i - 1;
                            if (tPrecision > demData.dataPrecision)
                                demData.dataPrecision = tPrecision;
                            break;
                        }
                    }
                    j++;

                }
                sArray = null;
            }

            demFileBack.Close();
            demFileBack = null;
            FreeMemory();

            return fpFlag;
        }
        #endregion

        //##############################################

        //                OutData

        //##############################################

        #region OutData
        private StreamWriter sw;
        private StreamWriter fp;
        public void OpenLogFile(string filename)
        {
            sw = new StreamWriter(filename);
        }
        public void DeleteLogFile(string filename)
        {
            if (File.Exists(filename))
            {
                File.Delete(filename);
            }
        }
        public void LogStartUp(DemData dd)
        {
            sw.WriteLine();
            sw.WriteLine("User Selected options:");
            sw.WriteLine("  DEM DATA file name:        {0}", dd.inPath);
            sw.WriteLine("  Output path prefix:        {0}", dd.preOutPath);
            if (dd.meterOrFeet)
                sw.WriteLine("  DEM elevation units:       Meters");
            else
                sw.WriteLine("  DEM elevation units:       Feet");
            if (dd.ifExcessFile)//�Ƿ����ɹ����ļ�
                sw.WriteLine("  Write intermediate files:  YES");
            else
                sw.WriteLine("  Write intermediate files:  NO");

            if (dd.flowcut)
            {
                sw.WriteLine("  Slope cutoff factors");
                sw.WriteLine("    Less than 5 percent:     {0}", dd.scf_lt5);
                sw.WriteLine("    Greater equal 5 percent: {0}", dd.scf_ge5);
            }
            else
            {
                sw.WriteLine("  Without considering slope cutoff");
            }
            if (dd.threshold > 0)
                sw.WriteLine("  Define Channels as pixels an accumulated area threshold: {0} Square meters", dd.threshold);
            else
                sw.WriteLine("  Without defined Channels");

            if (dd.ifRepair)
                sw.WriteLine("  Interior NODATA cells:     Fill if possible");
            else
                sw.WriteLine("  Interior NODATA cells:     Do not attempt to fill");

            if (dd.ifRepair)
                sw.WriteLine("  Interior NODATA clusters:  Process anyway!");
            else
                sw.WriteLine("  Interior NODATA clusters:  Terminate program");
            if (dd.fillWay)
                sw.WriteLine("  Interior NODATA point:  fill with average value of around 8-cells");
            else
                sw.WriteLine("  Interior NODATA point:  fill with min value of around 8-cells");

        }
        public void LogDemHeader(DemData dd)
        {
            sw.WriteLine("Processing data for dem data set containing:");
            sw.WriteLine("  ncols          {0:d}", dd.ncols);
            sw.WriteLine("  nrows          {0:d}", dd.nrows);
            sw.WriteLine("  xllcorner      {0:f6}", dd.xllcorner);
            sw.WriteLine("  xllcorner      {0:f6}", dd.yllcorner);
            if (dd.cellType)
            {
                sw.WriteLine("  cellsize       {0:f4}", dd.cellSize);
            }
            else
            {
                sw.WriteLine("  cellsize       {0:d}", (int)dd.cellSize);
            }

            if (dd.noDateType)
            {
                sw.WriteLine("  DEM NODATA     {0:f1}", dd.floatNoData);
            }
            else
            {
                sw.WriteLine("  DEM NODATA     {0:d}", dd.intNoData);
            }
            sw.WriteLine("  Float NODATA   -9.9");
            sw.WriteLine("  Int NODATA     -9");
        }
        public void LogFailedExit(int elements, int size, string type, string str)
        {
            sw.WriteLine("Unable to allocate memory for a dynamic {0} array.", type);
            sw.WriteLine("Such an array would have [{0}] elements", elements);
            sw.WriteLine("That's over {0} megabytes of storage", elements * size / 1000000);
            sw.WriteLine("This array would have stored the {0} values", str);
            sw.WriteLine("A guess is that your machine need about a {0} megaByte pagefile", elements * 18 / 1000000);
            sw.WriteLine("to handle this dataset.  NOTE: This is an apporximate size.");
            sw.WriteLine("Program execution has been halted!");
            CloseLogFile();
            Environment.Exit(0);
        }
        public void LogNegativeDEM(int nrows, int ncols, float demValue)
        {
            sw.WriteLine("Warning, DEM file contains negative values - Check Logfile if not expected!");
            sw.WriteLine("Warning, DEM file contains negative value(s)!");
            sw.WriteLine("Unless your working with data containing elevations below sea level");
            sw.WriteLine("This indicates an anomaly in your DEM data which may require attention");
            sw.WriteLine("Isolated negative values surrounded by valid DEM values will be sink filled");
            sw.WriteLine("Isolated negative values surrounded by NODATA cells will be rewritten as NODATA");
            sw.WriteLine("The negative cell(s) and their values are shown below");
            sw.WriteLine("DEM Cell[{0}][{1}] contains a negative value of {2}", nrows, ncols, demValue);
        }
        public void LogDataTypeDEM(DemData dd)
        {
            if (dd.floatOrInt)
            {
                sw.WriteLine("DEM file contains floating point DEM data");
                sw.WriteLine("DEM file contains {0} places decimal precision", dd.dataPrecision);
            }
            else
                sw.WriteLine("DEM file contains integer DEM data");
        }

        public void LogFillPoint(int i, int j, float fillValue)
        {
            sw.WriteLine("Cell [{0}][{1}] is an internal surrounded by cells which have valid DEM data", i, j);
            sw.WriteLine("It has filled by value {0}", fillValue);
        }
        public void LogExit()
        {
            sw.WriteLine("Dem data has cluster ,your chose option \"AnyWayProcess\"is false\nProgram execution has been halted!");
            CloseLogFile();
            Environment.Exit(0);
        }
        public void LogInteriorCluster(int r, int c)
        {
            sw.WriteLine("Cell[{0}][{1}] appears to be clustered!", r, c);
        }
        public void LocateInteriorNODATACells(DemData demData, ref bool[] noDataMap, ref float[] demMap)
        {
            int i; // Loop Counter.
            int j; // Loop Counter.


            int c, n, w, e, s; // Center, North, West, East, South
            int nw, ne, se, sw; // NorthWest. NorthEast, SouthEast, SouthWest

            bool done = false; // Iterative flag   
            int rows = demData.imagNrows;
            int cols = demData.imagNcols;

            bool[] ex_nd = new bool[rows * cols]; // EXternal_Nodata boolean map array
            if (ex_nd == null)
            {
                LogFailedExit(rows * cols, 1, "bool", "Temp File to locate interior NODATA points");
            }
            //����������ֱ�Ӹ�ֵtrue����Ϊ����������û������ģ�������ֵ��Ϊfalse
            for (i = 0; i < rows; i++)
            {
                for (j = 0; j < cols; j++)
                {
                    if (i < 2 || i > rows - 3)
                    {
                        c = i * cols + j;
                        ex_nd[c] = true;
                    }
                    else if (j < 2 || j > cols - 3)
                    {
                        c = i * cols + j;
                        ex_nd[c] = true;

                    }
                    else
                    {
                        c = i * cols + j;
                        ex_nd[c] = false;
                    }
                }
            }

            int count = 0; // Counts number of interior NODATA cells
            while (!done)
            {
                done = true;
                for (i = 2; i < rows - 2; i++)
                    for (j = 2; j < cols - 2; j++)
                    {
                        c = i * cols + j;
                        //������
                        if (!noDataMap[c] || ex_nd[c])
                        {
                            continue;
                        }
                        nw = c - cols - 1;
                        n = c - cols;
                        ne = c - cols + 1;
                        w = c - 1;
                        e = c + 1;
                        sw = c + cols - 1;
                        s = c + cols;
                        se = c + cols + 1;

                        if (ex_nd[nw] || ex_nd[n] || ex_nd[ne] || ex_nd[w] ||
                            ex_nd[sw] || ex_nd[e] || ex_nd[se] || ex_nd[s])
                        {
                            ex_nd[c] = true;
                            done = false;
                        }
                    }
                for (i = rows - 3; i > 1; i--)
                    for (j = cols - 2; j > 1; j--)
                    {
                        c = i * cols + j;
                        if (!noDataMap[c] || ex_nd[c])
                        {
                            continue;
                        }
                        nw = c - cols - 1;
                        n = c - cols;
                        ne = c - cols + 1;
                        w = c - 1;
                        e = c + 1;
                        sw = c + cols - 1;
                        s = c + cols;
                        se = c + cols + 1;

                        if (ex_nd[nw] || ex_nd[n] ||
                            ex_nd[ne] || ex_nd[w] ||
                            ex_nd[sw] || ex_nd[e] ||
                            ex_nd[se] || ex_nd[s])
                        {
                            ex_nd[c] = true;
                            done = false;
                        }
                    }
            }
            for (i = 2; i < rows - 2; i++)
                for (j = 2; j < cols - 2; j++)
                    if (ex_nd[i * cols + j] != noDataMap[i * cols + j])
                    {
                        c = i * cols + j;
                        nw = c - cols - 1;
                        n = c - cols;
                        ne = c - cols + 1;
                        w = c - 1;
                        e = c + 1;
                        sw = c + cols - 1;
                        s = c + cols;
                        se = c + cols + 1;
                        if (ex_nd[nw] || ex_nd[n] ||
                            ex_nd[ne] || ex_nd[w] ||
                           ex_nd[sw] || ex_nd[e] ||
                           ex_nd[se] || ex_nd[s])
                        {
                            LogInteriorCluster(i - 2, j - 2);
                        }
                        if (demData.ifRepair)
                        {
                            if (demData.fillWay)
                            {
                                int count1 = 0;
                                float temp = 0.0f;
                                if (!noDataMap[n])
                                {
                                    temp = demMap[n];
                                    ++count1;
                                }
                                if (!noDataMap[ne])
                                {
                                    temp += demMap[ne];
                                    ++count1;
                                }
                                if (!noDataMap[e])
                                {
                                    temp += demMap[e];
                                    ++count1;
                                }
                                if (!noDataMap[se])
                                {
                                    temp += demMap[se];
                                    ++count1;
                                }
                                if (!noDataMap[s])
                                {
                                    temp += demMap[s];
                                    ++count1;
                                }
                                if (!noDataMap[sw])
                                {
                                    temp += demMap[sw];
                                    ++count1;
                                }
                                if (!noDataMap[w])
                                {
                                    temp += demMap[w];
                                    ++count1;
                                }
                                if (!noDataMap[nw])
                                {
                                    temp += demMap[nw];
                                    ++count1;
                                }
                                if (count1 != 0)
                                {
                                    demMap[c] = temp / count1;
                                    noDataMap[c] = false;
                                    LogFillPoint(i - 2, j - 2, demMap[c]);
                                }
                            }
                            else
                            {
                                float temp = 9999.0f;//��һ���ϴ��ֵ
                                if (!noDataMap[n])
                                    temp = demMap[n];
                                if (!noDataMap[ne])
                                    temp = (temp < demMap[ne] ? temp : demMap[ne]);
                                if (!noDataMap[e])
                                    temp = (temp < demMap[e] ? temp : demMap[e]);
                                if (!noDataMap[se])
                                    temp = (temp < demMap[se] ? temp : demMap[se]);
                                if (!noDataMap[s])
                                    temp = (temp < demMap[s] ? temp : demMap[s]);
                                if (!noDataMap[sw])
                                    temp = (temp < demMap[sw] ? temp : demMap[se]);
                                if (!noDataMap[w])
                                    temp = (temp < demMap[w] ? temp : demMap[w]);
                                if (!noDataMap[nw])
                                    temp = (temp < demMap[nw] ? temp : demMap[nw]);
                                demMap[c] = temp;
                                noDataMap[c] = false;
                                LogFillPoint(i - 2, j - 2, temp);
                            }
                        }
                        else
                        {
                            LogExit();
                        }
                        count++;
                    }
            //Console.WriteLine("count = {0}", count);
            if (count == 0)
            {
                LogVerifiedDEM();
            }
            else
            {
                LogVerifiedDEM1(count);
            }

            ex_nd = null;

            FreeMemory();
        }
        public void LogVerifiedDEM()
        {
            sw.Write("There are no interior NODATA cells ");
            sw.WriteLine("surrounded by valid DEM cells");
        }
        public void LogVerifiedDEM1(int count)
        {
            sw.WriteLine("There are {0} cell have filled !", count);
        }
        public void LogFileError(string fileNamepPath, string lff_action)
        {
            sw.WriteLine("An error occurred while opening file: {0}", fileNamepPath);

            if (lff_action[0] == 'r')
                sw.WriteLine("Unable to read from this file");
            if (lff_action[0] == 'r')
                sw.WriteLine("Program execution halted");
            if (lff_action[0] == 'w')
                sw.WriteLine("Unable to write to this file");
            if (lff_action[0] == 'w')
                sw.WriteLine("Program execution halted");
            Environment.Exit(0);
        }
        public void WriteDEMGrid(string fileNamePath, DemData dd, bool[] noDataMap, float[] demMap)
        {
            int i, j;
            int cols = dd.imagNcols;
            int rows = dd.imagNrows;

            fp = new StreamWriter(fileNamePath);

            if (fp == null) // Handle error opening file
                LogFileError(fileNamePath, "w");

            fp.WriteLine("ncols         {0}", dd.ncols);
            fp.WriteLine("nrows         {0}", dd.nrows);
            fp.WriteLine("xllcorner     {0:f6}", dd.xllcorner);
            fp.WriteLine("yllcorner     {0:f6}", dd.yllcorner);
            if (dd.cellType)
                fp.WriteLine("cellsize      {0:f4}", dd.cellSize);
            else
                fp.WriteLine("cellsize      {0}", (int)dd.cellSize);

            fp.WriteLine("NODATA_value  {0}", dd.intNoData);
            int c = 0;
            for (i = 2; i < rows - 2; i++)
            {
                for (j = 2; j < cols - 2; j++)
                {
                    c = i * cols + j;
                    if (noDataMap[c])
                    {
                        fp.Write("{0} ", dd.intNoData);
                    }
                    else
                    {
                        if (dd.floatOrInt)
                        {
                            if (dd.dataPrecision == 1)
                                fp.Write("{0:f1} ", demMap[c]);
                            else if (dd.dataPrecision == 2)
                                fp.Write(" {0:f2}", demMap[c]);
                            else
                                fp.Write("{0:f3} ", demMap[c]);
                        }
                        else
                        {
                            fp.Write("{0} ", (int)demMap[c]);
                        }
                    }
                }
                fp.WriteLine();
            }
            fp.Flush();
            fp.Close();

            FreeMemory();
        }

        bool Toggle = true;
        public void LogFill(int i, int j, int precision, float old, float min)
        {
            bool flag;
            bool start = true;
            if (start)
            {
                flag = true;
                start = false;
            }
            else
                flag = Toggle;
            if (flag)
            {
                if (precision == 0)
                    sw.Write("Cell[{0}][{1}] with a value of {2}", i, j, (int)old);
                else
                    if (precision == 1)
                        sw.Write("Cell[{0}][{1}] with a value of {2:f1}", i, j, old);
                    else if (precision == 2)
                        sw.Write("Cell[{0}][{1}] with a value of {2:f2}", i, j, old);
                    else
                        sw.Write("Cell[{0}][{1}] with a value of {2:f3}", i, j, old);


                if (precision == 0)
                    sw.WriteLine(" was sink filled to {0}", min);
                else if (precision == 1)
                    sw.WriteLine(" was sink filled to {0:f1}", min);
                else if (precision == 2)
                    sw.WriteLine(" was sink filled to {0:f2}", min);
                else
                    sw.WriteLine(" was sink filled to {0:f3}", min);

                Toggle = false;
            }
            else
            {
                if (precision == 0)
                    sw.WriteLine("[{0}][{1}], {2}, {3}", i, j, (int)old, min)
                ;
                else
                    if (precision == 1)
                        sw.WriteLine("[{0}][{1}], {2:f2}, {3:f1}", i, j, old, min);
                    else if (precision == 2)
                        sw.WriteLine("[{0}][{1}], {2:f2}, {3:f2}", i, j, old, min);
                    else
                        sw.WriteLine("[{0}][{1}], {2:f3}, {3:f3}", i, j, old, min);

            }
        }
        public void LogWroteDEM(string fileName)
        {
            sw.WriteLine("Data successfully written to: {0}", fileName);
        }
        public void LogAnnulusFill(int i, int j, int precision, float old, float min)
        {
            bool flag;
            bool start = true;

            if (start)
                flag = start = false;
            else
                flag = Toggle;

            if (!flag)
            {
                if (precision == 0)
                    sw.Write("Cell[{0}][{1}] with a value of {2}", i, j, (int)old);
                else if (precision == 1)
                    sw.Write("Cell[{0}][{1}] with a value of {2:f1}", i, j, old);
                else if (precision == 2)
                    sw.Write("Cell[{0}][{1}] with a value of {2:f2}", i, j, old);
                else
                    sw.Write("Cell[{0}][{1}] with a value of {2:f3}", i, j, old);

                if (precision == 0)
                    sw.WriteLine(" It was annulus filled to {0}", (int)min);
                else if (precision == 1)
                    sw.WriteLine(" It was annulus filled to {0:f1}", min);
                else if (precision == 2)
                    sw.WriteLine(" It was annulus filled to {0:f2}", min);
                else
                    sw.WriteLine(" It was annulus filled to {0:f3}", min);

                Toggle = true;
            }
            else
            {
                if (precision == 0)
                    sw.WriteLine("[{0}][{1}], {2}, {3}", i, j, (int)old, min);
                else if (precision == 1)
                    sw.WriteLine("[{0}][{1}], {2:f1}, {3:f1}", i, j, old, min);
                else if (precision == 2)
                    sw.WriteLine("[{0}][{1}], {2:f2}, {3:f2}", i, j, old, min);
                else
                    sw.WriteLine("[{0}][{1}], {2:f3}, {3:f3}", i, j, old, min);

            }
        }
        public void Log_CLSE_LSWarning(int rusle_csle)
        {
            if (rusle_csle == 1)
                sw.WriteLine("The CLSE LS data has been saved !");
            else
                sw.WriteLine("The RUSLE LS data has been saved !");
            //sw.WriteLine("The RUSLE LS data has been scaled by 100 !");
            //sw.WriteLine("NOTE: These values are 100 times the actual CLSE LS value.");
        }
        /* zhangjie.2010.06.15
         * open file and write weigth data,and close file
         */
        public void WriteWeightFile(string fileName, ref DemData dd, ref bool[] noDataMap, ref OutFlow[] outFlow)
        {
            int rows, cols;
            int i, j;
            rows = dd.imagNrows;
            cols = dd.imagNcols;

            fp = new StreamWriter(fileName);

            if (fp == null)
                LogFileError(fileName, "w");

            fp.WriteLine("ncols         {0}", dd.ncols);
            fp.WriteLine("nrows         {0}", dd.nrows);
            fp.WriteLine("xllcorner     {0:f6}", dd.xllcorner);
            fp.WriteLine("yllcorner     {0:f6}", dd.yllcorner);
            if (dd.cellType)
                fp.WriteLine("cellsize      {0:f4}", dd.cellSize);
            else
                fp.WriteLine("cellsize      {0}", (int)dd.cellSize);
            fp.WriteLine("NOOUT_value  255");
            for (i = 2; i < rows - 2; i++)
            {
                for (j = 2; j < cols - 2; j++)
                {
                    int c = i * cols + j;
                    for (int k = 0; k < 8; ++k)
                    {
                        if (outFlow[c].m_weight[k] == OutFlow.NOOUT)
                        {
                            fp.Write("{0} ", 0);
                        }
                        //else if(outFlow[c].m_weight[k] > 100)
                        //{
                        //    fp.Write(" {0:f2}", ((float)(255 - outFlow[c].m_weight[k])) / 100);
                        //}
                        else
                        {

                            fp.Write("{0:f2} ", ((float)outFlow[c].m_weight[k]) / 100);
                        }
                    }
                }
                fp.WriteLine();
            }
            fp.Flush();
            fp.Close();
        }
        // Open file and write Slope Length data, close file
        public void WriteSlopeLenFile(string fileName, ref DemData dd, ref bool[] noDataMap, ref float[] slopeLen)
        {
            int rows, cols;
            int i, j;
            rows = dd.imagNrows;
            cols = dd.imagNcols;

            fp = new StreamWriter(fileName);

            if (fp == null)
                LogFileError(fileName, "w");

            fp.WriteLine("ncols         {0}", dd.ncols);
            fp.WriteLine("nrows         {0}", dd.nrows);
            fp.WriteLine("xllcorner     {0:f6}", dd.xllcorner);
            fp.WriteLine("yllcorner     {0:f6}", dd.yllcorner);
            if (dd.cellType)
                fp.WriteLine("cellsize      {0:f4}", dd.cellSize);
            else
                fp.WriteLine("cellsize      {0}", (int)dd.cellSize);

            fp.WriteLine("NODATA_value  -9.9");

            for (i = 2; i < rows - 2; i++)
            {
                for (j = 2; j < cols - 2; j++)
                {
                    if (noDataMap[i * cols + j])
                        fp.Write("-9.9 ");
                    else
                        fp.Write("{0:f3} ", slopeLen[i * cols + j]);
                }
                fp.WriteLine();
            }
            fp.Flush();
            fp.Close();
        }
        public void WriteSlopeAngFile(string fileName, DemData dd, bool[] noDataMap, float[] slopeAng)
        {
            int rows, cols;
            int i, j;
            rows = dd.imagNrows;
            cols = dd.imagNcols;

            fp = new StreamWriter(fileName);
            if (fp == null) // Handle error opening file
                LogFileError(fileName, "w");

            fp.WriteLine("ncols         {0}", dd.ncols);
            fp.WriteLine("nrows         {0}", dd.nrows);
            fp.WriteLine("xllcorner     {0:f6}", dd.xllcorner);
            fp.WriteLine("yllcorner     {0:f6}", dd.yllcorner);
            if (dd.cellType)
                fp.WriteLine("cellsize      {0:f4}", dd.cellSize);
            else
                fp.WriteLine("cellsize      {0}", (int)dd.cellSize);

            fp.WriteLine("NODATA_value  -9.9");
            for (i = 2; i < rows - 2; i++)
            {
                for (j = 2; j < cols - 2; j++)
                    if (noDataMap[i * cols + j])
                        fp.Write("-9.9 ");
                    else
                        fp.Write("{0:f4} ", slopeAng[i * cols + j]);
                fp.WriteLine();
            }

            fp.Flush();
            fp.Close();
        }
        public void WriteSlopeExponentFile(string fileName, DemData dd, bool[] noDataMap, float[] slopeAng)
        {
            int rows, cols;
            int i, j;

            rows = dd.imagNrows;
            cols = dd.imagNcols;

            fp = new StreamWriter(fileName);
            if (fp == null) // Handle error opening file
                LogFileError(fileName, "w");


            fp.WriteLine("ncols         {0}", dd.ncols);
            fp.WriteLine("nrows         {0}", dd.nrows);
            fp.WriteLine("xllcorner     {0:f6}", dd.xllcorner);
            fp.WriteLine("yllcorner     {0:f6}", dd.yllcorner);
            if (dd.cellType)
                fp.WriteLine("cellsize      {0:f4}", dd.cellSize);
            else
                fp.WriteLine("cellsize      {0}", (int)dd.cellSize);

            fp.WriteLine("NODATA_value  {0}", dd.intNoData);

            fp.WriteLine("NODATA_value  -9.9");

            for (i = 2; i < rows - 2; i++)
            {
                for (j = 2; j < cols - 2; j++)
                {
                    if (noDataMap[i * cols + j])
                        fp.Write("-9.9 ");
                    else
                        fp.Write("{0:f2} ", TableLookUp_csle(slopeAng[i * cols + j]));
                }
                fp.WriteLine();
            }
            fp.Flush();
            fp.Close();
        }
        //�������㷨�¼���0.5��0.7�ĵ�λ��
        public void WriteSlopeFactorFile(string fileName, DemData dd, bool[] noDataMap, float[] slopeAng)
        {
            int rows, cols;
            int i, j;
            rows = dd.imagNrows;
            cols = dd.imagNcols;

            fp = new StreamWriter(fileName);
            if (fp == null) // Handle error opening file
                LogFileError(fileName, "w");

            fp.WriteLine("ncols         {0}", dd.ncols);
            fp.WriteLine("nrows         {0}", dd.nrows);
            fp.WriteLine("xllcorner     {0:f6}", dd.xllcorner);
            fp.WriteLine("yllcorner     {0:f6}", dd.yllcorner);
            if (dd.cellType)
                fp.WriteLine("cellsize      {0:f4}", dd.cellSize);
            else
                fp.WriteLine("cellsize      {0}", (int)dd.cellSize);
            fp.WriteLine("NODATA_value  -9.9");

            for (i = 2; i < rows - 2; i++)
            {
                for (j = 2; j < cols - 2; j++)
                {
                    if (noDataMap[i * cols + j])
                        fp.Write("-9.9 ");
                    else
                    {
                        if (slopeAng[i * cols + j] < 2.8624)
                            fp.Write("{0:f1} ", dd.scf_lt5);
                        else
                            fp.Write("{0:f1} ", dd.scf_ge5);
                    }

                }
                fp.WriteLine();
            }
            fp.Flush();
            fp.Close();
        }
        public void WriteDirectionArray(string fileName, ref DemData dd, ref bool[] noDatamMap, ref byte[] outFlow)
        {
            int rows, cols;
            int i, j;
            rows = dd.imagNrows;
            cols = dd.imagNcols;
            fp = new StreamWriter(fileName);
            if (fp == null) // Handle error opening file
                LogFileError(fileName, "w");
            fp.WriteLine("ncols         {0}", dd.ncols);
            fp.WriteLine("nrows         {0}", dd.nrows);
            fp.WriteLine("xllcorner     {0:f6}", dd.xllcorner);
            fp.WriteLine("yllcorner     {0:f6}", dd.yllcorner);
            if (dd.cellType)
                fp.WriteLine("cellsize      {0:f4}", dd.cellSize);
            else
                fp.WriteLine("cellsize      {0}", (int)dd.cellSize);
            //fp.WriteLine("NODATA_value  {0}", dd.intNoData);
            fp.WriteLine("NODATA_value  -9");
            int count = 0;
            for (i = 2; i < rows - 2; i++)
            {
                for (j = 2; j < cols - 2; j++)
                {
                    if (noDatamMap[i * cols + j])
                        fp.Write("-9 ");
                    else
                    {
                        if (outFlow[i * cols + j] == 0)
                        {
                            count++;
                        }
                        fp.Write("{0} ", outFlow[i * cols + j]);
                    }
                }
                fp.WriteLine();
            }
            Debug.WriteLine("count = " + count);
            fp.Flush();
            fp.Close();
        }
        public void Write_Direction_Array(string fileName, ref DemData dd, ref bool[] noDataMap, ref byte[] inMap)
        {
            int rows, cols;
            int i, j;
            rows = dd.imagNrows;
            cols = dd.imagNcols;
            fp = new StreamWriter(fileName);
            if (fp == null) // Handle error opening file
                LogFileError(fileName, "w");
            fp.WriteLine("ncols         {0}", dd.ncols);
            fp.WriteLine("nrows         {0}", dd.nrows);
            fp.WriteLine("xllcorner     {0:f6}", dd.xllcorner);
            fp.WriteLine("yllcorner     {0:f6}", dd.yllcorner);
            if (dd.cellType)
                fp.WriteLine("cellsize      {0:f4}", dd.cellSize);
            else
                fp.WriteLine("cellsize      {0}", (int)dd.cellSize);
            //fp.WriteLine("NODATA_value  {0}", dd.intNoData);
            fp.WriteLine("NODATA_value  -9");

            for (i = 2; i < rows - 2; i++)
            {
                for (j = 2; j < cols - 2; j++)
                {
                    if (noDataMap[i * cols + j])

                        fp.Write("-9 ");
                    else
                        fp.Write("{0} ", (int)inMap[i * cols + j]);
                }
                fp.WriteLine();
            }
            fp.Flush();
            fp.Close();
        }
        public void WriteBoolGrid(string fileName, DemData dd, bool[] noDataMap, bool[] grid)
        {
            int rows, cols;
            int i, j;
            rows = dd.imagNrows;
            cols = dd.imagNcols;

            fp = new StreamWriter(fileName);
            if (fp == null)
                LogFileError(fileName, "w");

            fp.WriteLine("ncols         {0}", dd.ncols);
            fp.WriteLine("nrows         {0}", dd.nrows);
            fp.WriteLine("xllcorner     {0:f6}", dd.xllcorner);
            fp.WriteLine("yllcorner     {0:f6}", dd.yllcorner);
            if (dd.cellType)
                fp.WriteLine("cellsize      {0:f4}", dd.cellSize);
            else
                fp.WriteLine("cellsize      {0}", (int)dd.cellSize);
            fp.WriteLine("NODATA_value  -9");

            for (i = 2; i < rows - 2; i++)
            {
                for (j = 2; j < cols - 2; j++)
                {
                    if (grid[i * cols + j])
                        fp.Write(" 1");
                    else
                        fp.Write(" 0");
                }
                fp.WriteLine();
            }
            fp.Flush();
            fp.Close();
        }
        public void LogCumulativeProgress(int lcp_count, int lcp_p1, int lcp_p2)
        {
            if (lcp_count == 1)
                sw.WriteLine("Beginning cumulative length calculations");
            sw.WriteLine("Pass # {0,-3:d} Part 1 hits = {1,-9:d}	Part # 2 {2,-9:d}", lcp_count, lcp_p1, lcp_p2);
            if (lcp_p1 == 0 && lcp_p2 == 0)
                sw.WriteLine("Cumulative length calculations completed");
        }
        //�ر���־�ļ�
        public void CloseLogFile()
        {
            sw.Flush();
            sw.Close();
        }
        public void WriteSlopeLenFeet(string fileName, DemData dd, bool[] noDataMap, float[] grid)
        {
            int rows, cols;
            int i, j;

            rows = dd.imagNrows;
            cols = dd.imagNcols;

            fp = new StreamWriter(fileName);
            if (fp == null) // Handle error opening file
                LogFileError(fileName, "w");

            fp.WriteLine("ncols         {0}", dd.ncols);
            fp.WriteLine("nrows         {0}", dd.nrows);
            fp.WriteLine("xllcorner     {0:f6}", dd.xllcorner);
            fp.WriteLine("yllcorner     {0:f6}", dd.yllcorner);
            if (dd.cellType)
                fp.WriteLine("cellsize      {0:f4}", dd.cellSize);
            else
                fp.WriteLine("cellsize      {0}", (int)dd.cellSize);

            fp.WriteLine("NODATA_value  -9.9");
            for (i = 2; i < rows - 2; i++)
            {
                for (j = 2; j < cols - 2; j++)
                {
                    if (noDataMap[i * cols + j])
                        fp.Write("-9.9 ");
                    else
                        fp.Write("{0:f3} ", grid[i * cols + j]);
                }
                fp.WriteLine();

            }
            fp.Flush();
            fp.Close();
        }
        public void Write_FloatGrid(string fileName, DemData dd, bool[] noDataMap, float[] grid)
        {
            int rows, cols;
            int i, j;
            rows = dd.imagNrows;
            cols = dd.imagNcols;
            fp = new StreamWriter(fileName);
            if (fp == null) // Handle error opening file
                LogFileError(fileName, "w");


            fp.WriteLine("ncols         {0}", dd.ncols);
            fp.WriteLine("nrows         {0}", dd.nrows);
            fp.WriteLine("xllcorner     {0:f6}", dd.xllcorner);
            fp.WriteLine("yllcorner     {0:f6}", dd.yllcorner);
            if (dd.cellType)
                fp.WriteLine("cellsize      {0:f4}", dd.cellSize);
            else
                fp.WriteLine("cellsize      {0}", (int)dd.cellSize);

            fp.WriteLine("NODATA_value  -9.9");

            for (i = 2; i < rows - 2; i++)
            {
                for (j = 2; j < cols - 2; j++)
                    if (noDataMap[i * cols + j])
                        fp.Write("-9.9 ");
                    else
                        fp.Write("{0:f4} ", grid[i * cols + j]);
                fp.WriteLine();
            }
            fp.Flush();
            fp.Close();
        }
        // Open file and write Rusle LS2 data, close file
        public void Write_LS2(string fileName, DemData dd, bool[] noDataMap, float[] grid)
        {
            int rows, cols;
            int i, j;

            rows = dd.imagNrows;
            cols = dd.imagNcols;
            fp = new StreamWriter(fileName);
            if (fp == null) // Handle error opening file
                LogFileError(fileName, "w");


            fp.WriteLine("ncols         {0}", dd.ncols);
            fp.WriteLine("nrows         {0}", dd.nrows);
            fp.WriteLine("xllcorner     {0:f6}", dd.xllcorner);
            fp.WriteLine("yllcorner     {0:f6}", dd.yllcorner);
            if (dd.cellType)
                fp.WriteLine("cellsize      {0:f4}", dd.cellSize);
            else
                fp.WriteLine("cellsize      {0}", (int)dd.cellSize);

            fp.WriteLine("NODATA_value -9");
            for (i = 2; i < rows - 2; i++)
            {
                for (j = 2; j < cols - 2; j++)
                    if (noDataMap[i * cols + j])
                        fp.Write("-9 ");
                    else if ((int)(grid[i * cols + j] + 0.5) != 0)
                        fp.Write("{0:f2} ", (grid[i * cols + j] + 0.5));
                    else
                        fp.Write("0.01 ");//ԭʼֵΪ1,20110610��Ϊ0.01
                fp.WriteLine();
            }
            fp.Flush();
            fp.Close();
        }

        #endregion
        //##############################################



        //                    DemRepair



        //##############################################

        #region DemRepair
        public bool FillSinks(DemData demData, ref bool[] noDataMap, ref float[] demMap)
        {
            bool flag = false;
            int i; /*Loop Counter.*/
            int j; /*Loop Counter.*/
            int rows; /*Number of rows.*/
            int cols; /*Number of columns.*/
            float min; /*Temp value */
            float old; /*temp debugging value */
            int nw, n, ne, w, c, e, sw, s, se;
            rows = demData.imagNrows;
            cols = demData.imagNcols;
            float Min = (float)100000.0;
            min = Min;
            for (i = 2; i < demData.imagNrows - 2; i++)
                for (j = 2; j < demData.imagNcols - 2; j++)
                {
                    c = i * cols + j;
                    nw = c - cols - 1;
                    n = c - cols;
                    ne = c - cols + 1;
                    w = c - 1;
                    e = c + 1;
                    sw = c + cols - 1;
                    s = c + cols;
                    se = c + cols + 1;
                    //���ճ����˼·�������ݵصĶ����Ǳ�������ֵ�㣬��Χ�����ܱ�����ֵ������Χ��ֵ���������ĵ�
                    //�����ҽ�����������޸�
                    //��ô����һ�������ǣ���������������ͬ��ֵ�ĵ�������������Χ��ֵ�������������㣬��ô���أ������ǽ�����˵��������
                    //����˵�����ĵ�Ͳ����ݵ����أ���
                    if (noDataMap[c])
                        continue;
                    min = (float)100000.0; //��һ�����ֵ��
                    //�ж���Χ�Ƿ���ֵ��ֻҪ��һ����ֵ�����ѭ��
                    if (noDataMap[nw] && noDataMap[n] && noDataMap[ne] &&
                        noDataMap[e] && noDataMap[se] && noDataMap[s]
                        && noDataMap[sw] && noDataMap[w])
                    {
                        continue;
                    }
                    min = demMap[nw] < min ? demMap[nw] : min;
                    min = demMap[n] < min ? demMap[n] : min;
                    min = demMap[ne] < min ? demMap[ne] : min;
                    min = demMap[e] < min ? demMap[e] : min;
                    min = demMap[se] < min ? demMap[se] : min;
                    min = demMap[s] < min ? demMap[s] : min;
                    min = demMap[sw] < min ? demMap[sw] : min;
                    min = demMap[w] < min ? demMap[w] : min;
                    //�����Сֵ��������ֵ��˵�����ݵأ���������
                    if (min > demMap[c])
                    {
                        flag = true;
                        old = demMap[c];
                        demMap[c] = min;
                        LogFill(i - 2, j - 2, demData.dataPrecision, old, min);
                    }
                }
            return flag;
        }
        public bool AnnulusFill(DemData demData, ref bool[] noDataMap, ref float[] demMap)
        {
            bool flag = false;
            int i; /*Loop Counter.*/
            int j; /*Loop Counter.*/
            int rows; /*Number of rows.*/
            int cols; /*Number of columns.*/
            float min; /*Temp value */
            float old; /*Used for log file */
            int nw, n, ne, w, c, e, sw, s, se;
            int nnww, nnw, nn, nne, nnee;
            int nww, nee, ww, ee, sww, see;
            int ssww, ssw, ss, sse, ssee;
            /*�Žܵ��޸�*/
            rows = demData.imagNrows;
            cols = demData.imagNcols;
            for (i = 2; i < rows - 2; i++)
            {
                for (j = 2; j < cols - 2; j++)
                {
                    c = i * cols + j;

                    if (noDataMap[c])
                    {
                        continue;
                    }
                    nw = c - cols - 1;
                    n = c - cols;
                    ne = c - cols + 1;
                    w = c - 1;
                    e = c + 1;
                    sw = c + cols - 1;
                    s = c + cols;
                    se = c + cols + 1;

                    // Do next cell if any adjacent cell contains nodata

                    if (noDataMap[nw] || noDataMap[n] || noDataMap[ne] || noDataMap[w] ||
                        noDataMap[e] || noDataMap[sw] || noDataMap[s] || noDataMap[se])
                    {
                        continue;
                    }

                    min = demMap[nw] < demMap[n] ? demMap[nw] : demMap[n];
                    min = demMap[ne] < min ? demMap[ne] : min;
                    min = demMap[w] < min ? demMap[w] : min;
                    min = demMap[e] < min ? demMap[e] : min;
                    min = demMap[sw] < min ? demMap[sw] : min;
                    min = demMap[s] < min ? demMap[s] : min;
                    min = demMap[se] < min ? demMap[se] : min;

                    // Do next cell unless the case where min == dem[c] 

                    if (GlobalConstants.FUZZ < Math.Abs(min - demMap[c]))
                    {
                        continue;
                    }
                    nn = n - cols;
                    nnww = nn - 2;
                    nnw = nn - 1;
                    nne = nn + 1;
                    nnee = nn + 2;
                    nww = nw - 1;
                    nee = ne + 1;
                    ww = w - 1;
                    ee = e + 1;
                    sww = sw - 1;
                    see = se + 1;
                    ss = s + cols;
                    ssww = ss - 2;
                    ssw = ss - 1;
                    sse = ss + 1;
                    ssee = ss + 2;

                    // Move on to the next cell if the annulus ring contains a nodata cell

                    if (noDataMap[nnww] || noDataMap[nnw] || noDataMap[nn] || noDataMap[nne] ||
                        noDataMap[nnee] || noDataMap[nww] || noDataMap[nee] || noDataMap[ww] ||
                        noDataMap[ee] || noDataMap[sww] || noDataMap[see] || noDataMap[ssww] ||
                        noDataMap[ssw] || noDataMap[ss] || noDataMap[sse] || noDataMap[ssee])
                    {
                        continue;
                    }

                    // Determine the minimum value within the annulus ring.

                    min = demMap[nnww] < demMap[nnw] ? demMap[nnww] : demMap[nnw];
                    min = min < demMap[nn] ? min : demMap[nn];
                    min = min < demMap[nne] ? min : demMap[nne];
                    min = min < demMap[nnee] ? min : demMap[nnee];
                    min = min < demMap[nww] ? min : demMap[nww];
                    min = min < demMap[nee] ? min : demMap[nee];
                    min = min < demMap[ww] ? min : demMap[ww];
                    min = min < demMap[ss] ? min : demMap[ee];
                    min = min < demMap[sww] ? min : demMap[sww];
                    min = min < demMap[see] ? min : demMap[see];
                    min = min < demMap[ssww] ? min : demMap[ssww];
                    min = min < demMap[ssw] ? min : demMap[ssw];
                    min = min < demMap[ss] ? min : demMap[ss];
                    min = min < demMap[sse] ? min : demMap[sse];
                    min = min < demMap[ssee] ? min : demMap[ssee];

                    // If the center cell is lower than all the cells in the annulus ring then
                    // replace this cell value with the minimum value found in the annulus ring.

                    if (min > demMap[c])
                    {
                        flag = true;
                        old = demMap[c];
                        demMap[c] = min;
                        if (demMap[nw] < min) demMap[nw] = min;
                        if (demMap[n] < min) demMap[n] = min;
                        if (demMap[ne] < min) demMap[ne] = min;
                        if (demMap[w] < min) demMap[w] = min;
                        if (demMap[e] < min) demMap[e] = min;
                        if (demMap[sw] < min) demMap[sw] = min;
                        if (demMap[s] < min) demMap[s] = min;
                        if (demMap[se] < min) demMap[se] = min;
                        //Console.WriteLine("i = {0},j = {1},min = {2},dem[3] = {3}", i - 2, j - 2, min, dem[c]);
                        //LogAnnulusFill(i, j, demData.fp_precision, old, min);
                        LogAnnulusFill(i - 2, j - 2, demData.dataPrecision, old, min);
                    }
                }
            }

            return flag;
        }

        #endregion

        //##############################################



        //                    CalcData



        //##############################################
        #region CalcData
        /* zhangjie, 2010.08.06
         * ���á����ײ���Ȩ��֡������¶�
         */
        //downAng(demData, noDataMap, demMap, ref slopeAng,ref slopeLen,ref Aspect)
        //20140526 Dinf�޸�λ��
        public void downAng(DemData demData, bool[] noDataMap, float[] demMap, ref float[] slopeAng, ref int[] slopeAspect, ref float[] slopeLen)
        {
            float s1, s2;
            int Aspect=-1;
            //float bestCellLen;//?
            //byte bestDirection;
            //float diagCellSize; /* Diagonal cell size.*/
            float deg; /* Change to degrees.*/
            float cellSize; /* Cell Size.*/
            int rows; /* Number of rows.*/
            int cols; /* Number of columns.*/
            int nw, n, ne, w, c, e, sw, s, se;
            float[] H = new float[10];//H0�����ĵ㣬H1=H9=����H2=�������Դ�����
            float[] R = new float[9];
            float[] S = new float[9];

            rows = demData.imagNrows;
            cols = demData.imagNcols;
            cellSize = demData.cellSize;
            //diagCellSize = cellSize * (float)1.4142136; // for NW, NE, SE, SW 
            deg = (float)57.29577951308;

            bool flag = false;

            //��Ϊ��������������ܣ������ڴ�����ʱ���ÿ���Խ�磬��������д�����ͼ򵥶���
            for (int i = 2; i < rows - 2; i++)
            {
                for (int j = 2; j < cols - 2; j++)
                {
                    //bestCellLen = (float)0.0;
                    //bestDirection = (byte)0.0;
                    c = i * cols + j;
                    if (noDataMap[c])
                    {
                        slopeAspect[c] = 0;
                        slopeLen[c] = (float)0.0;
                        Aspect = -1;
                      //  outFlow[c] = (byte)0.0;
                        continue;
                    }
                    if(i==5 && j==3)
                        i=5;
                    flag = false;
                    nw = c - cols - 1;
                    n = c - cols;
                    ne = c - cols + 1;
                    w = c - 1;
                    e = c + 1;
                    sw = c + cols - 1;
                    s = c + cols;
                    se = c + cols + 1;
                    //��
                    for (int count = 0; count < 9; count++)
                    {
                        R[count] = 0; S[count] = 0;
                    }
                    for (int k = 0; k <= 9; k++)
                        H[k] = demMap[c];//��ʼ���Ƿ���� 2014 3 26 ��
                    s1 = s2 = 0.0f;
                    //��(west)
                    if (noDataMap[w] == false)
                    {
                        H[5] = demMap[w];
                    }
                    //����(north west)
                    if (noDataMap[nw] == false)
                    {
                        H[4] = demMap[nw];
                    }
                    //��(north)
                    if (noDataMap[n] == false)
                    {
                        H[3] = demMap[n];
                    }
                    // ����(north east)
                    if (noDataMap[ne] == false)
                    {
                        H[2] = demMap[ne];
                    }
                    // ��(east)
                    if (noDataMap[e] == false)
                    {
                        H[1] = demMap[e];
                        H[9] = demMap[e];
                    }
                    // ����(south east)
                    if (noDataMap[se] == false)
                    {
                        H[8] = demMap[se];
                    }
                    // ��(south)
                    if (noDataMap[s] == false)
                    {
                        H[7] = demMap[s];
                    }
                    // ����(south west)
                    if (noDataMap[sw] == false)
                    {
                        H[6] = demMap[sw];
                    }
                    float max = -1;//��ʱ�����Դ洢����¶�
                    int temp_k = -1;//��ʱ�洢����
                    Aspect = -1;
                    for (int k = 1; k <= 8; k++)//2014.4.10���
                    {
                        if (H[0] >= H[k] && H[0] >= H[k + 1])
                        {
                            if (H[0] == H[k] && H[0] == H[k + 1])
                            { }//ƽ�ز����д�����
                            else
                            {
                                if (k % 2 == 0)//ʼ����s1Ϊ���ĵ�Ԫ������������ķ��� 2014 9 13
                                {
                                    s1 = (H[0] - H[k + 1]) / cellSize;
                                    s2 = (H[k + 1] - H[k]) / cellSize;
                                }
                                else
                                {
                                    s1 = (H[0] - H[k]) / cellSize;
                                    s2 = (H[k] - H[k + 1]) / cellSize;
                                }
                                S[k] = (float)Math.Sqrt((double)(s1 * s1 + s2 * s2));
                                if (s1 != 0 && s2 != 0)
                                    //����ʹRΪ�������䡰ǰ�桱���������ɵĽǶȣ����ں���slopeAspect�ļ��㣩�����涼�������ĵ� 2014 9 16
                                    if (k % 2 == 0)
                                        R[k] = 45 - (float)Math.Atan(s2 / s1) * deg;
                                    else
                                        R[k] = (float)Math.Atan(s2 / s1) * deg;
                                /*else if (s1 == 0 && s2 == 0)
                                    R[k] = 22.5f;*/
                                if (s1 == 0)
                                    if (k % 2 == 0)
                                        R[k] = 0;
                                    else
                                        R[k] = 45;
                                if (s2 == 0)
                                    if (k % 2 == 0)
                                        R[k] = 45;
                                    else
                                        R[k] = 0;

                                if (R[k] < 0)
                                {
                                    if (k % 2 == 0)
                                        R[k] = 45;
                                    else
                                        R[k] = 0;
                                    S[k] = s1;
                                }
                                if (R[k] > 45)
                                {
                                    R[k] = 45;
                                    if (k % 2 == 0)
                                    {
                                      
                                        S[k] = (H[0] - H[k]) / ((float)Math.Sqrt((double)(2)) * cellSize);
                                    }
                                    else
                                    {
                                        //R[k] = 0;
                                        S[k] = (H[0] - H[k + 1]) / ((float)Math.Sqrt((double)(2)) * cellSize);
                                    }
                                }
                            }
                        }
                        else if (H[0] > H[k] && H[0] < H[k + 1])
                        {
                            R[k] = 0;
                            if (k % 2 != 0)
                                S[k] = (H[0] - H[k]) / (float)cellSize;
                            else
                                S[k] = (H[0] - H[k]) / ((float)Math.Sqrt((double)(2)) * cellSize);
                        }
                        else if (H[0] < H[k] && H[0] > H[k + 1])
                        {
                            R[k] = 45;
                            if (k % 2 != 0)
                                S[k] = (H[0] - H[k + 1]) / ((float)Math.Sqrt((double)(2)) * cellSize);
                            else
                                S[k] = (H[0] - H[k + 1]) / (float)cellSize;
                        }

                        else
                        {
                            //�ݵ�


                        }//R[k] = 22.5f;

                        if (max <= S[k] && S[k] > 0)//Ӱ��� 2014.7.13 ��
                            if (max < S[k])
                            {
                                max = S[k];
                                temp_k = k;
                                Aspect = temp_k;//�����³����ֵ ����Ӧ�ķ���
                            }
                            else
                                if (k % 2 == 0 && H[0] == H[k - 1] && H[k] == H[k + 1])//����ĸ��ǳ����ı����µ��������� 2014 9 13
                                {
                                    max = S[k];
                                    temp_k = k;//����һ�������µ���Ϊ�������
                                    Aspect = temp_k;
                                }
                    }
                    if (Aspect >= 0)
                    {
                        slopeAspect[c] = Convert.ToInt32(R[Aspect]) + 45 * (temp_k - 1);
                        slopeAng[c] = (float)Math.Atan(S[Aspect]) * deg;
                        if( (Aspect) % 2 == 0)
                        slopeLen[c] = cellSize / ((float)Math.Cos((45-R[Aspect])*Math.PI/180));//���һ ����R[temp_k]����45-R[temp_k] 2014.3.17
                        else
                        slopeLen[c] = cellSize / ((float)Math.Cos(R[Aspect] * Math.PI/180));
                    }
                    else//�������ݵػ���ƽ��
                    {
                        slopeAspect[c] = -1;
                        slopeAng[c] = 0;
                        slopeLen[c] = cellSize;
                    }
                }
            }
        }
        //3.31��
        //20140526 Dinf�޸�λ��
        public void downWeight(DemData demData, bool[] noDataMap, float[] demMap, ref OutFlow[] outFlow, ref int[] slopeAspect)
        {
            int[]  temp_Aspect={0,0};//��ʱ��������ˮ������
            byte Index_RE0 = 0;
            byte Index_RE1 = 0; 
            float cellSize = demData.cellSize;
            float diagCellSize = cellSize * (float)1.4142136;
            int rows = demData.imagNrows;
            int cols = demData.imagNcols;
            int nw, n, ne, w, c, e, sw, s, se;
            float total = 0.0f; // ��¼�ܺ�;
            bool ifcut = false;
            for (int i = 2; i < rows - 2; i++)
            {
                for (int j = 2; j < cols - 2; j++)
                {
                    c = i * cols + j;
                    if (noDataMap[c])
                    {
                        // ���Ϊ��ֵ�㣬��û��������
                        continue;
                    }
                    nw = c - cols - 1;
                    n = c - cols;
                    ne = c - cols + 1;
                    w = c - 1;
                    e = c + 1;
                    sw = c + cols - 1;
                    s = c + cols;
                    se = c + cols + 1;
                    total = 0.0f; // ��¼�ܺ�
                    int Number; //������Ϊ45�������Ĺ�����һ�������¡�ԭ���������������Ȩֵ����պ��෴  2014 9 18
                    if(slopeAspect[c]!=-1)
                        outFlow[c].JUG = true;

                    if (slopeAspect[c] % 45 != 0)
                        Number = slopeAspect[c] / 45 + 1;
                    else
                        Number = slopeAspect[c] / 45;
                    switch (Number)
                    {
                        case 1: { temp_Aspect[0] = e; temp_Aspect[1] = ne; Index_RE0 = 3; Index_RE1 = 2; } break;
                        case 2: { temp_Aspect[0] = ne; temp_Aspect[1] = n; Index_RE0 = 2; Index_RE1 = 1; } break;
                        case 3: { temp_Aspect[0] = n; temp_Aspect[1] = nw; Index_RE0 = 1; Index_RE1 = 0; } break;
                        case 4: { temp_Aspect[0] = nw; temp_Aspect[1] = w; Index_RE0 = 0; Index_RE1 = 7; } break;
                        case 5: { temp_Aspect[0] = w; temp_Aspect[1] = sw; Index_RE0 = 7; Index_RE1 = 6; } break;
                        case 6: { temp_Aspect[0] = sw; temp_Aspect[1] = s; Index_RE0 = 6; Index_RE1 = 5; } break;
                        case 7: { temp_Aspect[0] = s; temp_Aspect[1] = se; Index_RE0 = 5; Index_RE1 = 4; } break;
                        case 8: { temp_Aspect[0] = se; temp_Aspect[1] = e; Index_RE0 = 4; Index_RE1 = 3; } break;
                        case 0: { temp_Aspect[0] = se; temp_Aspect[1] = e; Index_RE0 = 4; Index_RE1 = 3; } break;
                    }    
                    // ����Ȩֵ
                    //if (total == 0.0f)
                    //{
                    //    // ԭ���ϲ����ܳ��������������Ϊ�ݵ����ʱ�Ѿ������ֵ������
                    //    // ��������totalҪ����ĸ�����Ի����ж�һ�±ȽϺ�
                    //    // 
                    //}
                    //else
                    //{
                    //    // ����(north west)
                    if (!noDataMap[temp_Aspect[0]] && demMap[temp_Aspect[0]] < demMap[c])
                    {
                        //ifcut = IsCutDirection(diagCellSize, demMap[c], demMap[nw], demData, slopeAng[nw]);
                        if (ifcut)
                        {
                            // outFlow[c].m_weight[Index.nw] = OutFlow.NOOUT;
                            // Debug.WriteLine("A Cut point");                                
                            // ����100��    ,2010.08.13ȥ����0.005
                            outFlow[c].m_weight[Index_RE0] = (byte)(255 - (int)(100 * ((slopeAspect[c] % 45) / 45)));//2014.7.13�� �� �������漸�еĳ��ţ�֮ǰ��Ϊ�����                  
                            //outFlow[c].m_weight[Index.nw] = (float)(255 - (int)(100 * (temp / total) + 0.5));
                            //outFlow[c].m_weight[Index.nw] = -100 * (temp / total);
                        }
                        else
                        {
                            //float temp = (demMap[c] - demMap[nw]) / 4;
                            // ����100��    
                            //outFlow[c].m_weight[Index.nw] = 100 * (temp / total );
                            outFlow[c].m_weight[Index_RE0] = (byte)((int)(100 * (slopeAspect[c] % 45) / 45));
                            //outFlow[c].m_weight[Index_RE0] = (byte)((int)(100 * (slopeAspect[c] / 45)) + (float)(slopeAspect[c]%45)/45*100); 2014.7.19��
                        }
                    }
                    // ��(north)
                    if (!noDataMap[temp_Aspect[1]] && demMap[temp_Aspect[1]] < demMap[c])
                    {
                        //ifcut = IsCutDirection(cellSize, demMap[c], demMap[n], demData, slopeAng[n]);
                        if (ifcut)
                        {
                            // outFlow[c].m_weight[Index.n] = OutFlow.NOOUT;
                            // Debug.WriteLine("A Cut point");
                            //float temp = (demMap[c] - demMap[n]) / 2;
                            outFlow[c].m_weight[Index_RE1] = (byte)(255 - (int)(100 * (45 - slopeAspect[c] % 45) / 45));//2014  4 9 ����Ȩֵ
                            //outFlow[c].m_weight[Index.n] = -100 * (temp / total);
                        }
                        else
                        {
                            //float temp = (demMap[c] - demMap[n]) / 2;
                            //outFlow[c].m_weight[Index.n] = 100 * (temp / total );
                            outFlow[c].m_weight[Index_RE1] = (byte)((int)(100 * (45 - slopeAspect[c] % 45) / 45));//2014  4 9 ����Ȩֵ
                            //outFlow[c].m_weight[Index_RE0] = (byte)((int)(100 * (slopeAspect[c] / 45)) + (float)(45-slopeAspect[c]%45)/45*100); 2014.7.19��
                        }

                    }
                       
                        //}

                    }
                }
            }
        //zhhm20111011����Ȩ�أ����ض�//flowcut������Ϊ�˺Ͳ����ǽضϵ�downweight�ĺ���������
        public void downWeight(DemData demData, bool[] noDataMap, float[] demMap, ref OutFlow[] outFlow, ref float[] slopeAng,bool flowcut)
        {
            float cellSize = demData.cellSize;
            float diagCellSize = cellSize * (float)1.4142136;
            int rows = demData.imagNrows;
            int cols = demData.imagNcols;
            int nw, n, ne, w, c, e, sw, s, se;
            float total = 0.0f, temp; // ��¼�ܺ�;
            bool ifcut = false;
            //bool boundary = false;
            for (int i = 2; i < rows - 2; i++)
            {
                for (int j = 2; j < cols - 2; j++)
                {
                    // Debug.WriteLine("i = " + i + "j = " + j);
                    c = i * cols + j;
                    if (noDataMap[c])
                    {
                        // ���Ϊ��ֵ�㣬��û��������
                        continue;
                    }
                    nw = c - cols - 1;
                    n = c - cols;
                    ne = c - cols + 1;
                    w = c - 1;
                    e = c + 1;
                    sw = c + cols - 1;
                    s = c + cols;
                    se = c + cols + 1;
                    total = 0.0f; // ��¼�ܺ�

                    // ��ֵ����Ҫ������ֵС
                    // ����(north west)

                    if (!noDataMap[nw] && demMap[nw] < demMap[c])
                    {
                        //ifcut = IsCutDirection(diagCellSize, demMap[c], demMap[nw], demData, slopeAng[nw]);
                        //if (!ifcut)
                        //{
                        //    total += (demMap[c] - demMap[nw]) / 4;
                        //}
                        total += (demMap[c] - demMap[nw]) / 4;
                    }
                    // ��(north)
                    if (!noDataMap[n] && demMap[n] < demMap[c])
                    {
                        //ifcut = IsCutDirection(cellSize, demMap[c], demMap[n], demData, slopeAng[n]);
                        //if (!ifcut)
                        //{
                        //    total += (demMap[c] - demMap[n]) / 2;
                        //}
                        total += (demMap[c] - demMap[n]) / 2;
                    }
                    // ����(north east)
                    if (!noDataMap[ne] && demMap[ne] < demMap[c])
                    {
                        //ifcut = IsCutDirection(diagCellSize, demMap[c], demMap[ne], demData, slopeAng[ne]);
                        //if (!ifcut)
                        //{
                        //   total += (demMap[c] - demMap[ne]) / 4;
                        //}
                        total += (demMap[c] - demMap[ne]) / 4;
                    }
                    // ��(east)
                    if (!noDataMap[e] && demMap[e] < demMap[c])
                    {
                        //ifcut = IsCutDirection(cellSize, demMap[c], demMap[e], demData, slopeAng[e]);
                        //if (!ifcut)
                        //{
                        //    total += (demMap[c] - demMap[e]) / 2;
                        //}
                        total += (demMap[c] - demMap[e]) / 2;
                    }
                    // ����(north east)
                    if (!noDataMap[se] && demMap[se] < demMap[c])
                    {
                        //ifcut = IsCutDirection(diagCellSize, demMap[c], demMap[se], demData, slopeAng[se]);
                        //if (!ifcut)
                        //{
                        //    total += (demMap[c] - demMap[se]) / 4;
                        //}
                        total += (demMap[c] - demMap[se]) / 4;
                    }
                    // ��(south)
                    if (!noDataMap[s] && demMap[s] < demMap[c])
                    {
                        //ifcut = IsCutDirection(cellSize, demMap[c], demMap[s], demData, slopeAng[s]);
                        //if (!ifcut)
                        //{
                        //    total += (demMap[c] - demMap[s]) / 2;
                        //}
                        total += (demMap[c] - demMap[s]) / 2;
                    }
                    // ����(south west)
                    if (!noDataMap[sw] && demMap[sw] < demMap[c])
                    {
                        //ifcut = IsCutDirection(diagCellSize, demMap[c], demMap[sw], demData, slopeAng[sw]);
                        //if (!ifcut)
                        //{
                        //    total += (demMap[c] - demMap[sw]) / 4;
                        //}
                        total += (demMap[c] - demMap[sw]) / 4;
                    }
                    // ��(west)
                    if (!noDataMap[w] && demMap[w] < demMap[c])
                    {
                        //ifcut = IsCutDirection(cellSize, demMap[c], demMap[w], demData, slopeAng[w]);
                        //if (!ifcut)
                        //{
                        //    total += (demMap[c] - demMap[w]) / 2;
                        //}
                        total += (demMap[c] - demMap[w]) / 2;
                    }

                    // ����Ȩֵ
                    if (total == 0.0f)
                    {
                        // ԭ���ϲ����ܳ��������������Ϊ�ݵ����ʱ�Ѿ������ֵ������
                        // ��������totalҪ����ĸ�����Ի����ж�һ�±ȽϺ�
                        // 
                        //MessageBox.Show(i.ToString());

                        if (!noDataMap[n] && !noDataMap[ne] && !noDataMap[e] && !noDataMap[se] && !noDataMap[s]
                            && !noDataMap[sw] && !noDataMap[w] && !noDataMap[nw])
                        {
                            if (demMap[c] == demMap[n] && outFlow[n].m_weight[Index.s] != OutFlow.NOOUT - 100)
                            {
                                outFlow[c].m_weight[Index.n] = OutFlow.NOOUT - 100;
                            }
                            else if (demMap[c] == demMap[ne] && outFlow[ne].m_weight[Index.sw] != OutFlow.NOOUT - 100)
                            {
                                outFlow[c].m_weight[Index.ne] = OutFlow.NOOUT - 100;
                            }
                            else if (demMap[c] == demMap[e] && outFlow[e].m_weight[Index.w] != OutFlow.NOOUT - 100)
                            {
                                outFlow[c].m_weight[Index.e] = OutFlow.NOOUT - 100;
                            }
                            else if (demMap[c] == demMap[se] && outFlow[se].m_weight[Index.nw] != OutFlow.NOOUT - 100)
                            {
                                outFlow[c].m_weight[Index.se] = OutFlow.NOOUT - 100;
                            }
                            else if (demMap[c] == demMap[s] && outFlow[s].m_weight[Index.n] != OutFlow.NOOUT - 100)
                            {
                                outFlow[c].m_weight[Index.s] = OutFlow.NOOUT - 100;
                            }
                            else if (demMap[c] == demMap[sw] && outFlow[sw].m_weight[Index.ne] != OutFlow.NOOUT - 100)
                            {
                                outFlow[c].m_weight[Index.sw] = OutFlow.NOOUT - 100;
                            }
                            else if (demMap[c] == demMap[w] && outFlow[w].m_weight[Index.e] != OutFlow.NOOUT - 100)
                            {
                                outFlow[c].m_weight[Index.w] = OutFlow.NOOUT - 100;
                            }
                            else if (demMap[c] == demMap[nw] && outFlow[nw].m_weight[Index.se] != OutFlow.NOOUT - 100)
                            {
                                outFlow[c].m_weight[Index.nw] = OutFlow.NOOUT - 100;
                            }
                            else
                            {
                                //��Χ��ƽ�����޷�����
                                //fixplatarea(c,cols);
                                bool iteraterly = true;
                                int c_now = c;
                                byte forbiddendir = 9;//û�з���
                                int nw_now, n_now, ne_now, w_now, e_now, sw_now, s_now, se_now;
                                while (iteraterly)
                                {
                                    nw_now = c_now - cols - 1;
                                    n_now = c_now - cols;
                                    ne_now = c_now - cols + 1;
                                    w_now = c_now - 1;
                                    e_now = c_now + 1;
                                    sw_now = c_now + cols - 1;
                                    s_now = c_now + cols;
                                    se_now = c_now + cols + 1;
                                    if (outFlow[c_now].m_weight[Index.nw] == OutFlow.NOOUT &&
                                    outFlow[c_now].m_weight[Index.n] == OutFlow.NOOUT &&
                                    outFlow[c_now].m_weight[Index.ne] == OutFlow.NOOUT &&
                                    outFlow[c_now].m_weight[Index.e] == OutFlow.NOOUT &&
                                    outFlow[c_now].m_weight[Index.se] == OutFlow.NOOUT &&
                                    outFlow[c_now].m_weight[Index.s] == OutFlow.NOOUT &&
                                    outFlow[c_now].m_weight[Index.sw] == OutFlow.NOOUT &&
                                    outFlow[c_now].m_weight[Index.w] == OutFlow.NOOUT)
                                    {
                                        if (demMap[c_now] == demMap[n_now] && outFlow[n_now].m_weight[Index.s] == OutFlow.NOOUT - 100 && forbiddendir != Index.n)
                                        {
                                            outFlow[c_now].m_weight[Index.n] = OutFlow.NOOUT - 100;
                                            outFlow[n_now].m_weight[Index.s] = OutFlow.NOOUT;
                                            forbiddendir = Index.s;
                                            c_now = n_now;
                                        }
                                        else if (demMap[c_now] == demMap[ne_now] && outFlow[ne_now].m_weight[Index.sw] == OutFlow.NOOUT - 100 && forbiddendir != Index.ne)
                                        {
                                            outFlow[c_now].m_weight[Index.ne] = OutFlow.NOOUT - 100;
                                            outFlow[ne_now].m_weight[Index.sw] = OutFlow.NOOUT;
                                            forbiddendir = Index.sw;
                                            c_now = ne_now;
                                        }
                                        else if (demMap[c_now] == demMap[e_now] && outFlow[e_now].m_weight[Index.w] == OutFlow.NOOUT - 100 && forbiddendir != Index.e)
                                        {
                                            outFlow[c_now].m_weight[Index.ne] = OutFlow.NOOUT - 100;
                                            outFlow[n_now].m_weight[Index.w] = OutFlow.NOOUT;
                                            forbiddendir = Index.w;
                                            c_now = e_now;
                                        }
                                        else if (demMap[c_now] == demMap[se_now] && outFlow[se_now].m_weight[Index.nw] == OutFlow.NOOUT - 100 && forbiddendir != Index.se)
                                        {
                                            outFlow[c_now].m_weight[Index.se] = OutFlow.NOOUT - 100;
                                            outFlow[se_now].m_weight[Index.nw] = OutFlow.NOOUT;
                                            forbiddendir = Index.nw;
                                            c_now = se_now;
                                        }
                                        else if (demMap[c_now] == demMap[s_now] && outFlow[s_now].m_weight[Index.n] == OutFlow.NOOUT - 100 && forbiddendir != Index.s)
                                        {
                                            outFlow[c_now].m_weight[Index.s] = OutFlow.NOOUT - 100;
                                            outFlow[s_now].m_weight[Index.n] = OutFlow.NOOUT;
                                            forbiddendir = Index.n;
                                            c_now = s_now;
                                        }
                                        else if (demMap[c_now] == demMap[sw_now] && outFlow[sw_now].m_weight[Index.ne] == OutFlow.NOOUT - 100 && forbiddendir != Index.sw)
                                        {
                                            outFlow[c_now].m_weight[Index.sw] = OutFlow.NOOUT - 100;
                                            outFlow[sw_now].m_weight[Index.ne] = OutFlow.NOOUT;
                                            forbiddendir = Index.ne;
                                            c_now = sw_now;
                                        }
                                        else if (demMap[c_now] == demMap[w_now] && outFlow[w_now].m_weight[Index.e] == OutFlow.NOOUT - 100 && forbiddendir != Index.w)
                                        {
                                            outFlow[c_now].m_weight[Index.w] = OutFlow.NOOUT - 100;
                                            outFlow[w_now].m_weight[Index.e] = OutFlow.NOOUT;
                                            forbiddendir = Index.e;
                                            c_now = w_now;
                                        }
                                        else if (demMap[c_now] == demMap[nw_now] && outFlow[nw_now].m_weight[Index.se] == OutFlow.NOOUT - 100 && forbiddendir != Index.nw)
                                        {
                                            outFlow[c_now].m_weight[Index.nw] = OutFlow.NOOUT - 100;
                                            outFlow[nw_now].m_weight[Index.se] = OutFlow.NOOUT;
                                            forbiddendir = Index.se;
                                            c_now = nw_now;
                                        }
                                        else
                                        {
                                            iteraterly = false;
                                        }

                                    }
                                    else
                                    {
                                        MessageBox.Show(i.ToString() + ";" + j.ToString());
                                    }
                                }
                            }
                        }
                    }
                    else
                    {
                        // ����(north west)
                        if (!noDataMap[nw] && demMap[nw] < demMap[c])
                        {
                            ifcut = IsCutDirection(diagCellSize, demMap[c], demMap[nw], demData, slopeAng[nw]);
                            temp = (demMap[c] - demMap[nw]) / 4;
                            if (ifcut)
                            {
                                // outFlow[c].m_weight[Index.nw] = OutFlow.NOOUT;
                                // Debug.WriteLine("A Cut point");                                
                                // ����100��    ,2010.08.13ȥ����0.005
                                outFlow[c].m_weight[Index.nw] = (byte)(255 - (int)(100 * (temp / total)));
                                //outFlow[c].m_weight[Index.nw] = (float)(255 - (int)(100 * (temp / total) + 0.5));
                                //outFlow[c].m_weight[Index.nw] = -100 * (temp / total);
                            }
                            else
                            {
                                //float temp = (demMap[c] - demMap[nw]) / 4;
                                // ����100��    
                                outFlow[c].m_weight[Index.nw] = (byte)(int)(100 * (temp / total));
                            }
                        }
                        // ��(north)
                        if (!noDataMap[n] && demMap[n] < demMap[c])
                        {
                            ifcut = IsCutDirection(cellSize, demMap[c], demMap[n], demData, slopeAng[n]);
                            temp = (demMap[c] - demMap[n]) / 2;
                            if (ifcut)
                            {
                                // outFlow[c].m_weight[Index.n] = OutFlow.NOOUT;
                                // Debug.WriteLine("A Cut point");
                                //float temp = (demMap[c] - demMap[n]) / 2;
                                outFlow[c].m_weight[Index.n] = (byte)(255 - (int)(100 * (temp / total)));
                                //outFlow[c].m_weight[Index.n] = -100 * (temp / total);
                            }
                            else
                            {
                                //float temp = (demMap[c] - demMap[n]) / 2;
                                outFlow[c].m_weight[Index.n] = (byte)(int)(100 * (temp / total));
                            }

                        }
                        // ����(north east)
                        if (!noDataMap[ne] && demMap[ne] < demMap[c])
                        {
                            ifcut = IsCutDirection(diagCellSize, demMap[c], demMap[ne], demData, slopeAng[ne]);
                            temp = (demMap[c] - demMap[ne]) / 4;
                            if (ifcut)
                            {
                                //  outFlow[c].m_weight[Index.ne] = OutFlow.NOOUT;
                                //Debug.WriteLine("A Cut point");
                                //float temp = (demMap[c] - demMap[ne]) / 4;
                                outFlow[c].m_weight[Index.ne] = (byte)(255 - (int)(100 * (temp / total)));
                                //outFlow[c].m_weight[Index.ne] = -100 * (temp / total);
                            }
                            else
                            {
                                //float temp = (demMap[c] - demMap[ne]) / 4;
                                outFlow[c].m_weight[Index.ne] = (byte)(int)(100 * (temp / total));
                            }
                        }
                        // ��(east)
                        if (!noDataMap[e] && demMap[e] < demMap[c])
                        {
                            ifcut = IsCutDirection(cellSize, demMap[c], demMap[e], demData, slopeAng[e]);
                            temp = (demMap[c] - demMap[e]) / 2;
                            if (ifcut)
                            {
                                // outFlow[c].m_weight[Index.e] = OutFlow.NOOUT;
                                // Debug.WriteLine("A Cut point");
                                //float temp = (demMap[c] - demMap[e]) / 2;
                                outFlow[c].m_weight[Index.e] = (byte)(255 - (int)(100 * (temp / total)));
                                //outFlow[c].m_weight[Index.e] = -100 * (temp / total);
                            }
                            else
                            {
                                //float temp = (demMap[c] - demMap[e]) / 2;
                                outFlow[c].m_weight[Index.e] = (byte)(int)(100 * (temp / total));
                            }
                        }
                        // ����(north east)
                        if (!noDataMap[se] && demMap[se] < demMap[c])
                        {
                            ifcut = IsCutDirection(diagCellSize, demMap[c], demMap[se], demData, slopeAng[se]);
                            temp = (demMap[c] - demMap[se]) / 4;
                            if (ifcut)
                            {
                                // outFlow[c].m_weight[Index.se] = OutFlow.NOOUT;
                                // Debug.WriteLine("A Cut point");
                                //float temp = (demMap[c] - demMap[se]) / 4;
                                outFlow[c].m_weight[Index.se] = (byte)(255 - (int)(100 * (temp / total)));
                                //outFlow[c].m_weight[Index.se] = -100 * (temp / total);
                            }
                            else
                            {
                                //float temp = (demMap[c] - demMap[se]) / 4;
                                outFlow[c].m_weight[Index.se] = (byte)(int)(100 * (temp / total));
                            }
                        }
                        // ��(south)
                        if (!noDataMap[s] && demMap[s] < demMap[c])
                        {
                            ifcut = IsCutDirection(cellSize, demMap[c], demMap[s], demData, slopeAng[s]);
                            temp = (demMap[c] - demMap[s]) / 2;
                            if (ifcut)
                            {
                                // outFlow[c].m_weight[Index.s] = OutFlow.NOOUT;
                                // Debug.WriteLine("A Cut point");
                                //float temp = (demMap[c] - demMap[s]) / 2;
                                outFlow[c].m_weight[Index.s] = (byte)(255 - (int)(100 * (temp / total)));
                                //outFlow[c].m_weight[Index.s] = -100 * (temp / total);
                            }
                            else
                            {
                                //float temp = (demMap[c] - demMap[s]) / 2;
                                outFlow[c].m_weight[Index.s] = (byte)(int)(100 * (temp / total));
                            }
                        }
                        // ����(south west)
                        if (!noDataMap[sw] && demMap[sw] < demMap[c])
                        {
                            ifcut = IsCutDirection(diagCellSize, demMap[c], demMap[sw], demData, slopeAng[sw]);
                            temp = (demMap[c] - demMap[sw]) / 4;
                            if (ifcut)
                            {
                                // outFlow[c].m_weight[Index.sw] = OutFlow.NOOUT;
                                // Debug.WriteLine("A Cut point");
                                //float temp = (demMap[c] - demMap[sw]) / 4;
                                outFlow[c].m_weight[Index.sw] = (byte)(255 - (int)(100 * (temp / total)));
                                //outFlow[c].m_weight[Index.sw] = -100 * (temp / total);
                            }
                            else
                            {
                                //float temp = (demMap[c] - demMap[sw]) / 4;
                                outFlow[c].m_weight[Index.sw] = (byte)(int)(100 * (temp / total));
                            }
                        }
                        // ��(west)
                        if (!noDataMap[w] && demMap[w] < demMap[c])
                        {
                            ifcut = IsCutDirection(cellSize, demMap[c], demMap[w], demData, slopeAng[w]);
                            temp = (demMap[c] - demMap[w]) / 2;
                            if (ifcut)
                            {
                                // outFlow[c].m_weight[Index.w] = OutFlow.NOOUT;
                                // Debug.WriteLine("A Cut point");
                                //float temp = (demMap[c] - demMap[w]) / 2;
                                outFlow[c].m_weight[Index.w] = (byte)(255 - (int)(100 * (temp / total)));
                                //outFlow[c].m_weight[Index.w] = -100 * (temp / total);
                            }
                            else
                            {
                                //float temp = (demMap[c] - demMap[w]) / 2;
                                outFlow[c].m_weight[Index.w] = (byte)(int)(100 * (temp / total));
                            }
                        }

                    }
                }
            }
        }
        //2011�����˺��������д���ƽ̹����ĺ���
        
        public void fixplatarea(int c, int cols)
        {

        }

        //�ź������Ӻ�����ȡ2011.01.25��ȡ������Ҫ�Ĺ������ǽ��ضϼӵ����еĵ�Ȩֵ�����У�ʹ���ں������������ֱ��ʹ��

        public void CalcChannelNetworks(DemData dd, ref float[] Cumlen_ChannelNetworks,OutFlow[] outflow,bool[] nd)//nd��nodatamap
        {
            int rows; // Number of rows.
            int cols; // Number of columns.
            int count = 0; //��¼ѭ������
            int hits = 0, hits1 = 0;
            int nw, n, ne, w, c, e, sw, s, se;
            float inicumarea = 0.01f;//ÿ����Ԫ������
            bool done = false;
            float cumarea;
            //float cellsize;
            //float diagcellsize;

            rows = dd.imagNrows;
            cols = dd.imagNcols;
            //cellsize = dd.cellSize;
            //diagcellsize = (float)Math.Sqrt(2.0) * dd.cellSize;
            for (int i = 2; i < rows - 2; i++)
            {
                for (int j = 2; j < cols - 2; j++)
                {
                    c = i * cols + j;
                    if (nd[c])
                    {
                        Cumlen_ChannelNetworks[c] = 0.0f;
                        continue;
                    } //�����ֵ�������ô�ѭ��
                    Cumlen_ChannelNetworks[c] = inicumarea;
                }
            }

            while (!done && count < 10000)//2014.4.9 ����
            {
                count++;
                done = true;
                hits = 0;
                for (int i = 2; i < rows - 2; i++)
                {
                    for (int j = 2; j < cols - 2; j++)
                    {
                        c = i * cols + j;
                        if (nd[c])
                        {
                            continue;
                        } //�����ֵ�������ô�ѭ��
                        nw = c - cols - 1;
                        n = c - cols;
                        ne = c - cols + 1;
                        w = c - 1;
                        e = c + 1;
                        sw = c + cols - 1;
                        s = c + cols;
                        se = c + cols + 1;
                        cumarea = 0.0f;
                        // ����Ȩֵ���䣬Ȼ���ۻ�
                        // ��
                        if (outflow[w].m_weight[Index.e] != OutFlow.NOOUT)
                        {
                            if (outflow[w].m_weight[Index.e] <= 100)
                                cumarea += ((float)(outflow[w].m_weight[Index.e] * Cumlen_ChannelNetworks[w])) / 100;
                            else
                                cumarea += ((float)((OutFlow.NOOUT - outflow[w].m_weight[Index.e]) * Cumlen_ChannelNetworks[w])) / 100;
                        }
                        // ����
                        if (outflow[nw].m_weight[Index.se] != OutFlow.NOOUT)
                        {
                            if (outflow[nw].m_weight[Index.se] <= 100)
                                cumarea += ((float)(outflow[nw].m_weight[Index.se] * Cumlen_ChannelNetworks[nw])) / 100;
                            else
                                cumarea += ((float)((OutFlow.NOOUT - outflow[nw].m_weight[Index.se]) * Cumlen_ChannelNetworks[nw])) / 100;
                        }
                        // ��
                        if (outflow[n].m_weight[Index.s] != OutFlow.NOOUT)
                        {
                            if (outflow[n].m_weight[Index.s] <= 100)
                                cumarea += ((float)(outflow[n].m_weight[Index.s] * Cumlen_ChannelNetworks[n])) / 100;
                            else
                                cumarea += ((float)((OutFlow.NOOUT - outflow[n].m_weight[Index.s]) * Cumlen_ChannelNetworks[n])) / 100;

                        }
                        // ����
                        if (outflow[ne].m_weight[Index.sw] != OutFlow.NOOUT)
                        {
                            if (outflow[ne].m_weight[Index.sw] <= 100)
                                cumarea += ((float)(outflow[ne].m_weight[Index.sw] * Cumlen_ChannelNetworks[ne])) / 100;
                            else
                                cumarea += ((float)((OutFlow.NOOUT - outflow[ne].m_weight[Index.sw]) * Cumlen_ChannelNetworks[ne])) / 100;
                        }
                        // ��
                        if (outflow[e].m_weight[Index.w] != OutFlow.NOOUT)
                        {
                            if (outflow[e].m_weight[Index.w] <= 100)
                                cumarea += (float)(outflow[e].m_weight[Index.w] * Cumlen_ChannelNetworks[e]) / 100;
                            else
                                cumarea += (float)((OutFlow.NOOUT - outflow[e].m_weight[Index.w]) * Cumlen_ChannelNetworks[e]) / 100;
                        }
                        // ����
                        if (outflow[se].m_weight[Index.nw] != OutFlow.NOOUT)
                        {
                            if (outflow[se].m_weight[Index.nw] <= 100)
                                cumarea += (float)(outflow[se].m_weight[Index.nw] * Cumlen_ChannelNetworks[se]) / 100;
                            else
                                cumarea += (float)((OutFlow.NOOUT - outflow[se].m_weight[Index.nw]) * Cumlen_ChannelNetworks[se]) / 100;
                        }
                        // ��
                        if (outflow[s].m_weight[Index.n] != OutFlow.NOOUT)
                        {
                            if (outflow[s].m_weight[Index.n] <= 100)
                                cumarea += (float)(outflow[s].m_weight[Index.n] * Cumlen_ChannelNetworks[s]) / 100;
                            else
                                cumarea += (float)((OutFlow.NOOUT - outflow[s].m_weight[Index.n]) * Cumlen_ChannelNetworks[s]) / 100;
                        }
                        // ����
                        if (outflow[sw].m_weight[Index.ne] != OutFlow.NOOUT)
                        {
                            if (outflow[sw].m_weight[Index.ne] <= 100)
                                cumarea += (float)(outflow[sw].m_weight[Index.ne] * Cumlen_ChannelNetworks[sw]) / 100;
                            else
                                cumarea += (float)((OutFlow.NOOUT - outflow[sw].m_weight[Index.ne]) * Cumlen_ChannelNetworks[sw]) / 100;
                        }
                        if (cumarea > 0.0)
                        {
                            cumarea += inicumarea;
                            if (cumarea > Cumlen_ChannelNetworks[c])
                            {
                                hits++;
                                done = false;
                                Cumlen_ChannelNetworks[c] = cumarea;
                            }
                        }
                    }
                }

                if (hits == hits1)
                    count = 10000;
                hits1 = hits;
                hits = 0;
                // �������
                for (int i = rows - 3; i >= 2; i--)
                {
                    // SECOND PART
                    for (int j = cols - 3; j >= 2; j--)
                    {
                        c = i * cols + j;
                        if (nd[c])
                        {
                            continue;
                        } //�����ֵ�������ô�ѭ��
                        nw = c - cols - 1;
                        n = c - cols;
                        ne = c - cols + 1;
                        w = c - 1;
                        e = c + 1;
                        sw = c + cols - 1;
                        s = c + cols;
                        se = c + cols + 1;
                        cumarea = 0.0f;
                        // ����Ȩֵ���䣬Ȼ���ۻ�
                        // ��
                        if (outflow[w].m_weight[Index.e] != OutFlow.NOOUT)
                        {
                            if (outflow[w].m_weight[Index.e] <= 100)
                                cumarea += ((float)(outflow[w].m_weight[Index.e] * Cumlen_ChannelNetworks[w])) / 100;
                            else
                                cumarea += ((float)((OutFlow.NOOUT - outflow[w].m_weight[Index.e]) * Cumlen_ChannelNetworks[w])) / 100;
                        }
                        // ����
                        if (outflow[nw].m_weight[Index.se] != OutFlow.NOOUT)
                        {
                            if (outflow[nw].m_weight[Index.se] <= 100)
                                cumarea += ((float)(outflow[nw].m_weight[Index.se] * Cumlen_ChannelNetworks[nw])) / 100;
                            else
                                cumarea += ((float)((OutFlow.NOOUT - outflow[nw].m_weight[Index.se]) * Cumlen_ChannelNetworks[nw])) / 100;
                        }
                        // ��
                        if (outflow[n].m_weight[Index.s] != OutFlow.NOOUT)
                        {
                            if (outflow[n].m_weight[Index.s] <= 100)
                                cumarea += ((float)(outflow[n].m_weight[Index.s] * Cumlen_ChannelNetworks[n])) / 100;
                            else
                                cumarea += ((float)((OutFlow.NOOUT - outflow[n].m_weight[Index.s]) * Cumlen_ChannelNetworks[n])) / 100;

                        }
                        // ����
                        if (outflow[ne].m_weight[Index.sw] != OutFlow.NOOUT)
                        {
                            if (outflow[ne].m_weight[Index.sw] <= 100)
                                cumarea += ((float)(outflow[ne].m_weight[Index.sw] * Cumlen_ChannelNetworks[ne])) / 100;
                            else
                                cumarea += ((float)((OutFlow.NOOUT - outflow[ne].m_weight[Index.sw]) * Cumlen_ChannelNetworks[ne])) / 100;
                        }
                        // ��
                        if (outflow[e].m_weight[Index.w] != OutFlow.NOOUT)
                        {
                            if (outflow[e].m_weight[Index.w] <= 100)
                                cumarea += (float)(outflow[e].m_weight[Index.w] * Cumlen_ChannelNetworks[e]) / 100;
                            else
                                cumarea += (float)((OutFlow.NOOUT - outflow[e].m_weight[Index.w]) * Cumlen_ChannelNetworks[e]) / 100;
                        }
                        // ����
                        if (outflow[se].m_weight[Index.nw] != OutFlow.NOOUT)
                        {
                            if (outflow[se].m_weight[Index.nw] <= 100)
                                cumarea += (float)(outflow[se].m_weight[Index.nw] * Cumlen_ChannelNetworks[se]) / 100;
                            else
                                cumarea += (float)((OutFlow.NOOUT - outflow[se].m_weight[Index.nw]) * Cumlen_ChannelNetworks[se]) / 100;
                        }
                        // ��
                        if (outflow[s].m_weight[Index.n] != OutFlow.NOOUT)
                        {
                            if (outflow[s].m_weight[Index.n] <= 100)
                                cumarea += (float)(outflow[s].m_weight[Index.n] * Cumlen_ChannelNetworks[s]) / 100;
                            else
                                cumarea += (float)((OutFlow.NOOUT - outflow[s].m_weight[Index.n]) * Cumlen_ChannelNetworks[s]) / 100;
                        }
                        // ����
                        if (outflow[sw].m_weight[Index.ne] != OutFlow.NOOUT)
                        {
                            if (outflow[sw].m_weight[Index.ne] <= 100)
                                cumarea += (float)(outflow[sw].m_weight[Index.ne] * Cumlen_ChannelNetworks[sw]) / 100;
                            else
                                cumarea += (float)((OutFlow.NOOUT - outflow[sw].m_weight[Index.ne]) * Cumlen_ChannelNetworks[sw]) / 100;
                        }
                        if (cumarea > 0.0)
                        {
                            cumarea += inicumarea;
                            if (cumarea > Cumlen_ChannelNetworks[c])
                            {
                                hits++;
                                done = false;
                                Cumlen_ChannelNetworks[c] = cumarea;
                            }
                        }
                    }
                }
            }
            LogCumulativeProgress(count, hits1, hits);
        }
        //20110126�ź������Ӻ�����ȡ��ֱ���޸�Ȩֵ�ļ���ʹ�����Ĳ�����ȫ������Ȩֵ�ļ��У�ʡ���ڴ�ռ�
        //2014 4 10 �о����øġ���
        public void RedownWeight(DemData demData, float threshold, float[] Cumlen_ChannelNetworks, ref OutFlow[] outflow, bool[] nd)
        {

            int rows = demData.imagNrows;
            int cols = demData.imagNcols;
            int nw, n, ne, w, c, e, sw, s, se;
            threshold = (threshold / 100) / (demData.cellSize * demData.cellSize);
            //�ڼ������ʱ��Ĭ��ÿ����Ԫ��Ϊ0.01ƽ���ף��˴�����ת����threshold��Ϊ�����Ǽ�����Ԫ��Ϊ��ֵ
            for (int i = 2; i < rows - 2; i++)
            {
                for (int j = 2; j < cols - 2; j++)
                {
                    c = i * cols + j;
                    if (nd[c])
                    {
                        //Cumlen_ChannelNetworks[c] = 0.0f;
                        continue;
                    } //�����ֵ�������ô�ѭ��
                    nw = c - cols - 1;
                    n = c - cols;
                    ne = c - cols + 1;
                    w = c - 1;
                    e = c + 1;
                    sw = c + cols - 1;
                    s = c + cols;
                    se = c + cols + 1;
                    //outflow[c] = inicumarea;
                    //��
                    if (outflow[e].m_weight[Index.w] != OutFlow.NOOUT && outflow[e].m_weight[Index.w] <= 100 && Cumlen_ChannelNetworks[c] >= threshold)
                    {
                        outflow[e].m_weight[Index.w] = (byte)(OutFlow.NOOUT - outflow[e].m_weight[Index.w]);
                    }
                    // ����
                    if (outflow[se].m_weight[Index.nw] != OutFlow.NOOUT && outflow[se].m_weight[Index.nw] <= 100 && Cumlen_ChannelNetworks[c] >= threshold)
                    {
                        outflow[se].m_weight[Index.nw] = (byte)(OutFlow.NOOUT - outflow[se].m_weight[Index.nw]);
                    }
                    // ��
                    if (outflow[s].m_weight[Index.n] != OutFlow.NOOUT && outflow[s].m_weight[Index.n] <= 100 && Cumlen_ChannelNetworks[c] >= threshold)
                    {
                        outflow[s].m_weight[Index.n] = (byte)(OutFlow.NOOUT - outflow[s].m_weight[Index.n]);
                    }
                    // ����
                    if (outflow[sw].m_weight[Index.ne] != OutFlow.NOOUT && outflow[sw].m_weight[Index.ne] <= 100 && Cumlen_ChannelNetworks[c] >= threshold)
                    {
                        outflow[sw].m_weight[Index.ne] = (byte)(OutFlow.NOOUT - outflow[sw].m_weight[Index.ne]);
                    }
                    // ��
                    if (outflow[w].m_weight[Index.e] != OutFlow.NOOUT && outflow[w].m_weight[Index.e] <= 100 && Cumlen_ChannelNetworks[c] >= threshold)
                    {
                        outflow[w].m_weight[Index.e] = (byte)(OutFlow.NOOUT - outflow[w].m_weight[Index.e]);
                    }
                    // ����
                    if (outflow[nw].m_weight[Index.se] != OutFlow.NOOUT && outflow[nw].m_weight[Index.se] <= 100 && Cumlen_ChannelNetworks[c] >= threshold)
                    {
                        outflow[nw].m_weight[Index.se] = (byte)(OutFlow.NOOUT - outflow[nw].m_weight[Index.se]);
                    }
                    // ��
                    if (outflow[n].m_weight[Index.s] != OutFlow.NOOUT && outflow[n].m_weight[Index.s] <= 100 && Cumlen_ChannelNetworks[c] >= threshold)
                    {
                        outflow[n].m_weight[Index.s] = (byte)(OutFlow.NOOUT - outflow[n].m_weight[Index.s]);
                    }
                    // ����
                    if (outflow[ne].m_weight[Index.sw] != OutFlow.NOOUT && outflow[ne].m_weight[Index.sw] <= 100 && Cumlen_ChannelNetworks[c] >= threshold)
                    {
                        outflow[ne].m_weight[Index.sw] = (byte)(OutFlow.NOOUT - outflow[ne].m_weight[Index.sw]);
                    }
                }
            }
        }



        /* zhangjie,2010.06.20
         * zhangjie,2010.07.03�޸�
         * �ж϶�����ضϷ���
         */
        public bool IsCutDirection(float cell, float centerDEM,float otherDEM,DemData demData,float otherAng)
        {
            float deg = (float)57.29577951308;
            // �����¶�
            float angle = deg * (float)Math.Atan((centerDEM - otherDEM) / cell);
            float slpEndFactor = angle < 2.8624 ? demData.scf_lt5 : demData.scf_ge5;
            bool ifcut = otherAng < angle * slpEndFactor;
            return ifcut;
        }

        public void SetInFlowByWeigth(DemData dd, ref bool[] noDataMap, ref OutFlow[] outFlow, ref byte[] inMap)
        {

            int rows; // Number of rows.
            int cols; // Number of columns.
            int nw, n, ne, w, c, e, sw, s, se;
            rows = dd.imagNrows;
            cols = dd.imagNcols;
            for (int i = 2; i < rows - 2; i++)
            {
                for (int j = 2; j < cols - 2; j++)
                {
                    c = i * cols + j;
                    inMap[c] = 0;
                    if (noDataMap[c])
                    {
                        continue;
                    }
                    nw = c - cols - 1;
                    n = c - cols;
                    ne = c - cols + 1;
                    w = c - 1;
                    e = c + 1;
                    sw = c + cols - 1;
                    s = c + cols;
                    se = c + cols + 1;
                    //2010.08.14ֻҪ��һ������ضϾͳ���ȫ���ϵ�
                    //����
                    //if (outFlow[nw].m_weight[Index.se] <= (byte)100 && outFlow[nw].m_weight[Index.se] >= (byte)0)
                    //{
                    //    inMap[c] += GlobalConstants.NW;
                    //}
                    //else if(outFlow[nw].m_weight[Index.se] != OutFlow.NOOUT)
                    //{
                    //    inMap[c] = 0;
                    //    continue;
                    //}
                    ////��
                    //if (outFlow[n].m_weight[Index.s] <= (byte)100 && outFlow[n].m_weight[Index.s] >= (byte)0)
                    //{
                    //    inMap[c] += GlobalConstants.N;
                    //}
                    //else if (outFlow[n].m_weight[Index.s]!=OutFlow.NOOUT)
                    //{
                    //    inMap[c] = 0;
                    //    continue;
                    //}
                    ////����
                    //if (outFlow[ne].m_weight[Index.sw] <= (byte)100 && outFlow[ne].m_weight[Index.sw] >= (byte)0)
                    //{
                    //    inMap[c] += GlobalConstants.NE;
                    //}
                    //else if (outFlow[ne].m_weight[Index.sw] != OutFlow.NOOUT)
                    //{
                    //    inMap[c] = 0;
                    //    continue;
                    //}
                    ////��
                    //if (outFlow[e].m_weight[Index.w] <= (byte)100 && outFlow[e].m_weight[Index.w] >= (byte)0)
                    //{
                    //    inMap[c] += GlobalConstants.E;
                    //}
                    //else if (outFlow[e].m_weight[Index.w] != OutFlow.NOOUT)
                    //{
                    //    inMap[c] = 0;
                    //    continue;
                    //}
                    ////����
                    //if (outFlow[se].m_weight[Index.nw] <= (byte)100 && outFlow[se].m_weight[Index.nw] >= (byte)0)
                    //{
                    //    inMap[c] += GlobalConstants.SE;
                    //}
                    //else if (outFlow[se].m_weight[Index.nw] != OutFlow.NOOUT)
                    //{
                    //    inMap[c] = 0;
                    //    continue;
                    //}
                    ////��
                    //if (outFlow[s].m_weight[Index.n] <= (byte)100 && outFlow[s].m_weight[Index.n] >= (byte)0)
                    //{   
                    //    inMap[c] += GlobalConstants.S;
                    //}
                    //else if (outFlow[s].m_weight[Index.n] != OutFlow.NOOUT)
                    //{
                    //    inMap[c] = 0;
                    //    continue;
                    //}
                    ////����
                    //if (outFlow[sw].m_weight[Index.ne] <= (byte)100 && outFlow[sw].m_weight[Index.ne] >= (byte)0)
                    //{
                    //    inMap[c] += GlobalConstants.SW;
                    //}
                    //else if (outFlow[sw].m_weight[Index.ne] != OutFlow.NOOUT)
                    //{
                    //    inMap[c] = 0;
                    //    continue;
                    //}
                    ////��
                    //if (outFlow[w].m_weight[Index.e] <= (byte)100 && outFlow[w].m_weight[Index.e] >= (byte)0)
                    //{
                    //    inMap[c] += GlobalConstants.W;
                    //}
                    //else if (outFlow[w].m_weight[Index.e] != OutFlow.NOOUT)
                    //{
                    //    inMap[c] = 0;
                    //    continue;
                    //}
                    //����
                    if (outFlow[nw].m_weight[Index.se] <= (byte)100 && outFlow[nw].m_weight[Index.se] > (byte)0)
                        inMap[c] += GlobalConstants.NW;
                    //��
                    if (outFlow[n].m_weight[Index.s] <= (byte)100 && outFlow[n].m_weight[Index.s] > (byte)0)
                        inMap[c] += GlobalConstants.N;
                    //����
                    if (outFlow[ne].m_weight[Index.sw] <= (byte)100 && outFlow[ne].m_weight[Index.sw] > (byte)0)
                        inMap[c] += GlobalConstants.NE;
                    //��
                    if (outFlow[e].m_weight[Index.w] <= (byte)100 && outFlow[e].m_weight[Index.w] > (byte)0)
                        inMap[c] += GlobalConstants.E;
                    //����
                    if (outFlow[se].m_weight[Index.nw] <= (byte)100 && outFlow[se].m_weight[Index.nw] > (byte)0)
                        inMap[c] += GlobalConstants.SE;
                    //��
                    if (outFlow[s].m_weight[Index.n] <= (byte)100 && outFlow[s].m_weight[Index.n] > (byte)0)
                        inMap[c] += GlobalConstants.S;
                    //����
                    if (outFlow[sw].m_weight[Index.ne] <= (byte)100 && outFlow[sw].m_weight[Index.ne] > (byte)0)
                        inMap[c] += GlobalConstants.SW;
                    //��
                    if (outFlow[w].m_weight[Index.e] <= (byte)100 && outFlow[w].m_weight[Index.e] > (byte)0)
                        inMap[c] += GlobalConstants.W;
                }
            }
        }


        /*public void InitCumulativeLength(DemData dd, float[] demMap, bool[] noDataMap,ref float[] cumlen,ref float[] inicumlen ,byte[] inFlow,bool flowcut)
        {
            int i; //  Loop Counter.
            int j; //  Loop Counter.
            int c; //  Cell Index value  
            int rows; //  Number of rows.
            int cols; //  Number of columns. 
            float cellorth; //  Width of cell in cardinal direction
            rows = dd.imagNrows;
            cols = dd.imagNcols;
            float deg = (float)57.29577951308;

            cellorth = dd.cellSize; //��Ԫ�񳤶�
            float cellsize = dd.cellSize;
            int nw, n, ne, w, e, sw, s, se;
            float A = 0;
            float z1, z2, z3, z4, z5, z6, z7, z8, z9;
            float fx;
            float fy;

            for (i = 2; i < rows - 2; i++)
            {
                for (j = 2; j < cols - 2; j++)
                {

                    c = i * cols + j;
                    cumlen[c] = (float)0.0;
                    if (noDataMap[c] == true)
                    {
                        continue;
                    }
                    nw = c - cols - 1;
                    n = c - cols;
                    ne = c - cols + 1;
                    w = c - 1;
                    e = c + 1;
                    sw = c + cols - 1;
                    s = c + cols;
                    se = c + cols + 1;

                    // ��ֵ��ʼ��
                    z1 = demMap[c];
                    z1 = z2 = z3 = z4 = z5 = z6 = z7 = z8 = z9 = demMap[c];
                    fx = fy = 0.0f;
                    //��(west)
                    if (noDataMap[w] == false)
                    {
                        z4 = demMap[w];
                    }
                    //����(north west)
                    if (noDataMap[nw] == false)
                    {
                        z7 = demMap[nw];
                    }
                    //��(north)
                    if (noDataMap[n] == false)
                    {
                        z8 = demMap[n];
                    }
                    // ����(north east)
                    if (noDataMap[ne] == false)
                    {
                        z9 = demMap[ne];
                    }
                    // ��(east)
                    if (noDataMap[e] == false)
                    {
                        z6 = demMap[e];
                    }
                    // ����(south east)
                    if (noDataMap[se] == false)
                    {
                        z3 = demMap[se];
                    }
                    // ��(south)
                    if (noDataMap[s] == false)
                    {
                        z2 = demMap[s];
                    }
                    // ����(south west)
                    if (noDataMap[sw] == false)
                    {
                        z1 = demMap[sw];
                    }
                    //fx = (z7 - z1 + z8 - z2 + z9 - z3) / (6 * cellsize);
                    //fy = (z3 - z1 + z6 - z4 + z9 - z7) / (6 * cellsize);
                    //����2010.08.13
                    fx = (z7 - z1 + 2 * (z8 - z2) + z9 - z3) / (8 * cellsize);
                    fy = (z3 - z1 + 2 * (z6 - z4) + z9 - z7) / (8 * cellsize);

                    if (fx == 0.0f)
                    {

                        if (flowcut)
                        {
                            if (inFlow[c] == 0)
                            {
                                cumlen[c] = cellsize / 2;
                            }
                            else
                            {
                                cumlen[c] = cellsize;
                            }
                        }
                        else
                        {
                            cumlen[c] = cellsize;
                        }
                        inicumlen[c] = cumlen[c];
                    }
                    else
                    {

                        // A = 270��+ arctan ( fy / fx ) - 90��fx / |fx|
                        A = 270 + deg * (float)Math.Atan(fy / fx) - 90 * (fx / Math.Abs(fx)); // A��������

                        //while (true)
                        //{
                        //    if (A > 360)
                        //    {
                        //        A = A - 360; // �������Ӧ��û��
                        //    }
                        //    else
                        //        break;
                        //else
                        //{
                        //    if (A >= 315)
                        //        A = A;
                        //    else if (A >= 225)
                        //        A = Math.Abs(270 - A);
                        //    else if (A >= 135)
                        //        A = A;
                        //    else if (A >= 45)
                        //        A = Math.Abs(90 - A);
                        //    break;
                        //}20110629ȥ���ĺ���Ϊsin+cos
                        //}

                              //if (A > 45 && A < 135 || A > 225 && A < 315)
                        {
                            Debug.WriteLine("A = " + A);
                        }
                        if ((float)Math.Abs(Math.Cos(Math.PI * A / 180.0)) < 0.7)
                        {
                            Debug.WriteLine("cos(a) = " + (float)Math.Abs(Math.Cos(Math.PI * A / 180.0)));
                               // }
                        //20110629ȥ������Ϊsin+cos
                        //cumlen[c] = cellsize / (float)Math.Abs(Math.Cos(Math.PI * A / 180.0));
                        cumlen[c] = cellsize * ((float)Math.Abs(Math.Cos(Math.PI * A / 180.0)) + (float)Math.Abs(Math.Sin(Math.PI * A / 180.0)));
                        if (flowcut)//����ض�
                        {
                            if (inFlow[c] == 0)
                            {
                                cumlen[c] = cumlen[c] / 2;
                            }
                        }
                        inicumlen[c] = cumlen[c];
                        //}
                        //else//û�нض�
                        //{
                        //    inicumlen[c] = cumlen[c];
                        //}

                    }
                }
            }
        }*/
       
        //�ۻ����ֵ
        //public void CalcCumulativeLength(DemData dd, OutFlow[] outflow, bool[] nd, ref float[] cumlen, float[] inicumlen)
        //{
        //    int rows; // Number of rows.
        //    int cols; // Number of columns.
        //    int count = 0; //��¼ѭ������
        //    int hits = 0, hits1 = 0;
        //    int nw, n, ne, w, c, e, sw, s, se;
        //    bool done = false;
        //    float cumlength;
        //    float maxlength;//���ڼ�¼��Χ����³�
        //    float currentlength;//���ڼ�¼��ǰ�����ϵ��³�
        //    float cellsize;
        //    float diagcellsize;

        //    rows = dd.imagNrows;
        //    cols = dd.imagNcols;
        //    cellsize = dd.cellSize;
        //    diagcellsize = (float)Math.Sqrt(2.0) * dd.cellSize;
        //    int fixnum = (int)(dd.imagNrows - 2) * (dd.imagNcols) /1000;
        //    float[] array_fix = new float[fixnum];
        //    //float setmax = 0;
        //    float setmin = dd.cellSize;
        //    //float classify_num = 10;
        //    while (!done && count < 10000)
        //    {
        //        count++;
        //        done = true;
        //        hits = 0;   
        //        for (int i = 2; i < rows - 2; i++)
        //        {
        //            for (int j = 2; j < cols - 2; j++)
        //            {
        //                c = i * cols + j;
        //                if (nd[c])
        //                {
        //                    continue;
        //                } //�����ֵ�������ô�ѭ��
        //                nw = c - cols - 1;
        //                n = c - cols;
        //                ne = c - cols + 1;
        //                w = c - 1;
        //                e = c + 1;
        //                sw = c + cols - 1;
        //                s = c + cols;
        //                se = c + cols + 1;
        //                cumlength = 0.0f;
        //                maxlength = 0.0f;
        //                currentlength = 0.0f;
        //                // ����Ȩֵ���䣬Ȼ���ۻ�
        //                // ��
        //                //if (i == 125)
        //                //{
        //                //   MessageBox.Show(j.ToString());
        //                //}
        //                if (outflow[w].m_weight[Index.e] != OutFlow.NOOUT
        //                    && outflow[w].m_weight[Index.e] <= (byte)100 && outflow[w].m_weight[Index.e] > (byte)0)
        //                    {
        //                        currentlength= ((float)(outflow[w].m_weight[Index.e] * cumlen[w])) / 100;
        //                        cumlength += currentlength;
        //                        if (maxlength < currentlength)
        //                        {
        //                            maxlength = currentlength;
        //                        }
        //                    }
        //                    //else
        //                    //{
        //                    //    cumlength -= ((float)((255-outflow[w].m_weight[Index.e]) * cumlen[w])) / 100;
        //                    //}
        //                // ����
        //                if (outflow[nw].m_weight[Index.se] != OutFlow.NOOUT
        //                    && outflow[nw].m_weight[Index.se] <= (byte)100 && outflow[nw].m_weight[Index.se] > (byte)0)
        //                {
        //                    currentlength = ((float)(outflow[nw].m_weight[Index.se] * cumlen[nw])) / 100;
        //                    cumlength += currentlength;
        //                    if (maxlength < currentlength)
        //                    {
        //                        maxlength = currentlength;
        //                    }
        //                }
        //                // ��
        //                if (outflow[n].m_weight[Index.s] != OutFlow.NOOUT
        //                     && outflow[n].m_weight[Index.s] <= (byte)100 && outflow[n].m_weight[Index.s] > (byte)0)
        //                {
        //                    currentlength = ((float)(outflow[n].m_weight[Index.s] * cumlen[n])) / 100;
        //                    cumlength += currentlength;
        //                    if (maxlength < currentlength)
        //                    {
        //                        maxlength = currentlength;
        //                    }
        //                }
        //                // ����
        //                if (outflow[ne].m_weight[Index.sw] != OutFlow.NOOUT
        //                     && outflow[ne].m_weight[Index.sw] <= (byte)100 && outflow[ne].m_weight[Index.sw] > (byte)0)
        //                {
        //                    currentlength = ((float)(outflow[ne].m_weight[Index.sw] * cumlen[ne])) / 100;
        //                    cumlength += currentlength;
        //                    if (maxlength < currentlength)
        //                    {
        //                        maxlength = currentlength;
        //                    }
        //                }
        //                // ��
        //                if (outflow[e].m_weight[Index.w] != OutFlow.NOOUT
        //                    && outflow[e].m_weight[Index.w] <= (byte)100 && outflow[e].m_weight[Index.w] > (byte)0)
        //                {
        //                    currentlength = (float)(outflow[e].m_weight[Index.w] * cumlen[e]) / 100;
        //                    cumlength += currentlength;
        //                    if (maxlength < currentlength)
        //                    {
        //                        maxlength = currentlength;
        //                    }
        //                }
        //                // ����
        //                if (outflow[se].m_weight[Index.nw] != OutFlow.NOOUT
        //                    && outflow[se].m_weight[Index.nw] <= (byte)100 && outflow[se].m_weight[Index.nw] > (byte)0)
        //                {
        //                    currentlength = (float)(outflow[se].m_weight[Index.nw] * cumlen[se]) / 100;
        //                    cumlength += currentlength;
        //                    if (maxlength < currentlength)
        //                    {
        //                        maxlength = currentlength;
        //                    }
        //                }
        //                // ��
        //                if (outflow[s].m_weight[Index.n] != OutFlow.NOOUT
        //                    && outflow[s].m_weight[Index.n] <= (byte)100 && outflow[s].m_weight[Index.n] > (byte)0)
        //                {
        //                    currentlength = (float)(outflow[s].m_weight[Index.n] * cumlen[s]) / 100;
        //                    cumlength += currentlength;
        //                    if (maxlength < currentlength)
        //                    {
        //                        maxlength = currentlength;
        //                    }
        //                }
        //                // ����
        //                if (outflow[sw].m_weight[Index.ne] != OutFlow.NOOUT
        //                    && outflow[sw].m_weight[Index.ne] <= (byte)100 && outflow[sw].m_weight[Index.ne] > (byte)0)
        //                {
        //                    currentlength = (float)(outflow[sw].m_weight[Index.ne] * cumlen[sw]) / 100;
        //                    cumlength += currentlength;
        //                    if (maxlength < currentlength)
        //                    {
        //                        maxlength = currentlength;
        //                    }
        //                }
        //                if (cumlength > 0.0)
        //                { 
        //                    // ����ֵ��̽��
        //                    //2010.08.13ɾ���ź���
        //                    //float cum = 0.0f;
        //                    //for (int k = 0; k < 8; k++)
        //                    //{
        //                    //    if (outflow[c].m_weight[k] != OutFlow.NOOUT)
        //                    //    {
        //                    //        if (k % 2 == 0)                                  
        //                    //            // �Խ��߷���
        //                    //            cum += (float)(diagcellsize * outflow[c].m_weight[k])/100;                                  
        //                    //        else 
        //                    //            cum += (float)(cellsize * outflow[c].m_weight[k])/100;                                   
        //                    //    }
        //                    //}
        //                    if (cumlength > maxlength)
        //                    {
        //                        cumlength = maxlength + inicumlen[c];
        //                    }
        //                    else
        //                    {
        //                        cumlength += inicumlen[c];
        //                    }
        //                    if (cumlength > cumlen[c])
        //                    {
        //                        hits++;
        //                        done = false;
        //                        cumlen[c] = cumlength;
        //                    }                            
        //                }// if
        //                //�ҵ����ֵ
        //                //if (cumlen[c] > setmax)
        //                //{
        //                //    setmax = cumlen[c];
        //                //}
        //                //if (cumlen[c] < setmin)
        //                //{
        //                //    setmin = cumlen[c];
        //                //}
        //            }
        //        }// for

        //        if (hits == hits1)
        //            count = 10000;
        //        hits1 = hits;
        //        hits = 0;
        //        // �������
        //        for (int i = rows - 3; i >= 2; i--)
        //        {
        //            // SECOND PART
        //            for (int j = cols - 3; j >= 2; j--)
        //            {
        //                c = i * cols + j;
        //                if (nd[c])
        //                {
        //                    continue;
        //                } //�����ֵ�������ô�ѭ��
        //                nw = c - cols - 1;
        //                n = c - cols;
        //                ne = c - cols + 1;
        //                w = c - 1;
        //                e = c + 1;
        //                sw = c + cols - 1;
        //                s = c + cols;
        //                se = c + cols + 1;
        //                cumlength = 0.0f;
        //                maxlength = 0.0f;
        //                currentlength = 0.0f;
        //                // ����Ȩֵ���䣬Ȼ���ۻ�
        //                // ��
        //                if (outflow[w].m_weight[Index.e] != OutFlow.NOOUT
        //                    && outflow[w].m_weight[Index.e] <= (byte)100 && outflow[w].m_weight[Index.e] > (byte)0)
        //                {
        //                    currentlength = (float)(outflow[w].m_weight[Index.e] * cumlen[w]) / 100;
        //                    cumlength += currentlength;
        //                    if (maxlength < currentlength)
        //                    {
        //                        maxlength = currentlength;
        //                    }
        //                }
        //                // ����
        //                if (outflow[nw].m_weight[Index.se] != OutFlow.NOOUT
        //                    && outflow[nw].m_weight[Index.se] <= (byte)100 && outflow[nw].m_weight[Index.se] > (byte)0)
        //                {
        //                    currentlength = (float)(outflow[nw].m_weight[Index.se] * cumlen[nw]) / 100;
        //                    cumlength += currentlength;
        //                    if (maxlength < currentlength)
        //                    {
        //                        maxlength = currentlength;
        //                    }
        //                }
        //                // ��
        //                if (outflow[n].m_weight[Index.s] != OutFlow.NOOUT
        //                    && outflow[n].m_weight[Index.s] <= (byte)100 && outflow[n].m_weight[Index.s] > (byte)0)
        //                {
        //                    currentlength = (float)(outflow[n].m_weight[Index.s] * cumlen[n]) / 100;
        //                    cumlength += currentlength;
        //                    if (maxlength < currentlength)
        //                    {
        //                        maxlength = currentlength;
        //                    }
        //                }
        //                // ����
        //                if (outflow[ne].m_weight[Index.sw] != OutFlow.NOOUT
        //                    && outflow[ne].m_weight[Index.sw] <= (byte)100 && outflow[ne].m_weight[Index.sw] > (byte)0)
        //                {
        //                    currentlength = (float)(outflow[ne].m_weight[Index.sw] * cumlen[ne]) / 100;
        //                    cumlength += currentlength;
        //                    if (maxlength < currentlength)
        //                    {
        //                        maxlength = currentlength;
        //                    }
        //                }
        //                // ��
        //                if (outflow[e].m_weight[Index.w] != OutFlow.NOOUT
        //                    && outflow[e].m_weight[Index.w] <= (byte)100 && outflow[e].m_weight[Index.w] > (byte)0)
        //                {
        //                    currentlength = (float)(outflow[e].m_weight[Index.w] * cumlen[e]) / 100; cumlength += currentlength;
        //                    if (maxlength < currentlength)
        //                    {
        //                        maxlength = currentlength;
        //                    }
        //                }
        //                // ����
        //                if (outflow[se].m_weight[Index.nw] != OutFlow.NOOUT
        //                    && outflow[se].m_weight[Index.nw] <= (byte)100 && outflow[se].m_weight[Index.nw] > (byte)0)
        //                {
        //                    currentlength = (float)(outflow[se].m_weight[Index.nw] * cumlen[se]) / 100;
        //                    cumlength += currentlength;
        //                    if (maxlength < currentlength)
        //                    {
        //                        maxlength = currentlength;
        //                    }
        //                }
        //                // ��
        //                if (outflow[s].m_weight[Index.n] != OutFlow.NOOUT
        //                    && outflow[s].m_weight[Index.n] <= (byte)100 && outflow[s].m_weight[Index.n] > (byte)0)
        //                {
        //                    currentlength = (float)(outflow[s].m_weight[Index.n] * cumlen[s]) / 100;
        //                    cumlength += currentlength;
        //                    if (maxlength < currentlength)
        //                    {
        //                        maxlength = currentlength;
        //                    }
        //                }
        //                // ����
        //                if (outflow[sw].m_weight[Index.ne] != OutFlow.NOOUT
        //                    && outflow[sw].m_weight[Index.ne] <= (byte)100 && outflow[sw].m_weight[Index.ne] > (byte)0)
        //                {
        //                    currentlength = (float)(outflow[sw].m_weight[Index.ne] * cumlen[sw]) / 100;
        //                    cumlength += currentlength;
        //                    if (maxlength < currentlength)
        //                    {
        //                        maxlength = currentlength;
        //                    }
        //                }
        //                if (cumlength > 0.0)
        //                {
        //                    // ����ֵ��̽��
        //                    //�ź���2010.08.13ע�͵�
        //                    //float cum = 0.0f;
        //                    //for (int k = 0; k < 8; ++k)
        //                    //{
        //                    //    if (outflow[c].m_weight[k] != OutFlow.NOOUT)
        //                    //    {
        //                    //        if (k % 2 == 0)
        //                    //            // �Խ��߷���
        //                    //            cum += (float)(diagcellsize * outflow[c].m_weight[k])/100;
        //                    //        else
        //                    //            cum += (float)(cellsize * outflow[c].m_weight[k])/100;
        //                    //    }
        //                    //}
        //                    //cumlength += inicumlen[c];
        //                    if (cumlength > maxlength)
        //                    {
        //                        cumlength = maxlength + inicumlen[c];
        //                    }
        //                    else
        //                    {
        //                        cumlength += inicumlen[c];
        //                    }
        //                    if (cumlength > cumlen[c])
        //                    {
        //                        hits++;
        //                        done = false;
        //                        cumlen[c] = cumlength;
        //                    }
        //                }// if
        //                //�ҵ����ֵ
        //                //if (cumlen[c] > setmax)
        //                //{
        //                //    setmax = cumlen[c];
        //                //}
        //                //if (cumlen[c] < setmin)
        //                //{
        //                //    setmin = cumlen[c];
        //                //}
        //            }
        //        }// for
        //    }// while
        //    LogCumulativeProgress(count, hits1, hits);  
        //}

        //�ۻ�����
        public void CalcCumulativeLength(DemData dd, float[] demMap, OutFlow[] outflow, bool[] nd, ref float[] cumlen, float[] inicumlen)
        {
            int rows; // Number of rows.
            int cols; // Number of columns.
            int count = 0; //��¼ѭ������
            int hits = 0, hits1 = 0;
            int nw, n, ne, w, c, e, sw, s, se;
            bool done = false;
            float cumlength;
            //float maxlength;//���ڼ�¼��Χ����³�
            //float currentlength;//���ڼ�¼��ǰ�����ϵ��³�
            float cellsize;
            //float diagcellsize;

            rows = dd.imagNrows;
            cols = dd.imagNcols;
            cellsize = dd.cellSize;
            //diagcellsize = (float)Math.Sqrt(2.0) * dd.cellSize;
            int fixnum = (int)(dd.imagNrows - 2) * (dd.imagNcols) / 1000;
            float[] array_fix = new float[fixnum];
            //float setmax = 0;
            float setmin = dd.cellSize;
            //float classify_num = 10;
            for (int i = 2; i < rows - 2; i++)
            {
                for (int j = 2; j < cols - 2; j++)
                {

                    cumlen[i * cols + j] = inicumlen[i * cols + j];
                }
            }
            while (!done && count < 10000)
            {
                count++;
                done = true;
                hits = 0;
                for (int i = 2; i < rows - 2; i++)
                {
                    for (int j = 2; j < cols - 2; j++)
                    {
                        
                        c = i * cols + j;
                        if (nd[c])
                        {
                            continue;
                        } //�����ֵ�������ô�ѭ��
                        nw = c - cols - 1;
                        n = c - cols;
                        ne = c - cols + 1;
                        w = c - 1;
                        e = c + 1;
                        sw = c + cols - 1;
                        s = c + cols;
                        se = c + cols + 1;
                        cumlength = 0.0f;

                        // ����Ȩֵ���䣬Ȼ���ۻ�
                        // ��
                        //if (i == 125)
                        //{
                        //   MessageBox.Show(j.ToString());
                        //}
                        if (outflow[w].m_weight[Index.e] != OutFlow.NOOUT
                            && outflow[w].m_weight[Index.e] <= (byte)100 && outflow[w].m_weight[Index.e] > (byte)0)
                        {
                            cumlength += ((float)(outflow[w].m_weight[Index.e] * cumlen[w])) / 100;
                        }
                        //else if (outflow[w].m_weight[Index.e] > (byte)100)
                        //{
                        //    cumlength -= ((float)((255 - outflow[w].m_weight[Index.e]) * cumlen[w])) / 100;
                       // }
                        // ����
                        if (outflow[nw].m_weight[Index.se] != OutFlow.NOOUT
                            && outflow[nw].m_weight[Index.se] <= (byte)100 && outflow[nw].m_weight[Index.se] > (byte)0)
                        {
                            cumlength += ((float)(outflow[nw].m_weight[Index.se] * cumlen[nw])) / 100;
                        }
                       // else if (outflow[nw].m_weight[Index.se] > (byte)100)
                        //{
                       //     cumlength -= ((float)((255 - outflow[nw].m_weight[Index.se]) * cumlen[nw])) / 100;
                       // }
                        // ��
                        if (outflow[n].m_weight[Index.s] != OutFlow.NOOUT
                             && outflow[n].m_weight[Index.s] <= (byte)100 && outflow[n].m_weight[Index.s] > (byte)0)
                        {
                            cumlength += ((float)(outflow[n].m_weight[Index.s] * cumlen[n])) / 100;
                        }
                        //else if (outflow[n].m_weight[Index.s] > (byte)100)
                       // {
                        //    cumlength -= ((float)((255 - outflow[n].m_weight[Index.s]) * cumlen[n])) / 100;
                       // }
                        // ����
                        if (outflow[ne].m_weight[Index.sw] != OutFlow.NOOUT
                             && outflow[ne].m_weight[Index.sw] <= (byte)100 && outflow[ne].m_weight[Index.sw] > (byte)0)
                        {
                            cumlength += ((float)(outflow[ne].m_weight[Index.sw] * cumlen[ne])) / 100;
                        }
                       // else if (outflow[ne].m_weight[Index.sw] > (byte)100)
                       // {
                       //     cumlength -= ((float)((255 - outflow[ne].m_weight[Index.sw]) * cumlen[ne])) / 100;
                       // }
                        // ��
                        if (outflow[e].m_weight[Index.w] != OutFlow.NOOUT
                            && outflow[e].m_weight[Index.w] <= (byte)100 && outflow[e].m_weight[Index.w] > (byte)0)
                        {
                            cumlength += (float)(outflow[e].m_weight[Index.w] * cumlen[e]) / 100;

                        }
                       // else if (outflow[e].m_weight[Index.w] > (byte)100)
                       // {
                       //     cumlength -= ((float)((255 - outflow[e].m_weight[Index.w]) * cumlen[e])) / 100;
                       // }

                        // ����
                        if (outflow[se].m_weight[Index.nw] != OutFlow.NOOUT
                            && outflow[se].m_weight[Index.nw] <= (byte)100 && outflow[se].m_weight[Index.nw] > (byte)0)
                        {
                            cumlength += (float)(outflow[se].m_weight[Index.nw] * cumlen[se]) / 100;
                        }
                       // else if (outflow[se].m_weight[Index.nw] > (byte)100)
                        //{
                        //    cumlength -= ((float)((255 - outflow[se].m_weight[Index.nw]) * cumlen[se])) / 100;
                       // }
                        // ��
                        if (outflow[s].m_weight[Index.n] != OutFlow.NOOUT
                            && outflow[s].m_weight[Index.n] <= (byte)100 && outflow[s].m_weight[Index.n] > (byte)0)
                        {
                            cumlength += (float)(outflow[s].m_weight[Index.n] * cumlen[s]) / 100;
                        }
                        //else if (outflow[s].m_weight[Index.n] > (byte)100)
                       // {
                        //    cumlength -= ((float)((255 - outflow[s].m_weight[Index.n]) * cumlen[s])) / 100;
                       // }
                        // ����
                        if (outflow[sw].m_weight[Index.ne] != OutFlow.NOOUT
                            && outflow[sw].m_weight[Index.ne] <= (byte)100 && outflow[sw].m_weight[Index.ne] > (byte)0)
                        {
                            cumlength += (float)(outflow[sw].m_weight[Index.ne] * cumlen[sw]) / 100;
                        }
                        //else if (outflow[sw].m_weight[Index.ne] > (byte)100)
                       // {
                       //     cumlength -= ((float)((255 - outflow[sw].m_weight[Index.ne]) * cumlen[sw])) / 100;
                       // }
                        if (cumlength > 0.0)
                        {
                            // ����ֵ��̽��
                            //2010.08.13ɾ���ź���
                            //float cum = 0.0f;
                            //for (int k = 0; k < 8; k++)
                            //{
                            //    if (outflow[c].m_weight[k] != OutFlow.NOOUT)
                            //    {
                            //        if (k % 2 == 0)                                  
                            //            // �Խ��߷���
                            //            cum += (float)(diagcellsize * outflow[c].m_weight[k])/100;                                  
                            //        else 
                            //            cum += (float)(cellsize * outflow[c].m_weight[k])/100;                                   
                            //    }
                            //}
                            cumlength += inicumlen[c];
                            if (cumlength > cumlen[c])
                            {
                                hits++;
                                done = false;
                                cumlen[c] = cumlength;
                            }

                        }
                    }
                }// for

                if (hits == hits1)
                    count = 10000;
                hits1 = hits;
                hits = 0;
                // �������
                for (int i = rows - 3; i >= 2; i--)
                {
                    // SECOND PART
                    for (int j = cols - 3; j >= 2; j--)
                    {
                        c = i * cols + j;
                        if (nd[c])
                        {
                            continue;
                        } //�����ֵ�������ô�ѭ��
                        nw = c - cols - 1;
                        n = c - cols;
                        ne = c - cols + 1;
                        w = c - 1;
                        e = c + 1;
                        sw = c + cols - 1;
                        s = c + cols;
                        se = c + cols + 1;
                        cumlength = 0.0f;
                        // ����Ȩֵ���䣬Ȼ���ۻ�
                        // ��
                        if (outflow[w].m_weight[Index.e] != OutFlow.NOOUT
                            && outflow[w].m_weight[Index.e] <= (byte)100 && outflow[w].m_weight[Index.e] > (byte)0)
                        {
                            cumlength += (float)(outflow[w].m_weight[Index.e] * cumlen[w]) / 100;
                        }
                        else if (outflow[w].m_weight[Index.e] > (byte)100)
                        {
                            cumlength -= ((float)((255 - outflow[w].m_weight[Index.e]) * cumlen[w])) / 100;
                        }
                        // ����
                        if (outflow[nw].m_weight[Index.se] != OutFlow.NOOUT
                            && outflow[nw].m_weight[Index.se] <= (byte)100 && outflow[nw].m_weight[Index.se] > (byte)0)
                        {
                            cumlength += (float)(outflow[nw].m_weight[Index.se] * cumlen[nw]) / 100;
                        }
                        else if (outflow[nw].m_weight[Index.se] > (byte)100)
                        {
                            cumlength -= ((float)((255 - outflow[nw].m_weight[Index.se]) * cumlen[nw])) / 100;
                        }
                        // ��
                        if (outflow[n].m_weight[Index.s] != OutFlow.NOOUT
                            && outflow[n].m_weight[Index.s] <= (byte)100 && outflow[n].m_weight[Index.s] > (byte)0)
                        {
                            cumlength += (float)(outflow[n].m_weight[Index.s] * cumlen[n]) / 100;
                        }
                        else if (outflow[n].m_weight[Index.s] > (byte)100)
                        {
                            cumlength -= ((float)((255 - outflow[n].m_weight[Index.s]) * cumlen[n])) / 100;
                        }
                        // ����
                        if (outflow[ne].m_weight[Index.sw] != OutFlow.NOOUT
                            && outflow[ne].m_weight[Index.sw] <= (byte)100 && outflow[ne].m_weight[Index.sw] > (byte)0)
                        {
                            cumlength += (float)(outflow[ne].m_weight[Index.sw] * cumlen[ne]) / 100;
                        }
                        else if (outflow[ne].m_weight[Index.sw] > (byte)100)
                        {
                            cumlength -= ((float)((255 - outflow[ne].m_weight[Index.sw]) * cumlen[ne])) / 100;
                        }
                        // ��
                        if (outflow[e].m_weight[Index.w] != OutFlow.NOOUT
                            && outflow[e].m_weight[Index.w] <= (byte)100 && outflow[e].m_weight[Index.w] > (byte)0)
                        {
                            cumlength += (float)(outflow[e].m_weight[Index.w] * cumlen[e]) / 100;
                        }
                        else if (outflow[e].m_weight[Index.w] > (byte)100)
                        {
                            cumlength -= ((float)((255 - outflow[e].m_weight[Index.w]) * cumlen[e])) / 100;
                        }
                        // ����
                        if (outflow[se].m_weight[Index.nw] != OutFlow.NOOUT
                            && outflow[se].m_weight[Index.nw] <= (byte)100 && outflow[se].m_weight[Index.nw] > (byte)0)
                        {
                            cumlength += (float)(outflow[se].m_weight[Index.nw] * cumlen[se]) / 100;
                        }
                        else if (outflow[se].m_weight[Index.nw] > (byte)100)
                        {
                            cumlength -= ((float)((255 - outflow[se].m_weight[Index.nw]) * cumlen[se])) / 100;
                        }
                        // ��
                        if (outflow[s].m_weight[Index.n] != OutFlow.NOOUT
                            && outflow[s].m_weight[Index.n] <= (byte)100 && outflow[s].m_weight[Index.n] > (byte)0)
                        {
                            cumlength += (float)(outflow[s].m_weight[Index.n] * cumlen[s]) / 100;
                        }
                        else if (outflow[s].m_weight[Index.n] > (byte)100)
                        {
                            cumlength -= ((float)((255 - outflow[s].m_weight[Index.n]) * cumlen[s])) / 100;
                        }
                        // ����
                        if (outflow[sw].m_weight[Index.ne] != OutFlow.NOOUT
                            && outflow[sw].m_weight[Index.ne] <= (byte)100 && outflow[sw].m_weight[Index.ne] > (byte)0)
                        {
                            cumlength += (float)(outflow[sw].m_weight[Index.ne] * cumlen[sw]) / 100;
                        }
                        else if (outflow[sw].m_weight[Index.ne] > (byte)100)
                        {
                            cumlength -= ((float)((255 - outflow[sw].m_weight[Index.ne]) * cumlen[sw])) / 100;
                        }
                        if (cumlength > 0.0)
                        {
                            cumlength += inicumlen[c];
                            if (cumlength > cumlen[c])
                            {
                                hits++;
                                done = false;
                                cumlen[c] = cumlength;
                            }
                        }
                    }
                }// for
            }// while
            setCalcChanneLength(dd, demMap, ref cumlen, ref outflow, nd);
            LogCumulativeProgress(count, hits1, hits);
        }
        public void setCalcChanneLength(DemData demData, float[] demMap, ref float[] Cumlen_ChannelNetworks, ref OutFlow[] outflow, bool[] nd)
        {
            int i, j, c, k, d, h, n, p, q, s;
            int[] dig = new int[8];
            int rows;/* Number of rows.*/
            int cols;/* Number of cols*/
            float cellSize;
            rows = demData.imagNrows;
            cols = demData.imagNcols;
            cellSize = demData.cellSize;


            node[] H = new node[rows * cols];
            node[] L = new node[rows * cols];
            node[] Q = new node[rows * cols];
            int[] inFlowNum = new int[rows * cols];
            int[] outF = new int[rows * cols];
            int Hnum, Lnum, Qnum;
            Hnum = 0;
            for (i = 0; i < rows; i++)
            {
                for (j = 0; j < cols; j++)
                {
                    c = i * cols + j;

                    if (i < 2 || j < 2 || i > rows - 3 || j > cols - 3)
                    {
                        outF[c] = -1;
                        continue;
                    }

                    if (nd[c] || outflow[c].JUG == false)
                        continue;
                   // Cumlen_ChannelNetworks = 1000.0;
                    dig[0] = c + 1;
                    dig[1] = c + cols + 1;
                    dig[2] = c + cols;
                    dig[3] = c + cols - 1;
                    dig[4] = c - 1;
                    dig[5] = c - cols - 1;
                    dig[6] = c - cols;
                    dig[7] = c - cols + 1;
                    for (k = 0; k < 8; k++)
                    {
                        d = dig[k];
                        if (demMap[d] == demMap[c] && outflow[d].JUG == false)
                        {
                            H[Hnum].flow = 1;
                            H[Hnum].i = c;
                            H[Hnum++].parent = 0;
                            break;
                        }
                    }
                }
            }
            for (i = 0; i < Hnum; i++)
            {
                for (j = 0; j < Hnum; j++)
                {
                    p = H[i].i;
                    q = H[j].i;
                    if (demMap[p] < demMap[q])
                    {
                        int temp = H[i].i;
                        H[i].i = H[j].i;
                        H[j].i = temp;
                    }
                }
            }
            for (i = 0; i < Hnum; i++)
            {
                int c0 = H[i].i;
                float outLen0 = Cumlen_ChannelNetworks[c0];
                Lnum = p = 0;
                L[p].i = c0;
                L[p].flow = 1;
                L[p].parent = 0;
                Lnum++;
                while (p != Lnum)
                {
                    c = L[p++].i;
                    dig[0] = c + 1;
                    dig[1] = c + cols + 1;
                    dig[2] = c + cols;
                    dig[3] = c + cols - 1;
                    dig[4] = c - 1;
                    dig[5] = c - cols - 1;
                    dig[6] = c - cols;
                    dig[7] = c - cols + 1;
                    for (k = 0; k < 8; k++)
                    {
                        d = dig[k];
                        if (demMap[d] == demMap[c] && outflow[d].JUG == false)
                        {
                            for (s = 0; s < Lnum && L[s].i != d; s++) ;
                            if (s == Lnum)
                            {
                                L[Lnum].i = d;
                                L[Lnum].flow = 0;
                                L[Lnum++].parent = c;
                            }

                        }
                    }
                }

                if (Lnum < 2) continue;//ʵ���ϲ�����
                for (k = 1; k < Lnum; k++)
                {
                    for (j = 1; j < Lnum; j++)
                    {
                        p = L[k].i;
                        q = L[j].i;
                        if (Cumlen_ChannelNetworks[p] < Cumlen_ChannelNetworks[q])
                        {
                            int temp = L[k].i;
                            L[k].i = L[j].i;
                            L[j].i = temp;
                        }

                    }
                }
                for (int w = 0; w < Lnum; w++)
                {
                    c = L[w].i;
                    if (outflow[c].JUG == true) continue;
                    Qnum = p = 0;
                    Q[p].i = c;
                    Q[p].parent = 0;
                    Q[p].flow = 1;
                    Qnum++;
                    while (true)
                    {
                        c = Q[p++].i;
                        dig[0] = c + 1;
                        dig[1] = c + cols;
                        dig[2] = c - 1;
                        dig[3] = c - cols;
                        dig[4] = c + cols + 1;
                        dig[5] = c + cols - 1;
                        dig[6] = c - cols - 1;
                        dig[7] = c - cols + 1;
                        int x = 0;
                        for (; x < 8; x++)
                        {
                            d = dig[x];
                            for (s = 0; s < Lnum && L[s].i != d; s++) ;
                            if (s < Lnum)
                            {

                                for (q = 0; q < Qnum && Q[q].i != d; q++) ;
                                if (q == Qnum)
                                {
                                    Q[Qnum].i = d;
                                    Q[Qnum++].parent = c;
                                }
                                if (L[s].flow != 0) break;
                            }
                        }
                        if (x < 8) break;
                    }
                    s = Qnum - 1;
                    while (s != 0)
                    {
                        c = Q[s].parent;
                        outF[c] = Q[s].i;
                        outflow[c].JUG = true;
                        if (outF[c] == c + 1)
                        {
                            Cumlen_ChannelNetworks[c] += cellSize;
                            outflow[c].m_weight[Index.e] = (byte)100;
                        }
                        else if (outF[c] == c + 1 + cols)
                        {
                            Cumlen_ChannelNetworks[c] += (float)1.41*cellSize;
                            outflow[c].m_weight[Index.se] = (byte)100;
                        }
                        else if (outF[c] == c + cols)
                        {
                            Cumlen_ChannelNetworks[c] += cellSize;
                            outflow[c].m_weight[Index.s] = (byte)100;
                        }

                        else if (outF[c] == c + cols - 1)
                        {
                            Cumlen_ChannelNetworks[c] += (float)1.41 * cellSize;
                            outflow[c].m_weight[Index.sw] = (byte)100;
                        }
                        else if (outF[c] == c - 1)
                        {
                            Cumlen_ChannelNetworks[c] += cellSize;
                            outflow[c].m_weight[Index.w] = (byte)100;
                        }
                        else if (outF[c] == c - cols - 1)
                        {
                            Cumlen_ChannelNetworks[c] += (float)1.41 * cellSize;
                            outflow[c].m_weight[Index.nw] = (byte)100;
                        }
                        else if (outF[c] == c - cols)
                        {
                            Cumlen_ChannelNetworks[c] += cellSize;
                            outflow[c].m_weight[Index.n] = (byte)100;
                        }
                        else if (outF[c] == c - cols + 1)
                        {
                            Cumlen_ChannelNetworks[c] += (float)1.41 * cellSize;
                            outflow[c].m_weight[Index.ne] = (byte)100;
                        }
                        c = Q[s].i;
                        inFlowNum[c]++;
                        for (p = 0; p < Lnum && L[p].i !=Q[s].parent; p++) ;
                        L[p].flow = 1;
                        for (p = 0; p < Qnum && Q[p].i != Q[s].parent; p++) ;
                        s = p;
                    }
                }
                while (true)
                {
                    int flag = 0;
                    for (p = 1; p < Lnum; p++)
                    {
                        c = L[p].i;
                        if (inFlowNum[c] == 0)
                        {
                            flag = 1;
                            j = outF[c];
                            if (j > 0)
                                Cumlen_ChannelNetworks[j] += Cumlen_ChannelNetworks[c];
                            inFlowNum[c]--;
                            inFlowNum[j]--;
                        }

                    }
                    if (flag == 0) break;
                }
                c = c0;
                float Len = Cumlen_ChannelNetworks[c0] - outLen0;
                p = Qnum = 0;
                Q[Qnum++].i = c;
                while (p != Qnum)
                {
                    if (Qnum == rows * cols - 1)
                        Qnum = rows * cols - 1;
                    c = Q[p++].i;
                    dig[0] = c - cols - 1;
                    dig[1] = c - cols;
                    dig[2] = c - cols + 1;
                    dig[3] = c + 1;
                    dig[4] = c + cols + 1;
                    dig[5] = c + cols;
                    dig[6] = c + cols - 1;
                    dig[7] = c - 1;
                    int mins = c;
                    for (s = 0; s < 8; s++)
                    {
                        d = dig[s];
                        if (nd[d] == false && demMap[d] < demMap[mins])
                            mins = d;
                    }
                    if (mins != c)
                    {
                        Cumlen_ChannelNetworks[mins] += Len;
                        Q[Qnum++].i = mins;
                    }
                    else if (outflow[c].JUG == true)
                    {
                                d = dig[s];
                                Cumlen_ChannelNetworks[d] += Len;
                                Q[Qnum++].i = d;


                    }
                }

            }
            ;
        }

        #endregion
        #region

        ////�ۻ���Χƽ���³��㷨
        //public void CalcCumulativeLength_New(DemData dd, byte[] outflow, bool[] nd, bool[] breakflow, float[] cumlen)
        //{
        //    try
        //    {
        //        int rows; /*Number of rows.*/
        //        int cols; /*Number of columns.*/
        //        int count_while = 0; //��¼ѭ������
        //        int hits, hits1 = 0;
        //        int nw, n, ne, w, c, e, sw, s, se, count;
        //        bool done = false;
        //        float cumlength;
        //        float diagcellsize;
        //        string outflow_array;

        //        rows = dd.imagNrows;
        //        cols = dd.imagNcols;

        //        diagcellsize = (float)Math.Sqrt(2.0) * dd.cellSize;
        //        while (!done && count_while < 10000)
        //        {
        //            count_while++;
        //            done = true;
        //            hits = 0;
        //            for (int i = 2; i < rows - 2; i++)
        //            {
        //                for (int j = 2; j < cols - 2; j++)
        //                {
        //                    c = i * cols + j;
        //                    if (nd[c])
        //                    {
        //                        continue;
        //                    } //�����ֵ�������ô�ѭ��

        //                    cumlength = (float)0.0; // �ۼ��³�Ϊ0.0
        //                    count = 0;
        //                    outflow_array = "";

        //                    nw = c - cols - 1;
        //                    n = c - cols;
        //                    ne = c - cols + 1;
        //                    w = c - 1;
        //                    e = c + 1;
        //                    sw = c + cols - 1;
        //                    s = c + cols;
        //                    se = c + cols + 1;

        //                    //��
        //                    if (outflow[w] == GlobalConstants.E && !breakflow[w] && cumlen[w] > cumlength)
        //                    {
        //                        //cumlength = cumlen[w];
        //                        outflow_array = outflow_array + "w";
        //                        count++;
        //                    }
        //                    //����
        //                    if (outflow[nw] == GlobalConstants.SE && !breakflow[nw] && cumlen[nw] > cumlength)
        //                    {
        //                        //cumlength = cumlen[nw];
        //                        if(outflow_array.Length>0)
        //                            outflow_array = outflow_array + ",nw";
        //                        else
        //                            outflow_array = outflow_array + "nw";
        //                        count++;
        //                    }
        //                    //��                          
        //                    if (outflow[n] == GlobalConstants.S && !breakflow[n] && cumlen[n] > cumlength)
        //                    {
        //                        //cumlength = cumlen[n];
        //                        if (outflow_array.Length > 0)
        //                            outflow_array = outflow_array + ",n";
        //                        else
        //                            outflow_array = outflow_array + "n";
        //                        count++;
        //                    }
        //                    //����
        //                    if (outflow[ne] == GlobalConstants.SW && !breakflow[ne] && cumlen[ne] > cumlength)
        //                    {
        //                        //cumlength = cumlen[ne];
        //                        if (outflow_array.Length > 0)
        //                            outflow_array = outflow_array + ",ne";
        //                        else
        //                            outflow_array = outflow_array + "ne";
        //                        count++;
        //                    }
        //                    //��
        //                    if (outflow[e] == GlobalConstants.W && !breakflow[e] && cumlen[e] > cumlength)
        //                    {
        //                        //cumlength = cumlen[e];
        //                        if (outflow_array.Length > 0)
        //                            outflow_array = outflow_array + ",e";
        //                        else
        //                            outflow_array = outflow_array + "e";
        //                        count++;
        //                    }
        //                    //����
        //                    if (outflow[se] == GlobalConstants.NW && !breakflow[se] && cumlen[se] > cumlength)
        //                    {
        //                        //cumlength = cumlen[se];
        //                        if (outflow_array.Length > 0)
        //                            outflow_array = outflow_array + ",se";
        //                        else
        //                            outflow_array = outflow_array + "se";
        //                        count++;
        //                    }
        //                    //��
        //                    if (outflow[s] == GlobalConstants.N && !breakflow[s] && cumlen[s] > cumlength)
        //                    {
        //                        //cumlength = cumlen[s];
        //                        if (outflow_array.Length > 0)
        //                            outflow_array = outflow_array + ",s";
        //                        else
        //                            outflow_array = outflow_array + "s";
        //                        count++;
        //                    }
        //                    //����
        //                    if (outflow[sw] == GlobalConstants.NE && !breakflow[sw] && cumlen[sw] > cumlength)
        //                    {
        //                        //cumlength = cumlen[sw];
        //                        if (outflow_array.Length > 0)
        //                        outflow_array = outflow_array + ",sw";
        //                        else
        //                        outflow_array = outflow_array + "sw";
        //                        count++;
        //                    }
        //                    if (outflow_array.Length > 0)
        //                    {
        //                        string[] cumlength_array = outflow_array.Split(',');
        //                        for (int x = 0; x < cumlength_array.Length; x++)
        //                        {
        //                            if (cumlength_array[x] == "w")
        //                                cumlength += cumlen[w];
        //                            else if (cumlength_array[x] == "nw")
        //                                cumlength += cumlen[nw];
        //                            else if (cumlength_array[x] == "e")
        //                                cumlength += cumlen[w];
        //                            else if (cumlength_array[x] == "ne")
        //                                cumlength += cumlen[w];
        //                            else if (cumlength_array[x] == "e")
        //                                cumlength += cumlen[w];
        //                            else if (cumlength_array[x] == "se")
        //                                cumlength += cumlen[w];
        //                            else if (cumlength_array[x] == "s")
        //                                cumlength += cumlen[w];
        //                            else if (cumlength_array[x] == "sw")
        //                                cumlength += cumlen[w];
        //                            if (count != 0)
        //                                cumlength = cumlength / count;
        //                        }
        //                    }
        //                    if (cumlength > 0.0)
        //                    {
        //                        if (outflow[c] == GlobalConstants.N || outflow[c] == GlobalConstants.E || outflow[c] == GlobalConstants.S ||
        //                            outflow[c] == GlobalConstants.W)
        //                            cumlength += dd.cellSize;
        //                        else if (outflow[c] == GlobalConstants.NE || outflow[c] == GlobalConstants.NW || outflow[c] == GlobalConstants.SE ||
        //                                 outflow[c] == GlobalConstants.SW)
        //                            cumlength += diagcellsize;
        //                        if (cumlength > cumlen[c])
        //                        {
        //                            hits++;
        //                            done = false;
        //                            cumlen[c] = cumlength;
        //                        }
        //                    }
        //                } // END for(i = 0; i < rows; i++) FIRST PART
        //            } // END for(j = 0; j < cols, j++)	  FIRST PART

        //            if (hits == hits1)
        //                count = 10000;

        //            hits1 = hits;
        //            hits = 0;
        //            //ΪʲôҪ���������¼����أ�
        //            for (int i = rows - 3; i >= 2; i--)
        //            {
        //                // SECOND PART
        //                for (int j = cols - 3; j >= 2; j--)
        //                {
        //                    // SECOND PART
        //                    c = i * cols + j;
        //                    if (nd[c])
        //                    {
        //                        continue;
        //                    }
        //                    cumlength = (float)0.0;
        //                    outflow_array = "";
        //                    count = 0;

        //                    nw = c - cols - 1;
        //                    n = c - cols;
        //                    ne = c - cols + 1;
        //                    w = c - 1;
        //                    e = c + 1;
        //                    sw = c + cols - 1;
        //                    s = c + cols;
        //                    se = c + cols + 1;
        //                    //����
        //                    if (outflow[nw] == GlobalConstants.SE && !breakflow[nw] && cumlen[nw] > cumlength)
        //                    {
        //                        //cumlength = cumlen[nw];
        //                        outflow_array = outflow_array + "nw";
        //                        count++;
        //                    }//��
        //                    if (outflow[n] == GlobalConstants.S && !breakflow[n] && cumlen[n] > cumlength)
        //                    {
        //                        //cumlength = cumlen[n];
        //                        if (outflow_array.Length > 0)
        //                        outflow_array = outflow_array + ",n";
        //                        else
        //                        outflow_array = outflow_array + "n";
        //                        count++;
        //                    }//����
        //                    if (outflow[ne] == GlobalConstants.SW && !breakflow[ne] && cumlen[ne] > cumlength)
        //                    {
        //                        //cumlength = cumlen[ne];
        //                        if (outflow_array.Length > 0)
        //                        outflow_array = outflow_array + ",ne";
        //                        else
        //                        outflow_array = outflow_array + "ne";
        //                        count++;
        //                    }//��
        //                    if (outflow[w] == GlobalConstants.E && !breakflow[w] && cumlen[w] > cumlength)
        //                    {
        //                        //cumlength = cumlen[w];
        //                        if (outflow_array.Length > 0)
        //                        outflow_array = outflow_array + ",w";
        //                        else
        //                        outflow_array = outflow_array + "w";
        //                        count++;
        //                    } //��
        //                    if (outflow[e] == GlobalConstants.W && !breakflow[e] && cumlen[e] > cumlength)
        //                    {
        //                        //cumlength = cumlen[e];
        //                        if (outflow_array.Length > 0)
        //                        outflow_array = outflow_array + ",e";
        //                        else
        //                        outflow_array = outflow_array + "e";
        //                        count++;
        //                    }//����
        //                    if (outflow[sw] == GlobalConstants.NE && !breakflow[sw] && cumlen[sw] > cumlength)
        //                    {
        //                        //cumlength = cumlen[sw];
        //                        if (outflow_array.Length > 0)
        //                        outflow_array = outflow_array + ",sw";
        //                        else
        //                        outflow_array = outflow_array + "sw";
        //                        count++;
        //                    }//��
        //                    if (outflow[s] == GlobalConstants.N && !breakflow[s] && cumlen[s] > cumlength)
        //                    {
        //                        //cumlength = cumlen[s];
        //                        if (outflow_array.Length > 0)
        //                         outflow_array = outflow_array + ",s";
        //                        else
        //                         outflow_array = outflow_array + "s";
        //                        count++;
        //                    }//����
        //                    if (outflow[se] == GlobalConstants.NW && !breakflow[se] && cumlen[se] > cumlength)
        //                    {
        //                        //cumlength = cumlen[se];
        //                        if (outflow_array.Length > 0)
        //                            outflow_array = outflow_array + ",se";
        //                        else
        //                            outflow_array = outflow_array + "se";
        //                        count++;
        //                    }
        //                    if (outflow_array.Length > 0)
        //                    {
        //                        string[] cumlength_array = outflow_array.Split(',');
        //                        for (int x = 0; x < cumlength_array.Length; x++)
        //                        {
        //                            if (cumlength_array[x] == "w")
        //                                cumlength += cumlen[w];
        //                            else if (cumlength_array[x] == "nw")
        //                                cumlength += cumlen[nw];
        //                            else if (cumlength_array[x] == "e")
        //                                cumlength += cumlen[w];
        //                            else if (cumlength_array[x] == "ne")
        //                                cumlength += cumlen[w];
        //                            else if (cumlength_array[x] == "e")
        //                                cumlength += cumlen[w];
        //                            else if (cumlength_array[x] == "se")
        //                                cumlength += cumlen[w];
        //                            else if (cumlength_array[x] == "s")
        //                                cumlength += cumlen[w];
        //                            else if (cumlength_array[x] == "sw")
        //                                cumlength += cumlen[w];
        //                            if (count != 0)
        //                                cumlength = cumlength / count;
        //                        }
        //                    }
        //                    if (cumlength > 0.0)
        //                    {
        //                        if (outflow[c] == GlobalConstants.N || outflow[c] == GlobalConstants.E || outflow[c] == GlobalConstants.S ||
        //                            outflow[c] == GlobalConstants.W)
        //                            cumlength += dd.cellSize;
        //                        else if (outflow[c] == GlobalConstants.NE || outflow[c] == GlobalConstants.NW || outflow[c] == GlobalConstants.SE ||
        //                                 outflow[c] == GlobalConstants.SW)
        //                            cumlength += diagcellsize;
        //                        if (cumlength > cumlen[c])
        //                        {
        //                            done = false;
        //                            hits++;
        //                            cumlen[c] = cumlength;
        //                        }
        //                    }
        //                } // END for(i = 0; i < rows; i++)  SECOND PART
        //            } // END for(j = 0; j < cols, j++)  SECOND PART
        //            LogCumulativeProgress(count_while, hits1, hits);
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        // 
        //        MessageBox.Show(ex.ToString());
        //    }

        //}
        //public void ConvertLengthToFeet(DemData dd, float[] slp_len_cum, float[] slp_lgth_ft)
        //{
        //    int i; /*Loop Counter.*/
        //    int j; /*Loop Counter.*/
        //    int c;
        //    int rows; /*Number of rows.*/
        //    int cols; /*Number of columns.*/
        //    /*�Žܵ��޸�*/
        //    rows = dd.imagNrows;
        //    cols = dd.imagNcols;

        //    for (i = 2; i < rows - 2; i++)
        //    {
        //        for (j = 2; j < cols - 2; j++)
        //        {
        //            c = i * cols + j;
        //            slp_lgth_ft[c] = slp_len_cum[c] / (float)0.3048;
        //        }
        //    }
        //}
        public void Calculate_L(DemData dd, float[] slopeAng, float[] slp_lgth_ft, float[] ruslel,int rusle_csle)
        {
            int i; /*Loop Counter.*/
            int j; /*Loop Counter.*/
            int c;
            int rows; /*Number of rows.*/
            int cols; /*Number of columns.*/
            rows = dd.imagNrows;
            cols = dd.imagNcols;
            if (rusle_csle == 1)
                for (i = 2; i < rows - 2; i++)
                {
                    for (j = 2; j < cols - 2; j++)
                    {
                        c = i * cols + j;
                        ruslel[c] = (float)Math.Pow(slp_lgth_ft[c] / (float)22.1, TableLookUp_csle(slopeAng[c])); //x��y����
                    }
                }
            else
                for (i = 2; i < rows - 2; i++)
                {
                    for (j = 2; j < cols - 2; j++)
                    {
                        c = i * cols + j;
                        ruslel[c] = (float)Math.Pow(slp_lgth_ft[c] / (float)22.1, TableLookUp_rusle(slopeAng[c])); //x��y����
                    }
                }
        }
        public void Calculate_CLSE_L_Feet(DemData dd, float[] slopeAng, float[] slp_lgth_ft, float[] ruslel)
        {
            int i; /*Loop Counter.*/
            int j; /*Loop Counter.*/
            int c;
            int rows; /*Number of rows.*/
            int cols; /*Number of columns.*/
            rows = dd.imagNrows;
            cols = dd.imagNcols;
            for (i = 2; i < rows - 2; i++)
            {
                for (j = 2; j < cols - 2; j++)
                {
                    c = i * cols + j;
                    ruslel[c] = (float)Math.Pow(slp_lgth_ft[c] / (float)72.6, TableLookUp_csle(slopeAng[c])); //x��y����
                } // END for(i = 0; i < rows; i++) 
            } // END for(j = 0; j < cols, j++)  
        }
        public void Calculate_S(DemData dd, float[] downSlpAng, float[] rusles,int rusle_csle)
        {
            int i; //	Loop Counter
            int j; //	Loop Counter
            int c;
            int rows; //	Number of rows
            int cols; //	Number of columns
            float deg;
            deg = (float)57.2958; //	ASK RICK
            rows = dd.imagNrows;
            cols = dd.imagNcols;
            if (rusle_csle == 1)
                for (i = 2; i < rows - 2; i++)
                {
                    for (j = 2; j < cols - 2; j++)
                    {
                        c = i * cols + j;
                        if (downSlpAng[c] >= 10)
                            rusles[c] = (float)(21.9 * (Math.Sin(downSlpAng[c] / deg)) - (float)0.96);
                        else if (downSlpAng[c] >= 5)
                            rusles[c] = (float)(16.8 * (Math.Sin(downSlpAng[c] / deg)) - (float)0.50);
                        else
                            rusles[c] = (float)(10.8 * (Math.Sin(downSlpAng[c] / deg)) + (float)0.03);
                    }
                }
            else
                for (i = 2; i < rows - 2; i++)
                {
                    for (j = 2; j < cols - 2; j++)
                    {
                        c = i * cols + j;
                        if (downSlpAng[c] >= 5.1428)
                            rusles[c] = (float)(16.8 * (Math.Sin(downSlpAng[c] / deg)) - (float)0.50);
                        else
                            rusles[c] = (float)(10.8 * (Math.Sin(downSlpAng[c] / deg)) + (float)0.03);
                    }
                }
        }
        //û���޸�ΪRusle�Ĺ�ʽ
        //public void Calculate_RUSLE_S(DemData dd, float[] downSlpAng, float[] rusles)
        //{
        //    int i; //	Loop Counter
        //    int j; //	Loop Counter
        //    int c;
        //    int rows; //	Number of rows
        //    int cols; //	Number of columns
        //    float deg;
        //    deg = (float)57.2958; //	ASK RICK
        //    rows = dd.imagNrows;
        //    cols = dd.imagNcols;
        //    for (i = 2; i < rows - 2; i++)
        //    {
        //        for (j = 2; j < cols - 2; j++)
        //        {
        //            c = i * cols + j;
        //            if (downSlpAng[c] >= 14.04)
        //                rusles[c] = (float)(21.91 * (Math.Sin(downSlpAng[c] / deg)) - (float)0.96);
        //            else if (downSlpAng[c] >= 5)
        //                rusles[c] = (float)(16.8 * (Math.Sin(downSlpAng[c] / deg)) - (float)0.50);
        //            else
        //                rusles[c] = (float)(10.8 * (Math.Sin(downSlpAng[c] / deg)) + (float)0.03);

        //        } // END for(i = 0; i < rows; i++) 
        //    } // END for(j = 0; j < cols, j++)  
        //}
        public void Calculate_CSLE_LS2(DemData dd, float[] ruslel, float[] rusles, float[] ruslels2)
        {
            int i; /*Loop Counter.*/
            int j; /*Loop Counter.*/
            int c;
            int rows; /*Number of rows.*/
            int cols; /*Number of columns.*/
            rows = dd.imagNrows;
            cols = dd.imagNcols;
            for (i = 2; i < rows - 2; i++)
            {
                for (j = 2; j < cols - 2; j++)
                {
                    c = i * cols + j;
                    //ruslels2[c] = (float)((int)(ruslel[c] * rusles[c] * 100 + 0.5));
                    //ruslels2[c] = (float)((int)(ruslel[c] * rusles[c] * 100 + 0.5)/100);
                    ruslels2[c] = ruslel[c] * rusles[c];
                }
            }
        }
        #endregion

        //##############################################



        //                    CalcLib



        //##############################################

        #region CalcLib

        public float TableLookUp_csle(float v)//CLSE
        {
            double temp = 0.56;

            if (v <= 1)
                temp = 0.2;
            else if (v < 3)
                temp = 0.3;
            else if (v < 5)
                temp = 0.4;
            else
                temp = 0.5;
            return (float)temp;
        }
        public float TableLookUp_rusle(float v)//RUSEL
        {
            double temp = 0.56;

            if (v <= 0.101)
                temp = 0.01;
            else if (v < 0.2)
                temp = 0.02;
            else if (v < 0.4)
                temp = 0.04;
            else if (v < 0.85)
                temp = 0.08;
            else if (v < 1.4)
                temp = 0.14;
            else if (v < 2.0)
                temp = 0.18;
            else if (v < 2.6)
                temp = 0.22;
            else if (v < 3.1)
                temp = 0.25;
            else if (v < 3.7)
                temp = 0.28;
            else if (v < 5.2)
                temp = 0.32;
            else if (v < 6.3)
                temp = 0.35;
            else if (v < 7.4)
                temp = 0.37;
            else if (v < 8.6)
                temp = 0.40;
            else if (v < 10.3)
                temp = 0.41;
            else if (v < 12.9)
                temp = 0.44;
            else if (v < 15.7)
                temp = 0.47;
            else if (v < 20.0)
                temp = 0.49;
            else if (v < 25.8)
                temp = 0.52;
            else if (v < 31.5)
                temp = 0.54;
            else if (v < 37.2)
                temp = 0.55;
            return (float)temp;
        }

        #endregion

        public void FreeMemory()
        {
            GC.Collect();
            GC.WaitForPendingFinalizers();
            GC.Collect();
        }
    }
}