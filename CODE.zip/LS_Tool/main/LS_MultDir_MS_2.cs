﻿//added by WangShuai 20140727
//MS_2Class实现了对地理坐标数据的实现

using System;
using System.Collections.Generic;
using System.Text;
using System.IO;

using System.Collections;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Data;

//using System.Drawing;
//using System.Drawing.Printing;
using System.Windows.Forms;
using System.Threading;
using System.Diagnostics;
namespace LengthSlope
{
    class LS_MultDir_MS_2Class
    {
        private bool debug = true;

        public void LSBegin(string inPath, string outPath, string prefix, bool ifRepair, 
            float lessThan5, float above5, bool unit, bool fillWay, bool flowcut, 
            bool fillsink, float threshold, bool CumulatedWay, 
            int RUSLE_CSLE, bool Channel_Consider, bool ExportAll, CheckBox[] MyCheckBox, Object form)
        {
            Form1 form1 = form as Form1;
            form1.form2.progressTextBox.Text = "准备读入数据 Loading DEM……";
            form1.form2.progressBar.Visible = true;
            form1.form2.progressBar.Value = 0;
            form1.form2.progressTextBox.Update();
            form1.form2.progressBar.Value++;

            DemData demData = new DemData();
            demData.fillWay = fillWay;
            demData.inPath = inPath;
            demData.flowcut = flowcut;
            demData.threshold = threshold;

            //下载数据源基本信息
            form1.form2.progressTextBox.Text = "获取数据源基本信息 Reading basic information……";
            form1.form2.progressTextBox.Update();
            LoadDEMHeaderData(demData.inPath, ref demData);
            demData.preOutPath = outPath + prefix;

            demData.scf_lt5 = lessThan5;
            demData.scf_ge5 = above5;

            demData.meterOrFeet = unit;
            demData.ifRepair = ifRepair;// 是否修复
            string logFilePath = String.Concat(outPath, "\\", prefix, "LogFile.txt");//日志文件路径
            //打开日志文件
            OpenLogFile(logFilePath);
            LogStartUp(demData);
            LogDemHeader(demData);
            form1.form2.progressBar.Value++;
            form1.form2.progressTextBox.Text = "申请内存空间 Appling memery......";
            form1.form2.progressTextBox.Update();

            FreeMemory();

            //开辟空间
            float[] demMap = new float[demData.imagNrows * demData.imagNcols];
            bool[] noDataMap = new bool[demData.imagNrows * demData.imagNcols];
            //Console.WriteLine("3");
            //开辟空间失败，写入日志文件，并退出程序
            if (demMap.Length == 0)
                LogFailedExit(demData.imagNcols * demData.imagNrows, 4, "float", "DEM_Map"); //写入日志文件
            if (noDataMap.Length == 0)
                LogFailedExit(demData.imagNcols * demData.imagNrows, 1, "bool", "NODATA Grid Map"); //写入日志文件

            //对最外两层填充为无值
            #region FillAroundCell
            {
                int c = 0;
                for (int i = 0; i < demData.imagNrows; i++)
                    for (int j = 0; j < demData.imagNcols; j++)
                    {
                        noDataMap[c] = true;
                        if (i < 2 || i > (demData.imagNrows - 3))
                        {
                            c = i * demData.imagNcols + j;
                            if (demData.noDateType)
                            {
                                demMap[c] = demData.floatNoData;
                            }
                            else
                            {
                                demMap[c] = demData.intNoData;
                            }
                            // zhangjie.2010.07.26注释下行
                            // noDataMap[c] = true;//填充无值点
                        }
                        else
                        {
                            //不是第一行和最后一行
                            if (j < 2 || (j > demData.imagNcols - 3))
                            {
                                c = i * demData.imagNcols + j;
                                if (demData.noDateType)
                                {
                                    demMap[c] = demData.floatNoData;
                                }
                                else
                                {
                                    demMap[c] = demData.intNoData;
                                }
                                // zhangjie.2010.07.26注释下行
                                // noDataMap[c] = true;
                            }
                        }
                        // zhangjie.2010.07.26注释新添加下行
                        // noDataMap[c] = true;
                    }
            }
            #endregion
            form1.form2.progressTextBox.Text = "读取DEM Checking DEM......";
            form1.form2.progressTextBox.Update();
            form1.form2.progressBar.Value++;


            ReadDEMElevations(ref demData, ref demMap, ref noDataMap); //读取DEM
            FreeMemory();

            //Console.WriteLine("4");
            form1.form2.progressTextBox.Text = "核查DEM的数据类型 Checking value types......";
            form1.form2.progressTextBox.Update();
            form1.form2.progressBar.Value++;
            demData.floatOrInt = VerifyDEMDataType(ref demData); //核实DEM的数据类型
            LogDataTypeDEM(demData); // 将数据类型写入日志文件

            form1.form2.progressTextBox.Text = "填充内部无值区Fill nodata area......";
            form1.form2.progressTextBox.Update();
            form1.form2.progressBar.Value++;

            FreeMemory();
            //填充内部无值区
            LocateInteriorNODATACells(demData, ref noDataMap, ref demMap);

            if (ExportAll)//if (demData.ifExcessFile)            
            {
                form1.form2.progressBar.Value++;
                form1.form2.progressBar.Maximum++;
                form1.form2.progressTextBox.Text = "重写修订后的DEM数据 Rewriting DEM......";
                form1.form2.progressTextBox.Update();

                string pathFileName = String.Concat(outPath, "\\", prefix, "orig_dem.txt");
                if (debug)
                {
                    WriteDEMGrid(pathFileName, demData, noDataMap, demMap); //打开一个文件，写DEM
                }
                LogWroteDEM(pathFileName); //写日志文件
            }

            form1.form2.progressTextBox.Text = "洼地填充，环面周围8个点Filling sinks......";
            form1.form2.progressTextBox.Update();
            form1.form2.progressBar.Value++;

            FreeMemory();

            //s设置是否进行洼地填充 
            bool sf = true;
            bool af = true;
            if (fillsink == false)
            {
                sf = false;
                af = false;
            }
            while (sf && af)
            {
                sf = FillSinks(demData, ref noDataMap, ref demMap); //填充洼地周围8个点
                af = AnnulusFill(demData, ref noDataMap, ref demMap); //填充环面周围16个点
                //Debug.WriteLine("sf = " + sf.ToString() + "af = " + af.ToString());
            }

            form1.form2.progressTextBox.Update();
            form1.form2.progressBar.Value++;

            if (ExportAll)//if (demData.ifExcessFile)            
            {
                form1.form2.progressTextBox.Text = "写填充完的DEM数据Writing new DEM......";
                form1.form2.progressTextBox.Update();
                form1.form2.progressBar.Value++;
                form1.form2.progressBar.Maximum++;
                string demFill = String.Concat(outPath, "\\", prefix, "DemFill.txt");
                if (debug) 
                {
                    WriteDEMGrid(demFill, demData, noDataMap, demMap); //写填充完的DEM数据
                }
                LogWroteDEM(demFill); //写日志文件
            }
            form1.form2.progressBar.Value++;
            form1.form2.progressTextBox.Text = "申请内存空间Applying for new memery......";
            form1.form2.progressTextBox.Update();

            FreeMemory();

            float[] slopeAng = new float[demData.imagNcols * demData.imagNrows];//坡度
            if (slopeAng == null)
                LogFailedExit(demData.imagNcols * demData.imagNrows, 4, "float", "slope angle");
            byte[] inFlow = new byte[demData.imagNcols * demData.imagNrows];//流入
            if (inFlow == null)
                LogFailedExit(demData.imagNcols * demData.imagNrows, 1, "FLOWTYPE", "inflow direction");
            // zhangjie.2010.06.14注释
            // byte[] outFlow = new byte[demData.imagNcols * demData.imagNrows];//流出
            // if (outFlow == null)
            //  LogFailedExit(demData.imagNcols * demData.imagNrows, 1, "FLOWTYPE", "outflow direction");
            //  bool[] flowFlag = new bool[demData.imagNcols * demData.imagNrows];//因子
            // if (flowFlag == null)
            //  LogFailedExit(demData.imagNcols * demData.imagNrows, 1, "bool", "flow cutoff rrid map");

            // zhangjie 2010.06.14 为流出权重分配空间
            OutFlow[] outFlow = new OutFlow[demData.imagNcols * demData.imagNrows];
            if (outFlow == null)
                LogFailedExit(demData.imagNcols * demData.imagNrows, 1, "OutFlow", "outFlow weigth");

            form1.form2.progressBar.Value++;
            form1.form2.progressTextBox.Text = "对数据进行缓冲区处理Bufferring......";
            form1.form2.progressTextBox.Update();

            //初始化最外两层
            #region
            {
                int c = 0;
                for (int i = 0; i < demData.imagNrows; i++)
                    for (int j = 0; j < demData.imagNcols; j++)
                    {
                        c = i * demData.imagNcols + j;
                        if (i < 2 || i > (demData.imagNrows - 3))
                        {
                            slopeAng[c] = (float)0.0;
                            inFlow[c] = (byte)0;
                            // flowFlag[c] = false;
                        }
                        else if (j < 2 || j > (demData.imagNcols - 3))
                        {
                            slopeAng[c] = (float)0.0;
                            inFlow[c] = (byte)0;
                            // flowFlag[c] = false;
                        }
                        outFlow[c] = new OutFlow();
                    }
            }
            #endregion
            form1.form2.progressBar.Value++;
            form1.form2.progressTextBox.Text = "获取坡度，权值，流向Calculating slope angle, weight, slope aspect......";
            form1.form2.progressTextBox.Update();

            // zhangjie,2010.06.14修改
            // downSlope(demData, noDataMap, demMap, ref slopeAng, ref slopeLen, ref outFlow); //获取坡度，坡长，流向
            // zhangjie.2010.08.06 使用“三阶不带权差分”
            //张宏鸣2010.08.13使用三阶反距离平方权差分
            downAng(demData, noDataMap, demMap, ref slopeAng); // 计算坡度

            FreeMemory();

            if (flowcut == false)//如果不计算截断
            {
                downWeight(demData, noDataMap, demMap, ref outFlow, ref slopeAng); // 计算权值
            }
            else//如果计算截断
            {
                downWeight(demData, noDataMap, demMap, ref outFlow, ref slopeAng, flowcut);//flowcut仅仅是为了和不考虑截断的downweight的函数相区别

                //计算河网
                form1.form2.progressTextBox.Text = "正在获取河网Canculating channel networks......";
                form1.form2.progressTextBox.Update();
                form1.form2.progressBar.Value++;
                if (Channel_Consider)
                {
                    float[] ChannelNetworks = new float[demData.imagNcols * demData.imagNrows];
                    CalcChannelNetworks(demData, ref ChannelNetworks, outFlow, noDataMap);
                    //将河网数据和阈值加载到权重文件中，这样可以省掉河网所占用的大量内存
                    RedownWeight(demData, threshold, ChannelNetworks, ref outFlow, noDataMap);//重新设置权值
                    if (ExportAll)//if (demData.ifExcessFile)            
                    {
                        form1.form2.progressTextBox.Text = "写河网数据Saving channel netwoks data......";
                        form1.form2.progressTextBox.Update();
                        form1.form2.progressBar.Value++;
                        form1.form2.progressBar.Maximum++;
                        string Channel = String.Concat(outPath, "\\", prefix, "flowaccu.txt");
                        if (debug)
                        {
                            WriteDEMGrid(Channel, demData, noDataMap, ChannelNetworks); //写河网数据
                        }
                        LogWroteDEM(Channel); //写日志文件
                    }
                    ChannelNetworks = new float[1];
                    ChannelNetworks = null;
                    FreeMemory();
                }
            }

            FreeMemory();

            if (ExportAll)//if (demData.ifExcessFile)            
            {
                // zhangjie,2010.06.15改，以前为输出坡长，改为输出权值
                form1.form2.progressBar.Value++;
                form1.form2.progressBar.Maximum++;
                form1.form2.progressTextBox.Text = "写权值文件Saving weight data......";
                form1.form2.progressTextBox.Update();
                // 将权值输出
                string weight_filename = String.Concat(outPath, "\\", prefix, "weight.txt");
                if (debug)
                {
                    WriteWeightFile(weight_filename, ref demData, ref noDataMap, ref outFlow);
                }
                LogWroteDEM(weight_filename); //写日志文件

                form1.form2.progressBar.Value++;
                form1.form2.progressBar.Maximum++;
                form1.form2.progressTextBox.Text = "写坡度文件Saving slope angle data......";
                form1.form2.progressTextBox.Update();
                string slp_ang = String.Concat(outPath, "\\", prefix, "slp_ang.txt");
                //打开并写坡度文件，然后关闭
                if (debug)
                {
                    WriteSlopeAngFile(slp_ang, demData, noDataMap, slopeAng);
                }
                //计算0.5和0.7的位置，
                form1.form2.progressBar.Value++;
                form1.form2.progressBar.Maximum++;
                form1.form2.progressTextBox.Text = "写坡度因子文件Saving S factor data......";
                form1.form2.progressTextBox.Update();
                string slp_fac = String.Concat(outPath, "\\", prefix, "slp_fac.txt");
                if (debug)
                {
                    WriteSlopeFactorFile(slp_fac, demData, noDataMap, slopeAng); //写坡度因子
                }
                LogWroteDEM(slp_fac); //写日志文件
            }

            FreeMemory();

            if (MyCheckBox[1].Checked && !ExportAll)
            {
                form1.form2.progressBar.Value++;
                form1.form2.progressBar.Maximum++;
                form1.form2.progressTextBox.Text = "写坡度文件Saving slope angle data......";
                form1.form2.progressTextBox.Update();
                string slp_ang = String.Concat(outPath, "\\", prefix, "slp_ang.txt");
                if (debug)
                {
                    WriteSlopeAngFile(slp_ang, demData, noDataMap, slopeAng); //打开并写坡度文件，然后关闭
                }
                LogWroteDEM(slp_ang); //写日志文件
            }

            form1.form2.progressBar.Value++;
            form1.form2.progressTextBox.Text = "计算流入Calculating inflow......";
            form1.form2.progressTextBox.Update();

            FreeMemory();

            SetInFlowByWeigth(demData, ref noDataMap, ref outFlow, ref  inFlow);

            FreeMemory();

            // SetInFlow(demData, ref noDataMap, ref outFlow, ref inFlow); //设置流入
            //Console.WriteLine("6");
            if (ExportAll)//if (demData.ifExcessFile)            
            {
                form1.form2.progressBar.Value++;
                form1.form2.progressBar.Maximum++;
                form1.form2.progressTextBox.Text = "写坡向数据Saving slope aspect......";
                form1.form2.progressTextBox.Update();
                string in_flow = String.Concat(outPath, "\\", prefix, "inflow.txt");
                if (debug)
                {
                    WriteDirectionArray(in_flow, ref demData, ref noDataMap, ref inFlow); //写坡向数组
                }
                LogWroteDEM(in_flow); //写日志文件
            }

            form1.form2.progressBar.Value++;
            form1.form2.progressTextBox.Text = "申请内存空间Applying for new memory......";
            form1.form2.progressTextBox.Update();

            FreeMemory();

            float[] cumlen = new float[demData.imagNcols * demData.imagNrows];
            float[] inicumlen = new float[demData.imagNcols * demData.imagNrows];
            if (cumlen == null)
            {
                LogFailedExit(demData.imagNcols * demData.imagNrows, 4, "float", "cumulative Length"); //申请内存空间失败写日志
            }
            form1.form2.progressBar.Value++;
            form1.form2.progressTextBox.Text = "设置缓冲区Bufferring......";
            form1.form2.progressTextBox.Update();
            //外围填充
            #region FillAround
            {
                int c = 0;
                for (int i = 0; i < demData.imagNrows; i++)
                {
                    for (int j = 0; j < demData.imagNcols; j++)
                    {
                        c = i * demData.imagNcols + j;
                        if (i < 2 || i > demData.imagNrows - 3)
                        {
                            cumlen[c] = (float)0.0;
                        }
                        else if (j < 2 || j > demData.imagNcols - 3)
                        {
                            cumlen[c] = (float)0.0;
                        }
                    }
                }
            }
            #endregion
            form1.form2.progressBar.Value++;
            form1.form2.progressTextBox.Text = "初始化累积坡长文件Calculating cell slope length......";
            form1.form2.progressTextBox.Update();
            // zhangjie,2010.06.16 改 
            // InitCumulativeLength(demData, inFlow, outFlow, noDataMap, slopeLen, cumlen); //初始化累积坡长文件
            // slopeLen = null;
            // zhangjie,2010.08.04改
            // 用单流向的方法计算初始化的累计坡长
            InitCumulativeLength(demData, demMap, noDataMap, ref cumlen, ref inicumlen, inFlow, flowcut);
            // InitCumulativeLength(demData, inFlow, outFlow, noDataMap, cumlen);
            //强制释放内存
            demMap = new float[1];
            demMap = null;
            inFlow = new byte[1];
            inFlow = null;

            FreeMemory();

            if (ExportAll)//if (demData.ifExcessFile)            
            {
                form1.form2.progressBar.Value++;
                form1.form2.progressTextBox.Text = "写初始化累积坡长文件Saving cell slope length......";
                form1.form2.progressTextBox.Update();
                form1.form2.progressBar.Maximum++;

                string init_len = String.Concat(outPath, "\\", prefix, "init_len.txt");
                if (debug)
                {
                    WriteSlopeLenFile(init_len, ref demData, ref noDataMap, ref cumlen); //写坡长文件
                }
                LogWroteDEM(init_len); //写日志文件
            }

            form1.form2.progressBar.Value++;
            form1.form2.progressTextBox.Text = "计算累积坡长Calculating slope length......";
            form1.form2.progressTextBox.Update();

            FreeMemory();
            if (CumulatedWay)
                CalcCumulativeLength(demData, outFlow, noDataMap, ref cumlen, inicumlen); //计算全部流入累计坡长!!!!!!!
            else
                CalcCumulativeLength(demData, outFlow, noDataMap, ref cumlen, inicumlen,0);

            FreeMemory();

            if (MyCheckBox[2].Checked)
            {
                form1.form2.progressBar.Value++;
                form1.form2.progressTextBox.Text = "写累积坡长文件Saving slope length......";
                form1.form2.progressTextBox.Update();
                form1.form2.progressBar.Maximum++;
                string slp_len = String.Concat(outPath, "\\", prefix, "slp_len.txt");
                if (debug)
                {
                    WriteSlopeLenFile(slp_len, ref demData, ref noDataMap, ref cumlen); //写坡长文件
                }
                LogWroteDEM(slp_len); //写日志文件
            }
            outFlow = new OutFlow[1];
            outFlow = null;
            FreeMemory();


            form1.form2.progressBar.Value++;
            form1.form2.progressTextBox.Text = "申请内存空间Applying for new memory......";
            form1.form2.progressTextBox.Update();
            //20110129去掉英尺转换
            //float[] slp_lgth_ft = new float[demData.imagNcols * demData.imagNrows];
            //if (slp_lgth_ft == null)
            //{
            //    LogFailedExit(demData.imagNcols * demData.imagNrows, 4, "float", "cumulative Length in Feet");
            //}
            if (!demData.meterOrFeet)
            {
                form1.form2.progressTextBox.Text = "进行单位转换......";
                form1.form2.progressTextBox.Update();
                form1.form2.progressBar.Value++;
                form1.form2.progressBar.Maximum++;
                //20110129去掉英尺转换
                //ConvertLengthToFeet(demData, cumlen, slp_lgth_ft); //当前值除以0.3048的变换meter->feet的变化
                //if(ExportAll)
                if (demData.ifExcessFile)
                {
                    form1.form2.progressTextBox.Text = "写坡长(feet)......";
                    form1.form2.progressTextBox.Update();
                    form1.form2.progressBar.Value++;
                    form1.form2.progressBar.Maximum++;
                    //20110129去掉英尺转换
                    //string slp_in_ft = String.Concat(outPath, "\\", prefix, "slp_in_ft.txt");
                    //WriteSlopeLenFeet(slp_in_ft, demData, noDataMap, slp_lgth_ft); //写坡长（单位feet）
                    //LogWroteDEM(slp_in_ft); //写日志文件
                }
                //cumlen = null;
            }
            FreeMemory();

            float[] ruslel = new float[1];
            if (MyCheckBox[4].Checked || MyCheckBox[5].Checked)
            {
                form1.form2.progressTextBox.Text = "申请内存空间(L)Applying for new memory......";
                form1.form2.progressTextBox.Update();
                form1.form2.progressBar.Value++;

                ruslel = new float[demData.imagNcols * demData.imagNrows];
                if (ruslel == null)
                {
                    if (RUSLE_CSLE == 1)
                        LogFailedExit(demData.imagNcols * demData.imagNrows, 4, "float", "CSLE L "); //申请内存单元失败后写日志文件
                    else
                        LogFailedExit(demData.imagNcols * demData.imagNrows, 4, "float", "RUSLE L ");

                }
                form1.form2.progressTextBox.Text = "设置缓冲区Bufferring......";
                form1.form2.progressTextBox.Update();
                form1.form2.progressBar.Value++;
                //外围赋值
                #region
                {
                    int c = 0;
                    for (int i = 0; i < demData.imagNrows; i++)
                        for (int j = 0; j < demData.imagNcols; j++)
                        {
                            c = i * demData.imagNcols + j;
                            if (i < 2 || i > demData.imagNrows - 3)
                                ruslel[c] = (float)0.0;
                            else if (j < 2 || j > demData.imagNcols - 3)
                                ruslel[c] = (float)0.0;
                        }
                }
                #endregion
                if (!demData.meterOrFeet)
                {
                    form1.form2.progressTextBox.Text = "计算(feet)......";
                    form1.form2.progressTextBox.Update();
                    form1.form2.progressBar.Value++;
                    //20110129去掉英尺转换
                    //Calculate_CLSE_L_Feet(demData, slopeAng, slp_lgth_ft, ruslel); //计算rusle(feet)
                }
                else
                {
                    form1.form2.progressTextBox.Text = "计算坡长因子Calculating L factor......";
                    form1.form2.progressTextBox.Update();
                    form1.form2.progressBar.Value++;
                    Calculate_L(demData, slopeAng, cumlen, ruslel, RUSLE_CSLE); //计算rusle(meter)
                }
                cumlen = new float[0];
                cumlen = null;
                FreeMemory();

                form1.form2.progressTextBox.Text = "写坡长因子文件Saving L factor......";
                form1.form2.progressTextBox.Update();
                form1.form2.progressBar.Value++;
                form1.form2.progressBar.Maximum++;
                string rusle_l;
                if (RUSLE_CSLE == 1)
                    rusle_l = String.Concat(outPath, "\\", prefix, "CSLE_L.txt");
                else
                    rusle_l = String.Concat(outPath, "\\", prefix, "RUSLE_L.txt");
                if (debug)
                {
                    Write_FloatGrid(rusle_l, demData, noDataMap, ruslel); //将rusle1储存为浮点型
                }
                LogWroteDEM(rusle_l); //写日志文件
            }
            //Console.WriteLine("8");            
            float[] rusles = new float[1];
            FreeMemory();
            form1.form2.progressBar.Value++;
            form1.form2.progressTextBox.Text = "申请内存空间(S)Applying for new memory......";
            form1.form2.progressTextBox.Update();
            if (MyCheckBox[3].Checked || MyCheckBox[5].Checked)
            {             

                rusles = new float[demData.imagNcols * demData.imagNrows];
                if (rusles == null)
                {
                    if (RUSLE_CSLE == 1)
                        LogFailedExit(demData.imagNcols * demData.imagNrows, 4, "float", "CLSE S "); //申请内存空间失败写日志
                    else
                        LogFailedExit(demData.imagNcols * demData.imagNrows, 4, "float", "RUSLE S "); //申请内存空间失败写日志
                }
                form1.form2.progressBar.Value++;
                form1.form2.progressTextBox.Text = "设置缓冲区Bufferring......";
                form1.form2.progressTextBox.Update();
                //外围填充
                #region
                {
                    int c = 0;
                    for (int i = 0; i < demData.imagNrows; i++)
                        for (int j = 0; j < demData.imagNcols; j++)
                        {
                            c = i * demData.imagNcols + j;
                            if (i < 2 || i > demData.imagNrows - 3)
                                rusles[c] = (float)0.0;
                            else if (j < 2 || j > demData.imagNcols - 3)
                                rusles[c] = (float)0.0;
                        }
                }
                #endregion
                form1.form2.progressBar.Value++;
                form1.form2.progressTextBox.Text = "计算坡度因子Calculating S factor......";
                form1.form2.progressTextBox.Update();
                Calculate_S(demData, slopeAng, rusles, RUSLE_CSLE); //
                //强制释放内存
                slopeAng = new float[0];
                slopeAng = null;
                FreeMemory();

                form1.form2.progressTextBox.Text = "写坡度因子文件Saving S factor......";
                form1.form2.progressTextBox.Update();
                form1.form2.progressBar.Value++;
                form1.form2.progressBar.Maximum++;
                string rusle_s;
                if (RUSLE_CSLE == 1)
                    rusle_s = String.Concat(outPath, "\\", prefix, "CSLE_S.txt");
                else
                    rusle_s = String.Concat(outPath, "\\", prefix, "RUSLE_S.txt");
                if (debug)
                {
                    Write_FloatGrid(rusle_s, demData, noDataMap, rusles); //将rusle1储存为浮点型
                }
                LogWroteDEM(rusle_s); //写日志文件
            }
            FreeMemory();

            form1.form2.progressBar.Value++;
            form1.form2.progressTextBox.Text = "申请内存空间Applying for new memory......";
            form1.form2.progressTextBox.Update();
            if (MyCheckBox[5].Checked)
            {                
                float[] ruslels = new float[demData.imagNcols * demData.imagNrows];

                if (ruslels == null)
                {
                    if (RUSLE_CSLE == 1)
                        LogFailedExit(demData.imagNcols * demData.imagNrows, 4, "float", "CSLE LS "); //申请内存空间失败写日志
                    else
                        LogFailedExit(demData.imagNcols * demData.imagNrows, 4, "float", "RUSLE LS ");
                }
                form1.form2.progressBar.Value++;
                form1.form2.progressTextBox.Text = "设置缓冲区Bufferring......";
                form1.form2.progressTextBox.Update();

                //外围填充
                #region
                {
                    int c = 0;
                    for (int i = 0; i < demData.imagNrows; i++)
                        for (int j = 0; j < demData.imagNcols; j++)
                        {
                            c = i * demData.imagNcols + j;
                            if (i < 2 || i > demData.imagNrows - 3)
                                ruslels[c] = (float)0.0;
                            else if (j < 2 || j > demData.imagNcols - 3)
                                ruslels[c] = (float)0.0;
                        }
                }
                #endregion
                form1.form2.progressTextBox.Text = "计算坡度坡长Calculating LS factor......";
                form1.form2.progressTextBox.Update();
                form1.form2.progressBar.Value++;

                Calculate_CSLE_LS2(demData, ruslel, rusles, ruslels); //将rusle2储存
                ruslel = new float[0];
                ruslel = null;
                rusles = new float[0];
                rusles = null;
                FreeMemory();

                form1.form2.progressTextBox.Text = "写坡度坡长文件Saving S factor......";
                form1.form2.progressTextBox.Update();
                form1.form2.progressBar.Value++;
                string ruslels2;
                if (RUSLE_CSLE == 1)
                    ruslels2 = String.Concat(outPath, "\\", prefix, "CSLE_LS.txt");
                else
                    ruslels2 = String.Concat(outPath, "\\", prefix, "RUSLE_LS.txt");
                if (debug)
                {
                    Write_LS2(ruslels2, demData, noDataMap, ruslels);
                }
                LogWroteDEM(ruslels2);
                form1.form2.progressBar.Value++;
                form1.form2.progressTextBox.Text = "计算结束Calculation Over";
                form1.form2.progressTextBox.Update();
                Debug.WriteLine("form1.form2.progressBar.Value = " + form1.form2.progressBar.Value);
                Log_CLSE_LSWarning(RUSLE_CSLE);
            }
            CloseLogFile();
            if (ExportAll == false)
            {
                DeleteLogFile(logFilePath);
            }
            form1.form2.progressBar.Value = form1.form2.progressBar.Maximum;
            FreeMemory();
        }

        //##############################################

        //                   InData

        //##############################################
        #region InData
        private StreamReader demFile;
        private int BarMaxNum;//用于存放进度条最大值  BarMaxNum = demData.nrows;

        public void LoadDEMHeaderData(string inFileName, ref DemData demData)
        {
            //检验文件是否存在
            if (!File.Exists(inFileName))
            {
                throw (new FileNotFoundException(inFileName + " does not exist!"));
            }
            string line;
            demFile = new StreamReader(inFileName);

            //赋值ncols
            line = demFile.ReadLine().Trim();
            Debug.WriteLine(line);
            int tmpLastIndex = line.LastIndexOf(' ');
            demData.ncols = int.Parse(line.Substring(tmpLastIndex + 1));

            //赋值nrows
            line = demFile.ReadLine().Trim();
            tmpLastIndex = line.LastIndexOf(' ');//由行值为进度条赋值
            demData.nrows = int.Parse(line.Substring(tmpLastIndex + 1));
            BarMaxNum = demData.nrows;
            Debug.WriteLine(line);
            //赋值xllcorner
            line = demFile.ReadLine().Trim();
            tmpLastIndex = line.LastIndexOf(' ');
            demData.xllcorner = double.Parse(line.Substring(tmpLastIndex + 1));
            Debug.WriteLine(line);
            //赋值yllcorner
            line = demFile.ReadLine().Trim();
            tmpLastIndex = line.LastIndexOf(' ');
            demData.yllcorner = double.Parse(line.Substring(tmpLastIndex + 1));
            Debug.WriteLine(line);
            //赋值cellStep
            line = demFile.ReadLine().Trim();
            tmpLastIndex = line.LastIndexOf(' ');
            char[] numPart = line.Substring(tmpLastIndex + 1).ToCharArray();//将栅格的长度转换成字符串，目的是为了判断是否为浮点型
            Debug.WriteLine(line);
            demData.cellType = false;
            bool tmpFlag = false;
            //通过'.'来判断是否为浮点型
            for (int i = 0; i < numPart.Length; i++)
            {
                if (numPart[i] == '.')
                {
                    demData.cellType = true;
                }
            }

            demData.cellStep = double.Parse(line.Substring(tmpLastIndex + 1));

            //赋值NOTDATA
            line = demFile.ReadLine().Trim();
            tmpLastIndex = line.LastIndexOf(' ');
            numPart = line.Substring(tmpLastIndex + 1).ToCharArray();//相同的方法来处理
            for (int i = 0; i < numPart.Length; i++)
            {
                if (numPart[i] == '.')
                {
                    tmpFlag = true;
                }
            }
            demData.noDateType = tmpFlag;
            demData.floatNoData = float.Parse(line.Substring(tmpLastIndex + 1));
            Debug.WriteLine(demData.floatNoData);

            demData.intNoData = (int)demData.floatNoData;//09.12.01修改
            //demData.intNoData = int.Parse(line.Substring(tmpLastIndex + 1));
            demData.imagNcols = demData.ncols + 4;
            demData.imagNrows = demData.nrows + 4;

            /*demData.F_DEM_Flag = tmpFlag;
            demData.NODATA = float.Parse(line.Substring(tmpLastIndex + 1));
            demData.F_NODATA = float.Parse(line.Substring(tmpLastIndex + 1));
            demData.D_NODATA = int.Parse(line.Substring(tmpLastIndex + 1));*/
        }

        public void ReadDEMElevations(ref DemData demData, ref float[] demMap, ref bool[] noDataMap)
        {
            string[] tmp = new string[demData.ncols];
            float[] tmp1 = new float[demData.nrows * demData.ncols];
            //int mark = 0;
            //for (int i = 0; i < demData.nrows; i++)
            //{
            //    tmp = demFile.ReadLine().Split(' ');//读入除了txt的head部分剩下的部分
            //    for (int j = 0; j < demData.ncols; j++)
            //    {
            //        tmp1[mark] = float.Parse(tmp[j]);
            //        mark++;
            //    }
            //}
            /****************************/
            string aString;
            int count = 0;
            while ((aString = demFile.ReadLine()) != null)
            {
                string[] sArray = aString.Split(' ');
                int i = 0;
                while (i < sArray.Length)
                {
                    //Debug.WriteLine("the string:" + sArray [i]);
                    //tmp1[count] = float.Parse(sArray[i]);
                    if (sArray[i] != "")
                    {
                        tmp1[count] = Convert.ToSingle(sArray[i]);
                        count++;
                        i++;
                    }
                    else
                    {
                        i++;
                    }

                }
                sArray = null;
                if (count == demData.nrows * demData.ncols)
                    break;
                //Debug.WriteLine(count.ToString());
                //Debug.WriteLine(demData.ncols * demData.nrows);

            }
            /****************************/
            int real = 0;
            int imag = 0;
            for (int i = 2; i < demData.imagNrows - 2; i++)
                for (int j = 2; j < demData.imagNcols - 2; j++)
                {
                    imag = i * demData.imagNcols + j;
                    real = (i - 2) * demData.ncols + (j - 2);

                    if (tmp1[real] != demData.floatNoData)
                        demMap[imag] = tmp1[real];
                    else
                        demMap[imag] = (float)32767.0;//源文件中此处的32767定义#GlobalConstants在limit.h中,这怎么理解？？
                    noDataMap[imag] = (tmp1[real] == demData.floatNoData);
                    if (demMap[imag] < 0.0)
                    {
                        LogNegativeDEM(i - 2, j - 2, tmp1[real]);
                    }
                }
            tmp1 = null;
            tmp = null;
            demFile.Close();

            FreeMemory();
        }

        public bool VerifyDEMDataType(ref DemData demData)
        {
            StreamReader demFileBack = new StreamReader(demData.inPath);
            //读取六行，空过文件的起始标题
            demFileBack.ReadLine();
            demFileBack.ReadLine();
            demFileBack.ReadLine();
            demFileBack.ReadLine();
            demFileBack.ReadLine();
            string aString;
            bool fpFlag = false;
            int tPrecision = 0;
            demData.dataPrecision = 0;

            while ((aString = demFileBack.ReadLine()) != null)
            {
                string[] sArray = aString.Split(' ');
                int j = 0;
                while (j < sArray.Length)
                {
                    char[] array = sArray[j].ToCharArray();
                    for (int i = 0; i < array.Length; i++)
                    {

                        tPrecision = 0;
                        if (array[i] == '.')
                        {
                            fpFlag = true;
                            //tPrecision = array.Length - i-2;
                            tPrecision = array.Length - i - 1;
                            if (tPrecision > demData.dataPrecision)
                                demData.dataPrecision = tPrecision;
                            break;
                        }
                    }
                    j++;

                }
                sArray = null;
            }

            demFileBack.Close();
            demFileBack = null;
            FreeMemory();

            return fpFlag;
        }
        #endregion

        //##############################################

        //                OutData

        //##############################################

        #region OutData
        private StreamWriter sw;
        private StreamWriter fp;
        public void OpenLogFile(string filename)
        {
            sw = new StreamWriter(filename);
        }
        public void DeleteLogFile(string filename)
        {
            if (File.Exists(filename))
            {
                File.Delete(filename);
            }
        }
        public void LogStartUp(DemData dd)
        {
            sw.WriteLine();
            sw.WriteLine("User Selected options:");
            sw.WriteLine("  DEM DATA file name:        {0}", dd.inPath);
            sw.WriteLine("  Output path prefix:        {0}", dd.preOutPath);
            if (dd.meterOrFeet)
                sw.WriteLine("  DEM elevation units:       Meters");
            else
                sw.WriteLine("  DEM elevation units:       Feet");
            if (dd.ifExcessFile)//是否生成过度文件
                sw.WriteLine("  Write intermediate files:  YES");
            else
                sw.WriteLine("  Write intermediate files:  NO");

            if (dd.flowcut)
            {
                sw.WriteLine("  Slope cutoff factors");
                sw.WriteLine("    Less than 5 percent:     {0}", dd.scf_lt5);
                sw.WriteLine("    Greater equal 5 percent: {0}", dd.scf_ge5);
            }
            else
            {
                sw.WriteLine("  Without considering slope cutoff");
            }
            if (dd.threshold > 0)
                sw.WriteLine("  Define Channels as pixels an accumulated area threshold: {0} Square meters", dd.threshold);
            else
                sw.WriteLine("  Without defined Channels");

            if (dd.ifRepair)
                sw.WriteLine("  Interior NODATA cells:     Fill if possible");
            else
                sw.WriteLine("  Interior NODATA cells:     Do not attempt to fill");

            if (dd.ifRepair)
                sw.WriteLine("  Interior NODATA clusters:  Process anyway!");
            else
                sw.WriteLine("  Interior NODATA clusters:  Terminate program");
            if (dd.fillWay)
                sw.WriteLine("  Interior NODATA point:  fill with average value of around 8-cells");
            else
                sw.WriteLine("  Interior NODATA point:  fill with min value of around 8-cells");

        }
        public void LogDemHeader(DemData dd)
        {
            sw.WriteLine("Processing data for dem data set containing:");
            sw.WriteLine("  ncols          {0:d}", dd.ncols);
            sw.WriteLine("  nrows          {0:d}", dd.nrows);
            sw.WriteLine("  xllcorner      {0}", dd.xllcorner);
            sw.WriteLine("  xllcorner      {0}", dd.yllcorner);
            if (dd.cellType)
            {
                sw.WriteLine("  cellSize       {0}", dd.cellStep);
            }
            else
            {
                sw.WriteLine("  cellSize       {0:d}", (int)dd.cellStep);
            }

            if (dd.noDateType)
            {
                sw.WriteLine("  DEM NODATA     {0:f1}", dd.floatNoData);
            }
            else
            {
                sw.WriteLine("  DEM NODATA     {0:d}", dd.intNoData);
            }
            sw.WriteLine("  Float NODATA   -9.9");
            sw.WriteLine("  Int NODATA     -9");
        }
        public void LogFailedExit(int elements, int size, string type, string str)
        {
            sw.WriteLine("Unable to allocate memory for a dynamic {0} array.", type);
            sw.WriteLine("Such an array would have [{0}] elements", elements);
            sw.WriteLine("That's over {0} megabytes of storage", elements * size / 1000000);
            sw.WriteLine("This array would have stored the {0} values", str);
            sw.WriteLine("A guess is that your machine need about a {0} megaByte pagefile", elements * 18 / 1000000);
            sw.WriteLine("to handle this dataset.  NOTE: This is an apporximate size.");
            sw.WriteLine("Program execution has been halted!");
            CloseLogFile();
            Environment.Exit(0);
        }
        public void LogNegativeDEM(int nrows, int ncols, float demValue)
        {
            sw.WriteLine("Warning, DEM file contains negative values - Check Logfile if not expected!");
            sw.WriteLine("Warning, DEM file contains negative value(s)!");
            sw.WriteLine("Unless your working with data containing elevations below sea level");
            sw.WriteLine("This indicates an anomaly in your DEM data which may require attention");
            sw.WriteLine("Isolated negative values surrounded by valid DEM values will be sink filled");
            sw.WriteLine("Isolated negative values surrounded by NODATA cells will be rewritten as NODATA");
            sw.WriteLine("The negative cell(s) and their values are shown below");
            sw.WriteLine("DEM Cell[{0}][{1}] contains a negative value of {2}", nrows, ncols, demValue);
        }
        public void LogDataTypeDEM(DemData dd)
        {
            if (dd.floatOrInt)
            {
                sw.WriteLine("DEM file contains floating point DEM data");
                sw.WriteLine("DEM file contains {0} places decimal precision", dd.dataPrecision);
            }
            else
                sw.WriteLine("DEM file contains integer DEM data");
        }

        public void LogFillPoint(int i, int j, float fillValue)
        {
            sw.WriteLine("Cell [{0}][{1}] is an internal surrounded by cells which have valid DEM data", i, j);
            sw.WriteLine("It has filled by value {0}", fillValue);
        }
        public void LogExit()
        {
            sw.WriteLine("Dem data has cluster ,your chose option \"AnyWayProcess\"is false\nProgram execution has been halted!");
            CloseLogFile();
            Environment.Exit(0);
        }
        public void LogInteriorCluster(int r, int c)
        {
            sw.WriteLine("Cell[{0}][{1}] appears to be clustered!", r, c);
        }
        public void LocateInteriorNODATACells(DemData demData, ref bool[] noDataMap, ref float[] demMap)
        {
            int i; // Loop Counter.
            int j; // Loop Counter.


            int c, n, w, e, s; // Center, North, West, East, South
            int nw, ne, se, sw; // NorthWest. NorthEast, SouthEast, SouthWest

            bool done = false; // Iterative flag   
            int rows = demData.imagNrows;
            int cols = demData.imagNcols;

            bool[] ex_nd = new bool[rows * cols]; // EXternal_Nodata boolean map array
            if (ex_nd == null)
            {
                LogFailedExit(rows * cols, 1, "bool", "Temp File to locate interior NODATA points");
            }
            //把最外两层直接赋值true，因为最外两层是没有意义的，其他的值赋为false
            for (i = 0; i < rows; i++)
            {
                for (j = 0; j < cols; j++)
                {
                    if (i < 2 || i > rows - 3)
                    {
                        c = i * cols + j;
                        ex_nd[c] = true;
                    }
                    else if (j < 2 || j > cols - 3)
                    {
                        c = i * cols + j;
                        ex_nd[c] = true;

                    }
                    else
                    {
                        c = i * cols + j;
                        ex_nd[c] = false;
                    }
                }
            }

            int count = 0; // Counts number of interior NODATA cells
            while (!done)
            {
                done = true;
                for (i = 2; i < rows - 2; i++)
                    for (j = 2; j < cols - 2; j++)
                    {
                        c = i * cols + j;
                        //有数据
                        if (!noDataMap[c] || ex_nd[c])
                        {
                            continue;
                        }
                        nw = c - cols - 1;
                        n = c - cols;
                        ne = c - cols + 1;
                        w = c - 1;
                        e = c + 1;
                        sw = c + cols - 1;
                        s = c + cols;
                        se = c + cols + 1;

                        if (ex_nd[nw] || ex_nd[n] || ex_nd[ne] || ex_nd[w] ||
                            ex_nd[sw] || ex_nd[e] || ex_nd[se] || ex_nd[s])
                        {
                            ex_nd[c] = true;
                            done = false;
                        }
                    }
                for (i = rows - 3; i > 1; i--)
                    for (j = cols - 2; j > 1; j--)
                    {
                        c = i * cols + j;
                        if (!noDataMap[c] || ex_nd[c])
                        {
                            continue;
                        }
                        nw = c - cols - 1;
                        n = c - cols;
                        ne = c - cols + 1;
                        w = c - 1;
                        e = c + 1;
                        sw = c + cols - 1;
                        s = c + cols;
                        se = c + cols + 1;

                        if (ex_nd[nw] || ex_nd[n] ||
                            ex_nd[ne] || ex_nd[w] ||
                            ex_nd[sw] || ex_nd[e] ||
                            ex_nd[se] || ex_nd[s])
                        {
                            ex_nd[c] = true;
                            done = false;
                        }
                    }
            }
            for (i = 2; i < rows - 2; i++)
                for (j = 2; j < cols - 2; j++)
                    if (ex_nd[i * cols + j] != noDataMap[i * cols + j])
                    {
                        c = i * cols + j;
                        nw = c - cols - 1;
                        n = c - cols;
                        ne = c - cols + 1;
                        w = c - 1;
                        e = c + 1;
                        sw = c + cols - 1;
                        s = c + cols;
                        se = c + cols + 1;
                        if (ex_nd[nw] || ex_nd[n] ||
                            ex_nd[ne] || ex_nd[w] ||
                           ex_nd[sw] || ex_nd[e] ||
                           ex_nd[se] || ex_nd[s])
                        {
                            LogInteriorCluster(i - 2, j - 2);
                        }
                        if (demData.ifRepair)
                        {
                            if (demData.fillWay)
                            {
                                int count1 = 0;
                                float temp = 0.0f;
                                if (!noDataMap[n])
                                {
                                    temp = demMap[n];
                                    ++count1;
                                }
                                if (!noDataMap[ne])
                                {
                                    temp += demMap[ne];
                                    ++count1;
                                }
                                if (!noDataMap[e])
                                {
                                    temp += demMap[e];
                                    ++count1;
                                }
                                if (!noDataMap[se])
                                {
                                    temp += demMap[se];
                                    ++count1;
                                }
                                if (!noDataMap[s])
                                {
                                    temp += demMap[s];
                                    ++count1;
                                }
                                if (!noDataMap[sw])
                                {
                                    temp += demMap[sw];
                                    ++count1;
                                }
                                if (!noDataMap[w])
                                {
                                    temp += demMap[w];
                                    ++count1;
                                }
                                if (!noDataMap[nw])
                                {
                                    temp += demMap[nw];
                                    ++count1;
                                }
                                if (count1 != 0)
                                {
                                    demMap[c] = temp / count1;
                                    noDataMap[c] = false;
                                    LogFillPoint(i - 2, j - 2, demMap[c]);
                                }
                            }
                            else
                            {
                                float temp = 9999.0f;//存一个较大的值
                                if (!noDataMap[n])
                                    temp = demMap[n];
                                if (!noDataMap[ne])
                                    temp = (temp < demMap[ne] ? temp : demMap[ne]);
                                if (!noDataMap[e])
                                    temp = (temp < demMap[e] ? temp : demMap[e]);
                                if (!noDataMap[se])
                                    temp = (temp < demMap[se] ? temp : demMap[se]);
                                if (!noDataMap[s])
                                    temp = (temp < demMap[s] ? temp : demMap[s]);
                                if (!noDataMap[sw])
                                    temp = (temp < demMap[sw] ? temp : demMap[se]);
                                if (!noDataMap[w])
                                    temp = (temp < demMap[w] ? temp : demMap[w]);
                                if (!noDataMap[nw])
                                    temp = (temp < demMap[nw] ? temp : demMap[nw]);
                                demMap[c] = temp;
                                noDataMap[c] = false;
                                LogFillPoint(i - 2, j - 2, temp);
                            }
                        }
                        else
                        {
                            LogExit();
                        }
                        count++;
                    }
            //Console.WriteLine("count = {0}", count);
            if (count == 0)
            {
                LogVerifiedDEM();
            }
            else
            {
                LogVerifiedDEM1(count);
            }

            ex_nd = null;

            FreeMemory();
        }
        public void LogVerifiedDEM()
        {
            sw.Write("There are no interior NODATA cells ");
            sw.WriteLine("surrounded by valid DEM cells");
        }
        public void LogVerifiedDEM1(int count)
        {
            sw.WriteLine("There are {0} cell have filled !", count);
        }
        public void LogFileError(string fileNamepPath, string lff_action)
        {
            sw.WriteLine("An error occurred while opening file: {0}", fileNamepPath);

            if (lff_action[0] == 'r')
                sw.WriteLine("Unable to read from this file");
            if (lff_action[0] == 'r')
                sw.WriteLine("Program execution halted");
            if (lff_action[0] == 'w')
                sw.WriteLine("Unable to write to this file");
            if (lff_action[0] == 'w')
                sw.WriteLine("Program execution halted");
            Environment.Exit(0);
        }
        public void WriteDEMGrid(string fileNamePath, DemData dd, bool[] noDataMap, float[] demMap)
        {
            int i, j;
            int cols = dd.imagNcols;
            int rows = dd.imagNrows;

            fp = new StreamWriter(fileNamePath);

            if (fp == null) // Handle error opening file
                LogFileError(fileNamePath, "w");

            fp.WriteLine("ncols         {0}", dd.ncols);
            fp.WriteLine("nrows         {0}", dd.nrows);
            fp.WriteLine("xllcorner     {0}", dd.xllcorner);
            fp.WriteLine("yllcorner     {0}", dd.yllcorner);
            if (dd.cellType)
                fp.WriteLine("cellSize      {0}", dd.cellStep);
            else
                fp.WriteLine("cellSize      {0}", (int)dd.cellStep);

            fp.WriteLine("NODATA_value  {0}", dd.intNoData);
            int c = 0;
            for (i = 2; i < rows - 2; i++)
            {
                for (j = 2; j < cols - 2; j++)
                {
                    c = i * cols + j;
                    if (noDataMap[c])
                    {
                        fp.Write("{0} ", dd.intNoData);
                    }
                    else
                    {
                        if (dd.floatOrInt)
                        {
                            if (dd.dataPrecision == 1)
                                fp.Write("{0:f1} ", demMap[c]);
                            else if (dd.dataPrecision == 2)
                                fp.Write("{0:f2} ", demMap[c]);
                            else
                                fp.Write("{0:f3} ", demMap[c]);
                        }
                        else
                        {
                            fp.Write("{0} ", (int)demMap[c]);
                        }
                    }
                }
                fp.WriteLine();
            }
            fp.Flush();
            fp.Close();

            FreeMemory();
        }

        bool Toggle = true;
        public void LogFill(int i, int j, int precision, float old, float min)
        {
            bool flag;
            bool start = true;
            if (start)
            {
                flag = true;
                start = false;
            }
            else
                flag = Toggle;
            if (flag)
            {
                if (precision == 0)
                    sw.Write("Cell[{0}][{1}] with a value of {2}", i, j, (int)old);
                else
                    if (precision == 1)
                        sw.Write("Cell[{0}][{1}] with a value of {2:f1}", i, j, old);
                    else if (precision == 2)
                        sw.Write("Cell[{0}][{1}] with a value of {2:f2}", i, j, old);
                    else
                        sw.Write("Cell[{0}][{1}] with a value of {2:f3}", i, j, old);


                if (precision == 0)
                    sw.WriteLine(" was sink filled to {0}", min);
                else if (precision == 1)
                    sw.WriteLine(" was sink filled to {0:f1}", min);
                else if (precision == 2)
                    sw.WriteLine(" was sink filled to {0:f2}", min);
                else
                    sw.WriteLine(" was sink filled to {0:f3}", min);

                Toggle = false;
            }
            else
            {
                if (precision == 0)
                    sw.WriteLine("[{0}][{1}], {2}, {3}", i, j, (int)old, min)
                ;
                else
                    if (precision == 1)
                        sw.WriteLine("[{0}][{1}], {2:f2}, {3:f1}", i, j, old, min);
                    else if (precision == 2)
                        sw.WriteLine("[{0}][{1}], {2:f2}, {3:f2}", i, j, old, min);
                    else
                        sw.WriteLine("[{0}][{1}], {2:f3}, {3:f3}", i, j, old, min);

            }
        }
        public void LogWroteDEM(string fileName)
        {
            sw.WriteLine("Data successfully written to: {0}", fileName);
        }
        public void LogAnnulusFill(int i, int j, int precision, float old, float min)
        {
            bool flag;
            bool start = true;

            if (start)
                flag = start = false;
            else
                flag = Toggle;

            if (!flag)
            {
                if (precision == 0)
                    sw.Write("Cell[{0}][{1}] with a value of {2}", i, j, (int)old);
                else if (precision == 1)
                    sw.Write("Cell[{0}][{1}] with a value of {2:f1}", i, j, old);
                else if (precision == 2)
                    sw.Write("Cell[{0}][{1}] with a value of {2:f2}", i, j, old);
                else
                    sw.Write("Cell[{0}][{1}] with a value of {2:f3}", i, j, old);

                if (precision == 0)
                    sw.WriteLine(" It was annulus filled to {0}", (int)min);
                else if (precision == 1)
                    sw.WriteLine(" It was annulus filled to {0:f1}", min);
                else if (precision == 2)
                    sw.WriteLine(" It was annulus filled to {0:f2}", min);
                else
                    sw.WriteLine(" It was annulus filled to {0:f3}", min);

                Toggle = true;
            }
            else
            {
                if (precision == 0)
                    sw.WriteLine("[{0}][{1}], {2}, {3}", i, j, (int)old, min);
                else if (precision == 1)
                    sw.WriteLine("[{0}][{1}], {2:f1}, {3:f1}", i, j, old, min);
                else if (precision == 2)
                    sw.WriteLine("[{0}][{1}], {2:f2}, {3:f2}", i, j, old, min);
                else
                    sw.WriteLine("[{0}][{1}], {2:f3}, {3:f3}", i, j, old, min);

            }
        }
        public void Log_CLSE_LSWarning(int rusle_csle)
        {
            if (rusle_csle == 1)
                sw.WriteLine("The CLSE LS data has been saved !");
            else
                sw.WriteLine("The RUSLE LS data has been saved !");
            //sw.WriteLine("The RUSLE LS data has been scaled by 100 !");
            //sw.WriteLine("NOTE: These values are 100 times the actual CLSE LS value.");
        }
        /* zhangjie.2010.06.15
         * open file and write weigth data,and close file
         */
        public void WriteWeightFile(string fileName, ref DemData dd, ref bool[] noDataMap, ref OutFlow[] outFlow)
        {
            int rows, cols;
            int i, j;
            rows = dd.imagNrows;
            cols = dd.imagNcols;

            fp = new StreamWriter(fileName);

            if (fp == null)
                LogFileError(fileName, "w");

            fp.WriteLine("ncols         {0}", dd.ncols);
            fp.WriteLine("nrows         {0}", dd.nrows);
            fp.WriteLine("xllcorner     {0}", dd.xllcorner);
            fp.WriteLine("yllcorner     {0}", dd.yllcorner);
            if (dd.cellType)
                fp.WriteLine("cellSize      {0}", dd.cellStep);
            else
                fp.WriteLine("cellSize      {0}", (int)dd.cellStep);
            fp.WriteLine("NOOUT_value  255");
            for (i = 2; i < rows - 2; i++)
            {
                for (j = 2; j < cols - 2; j++)
                {
                    int c = i * cols + j;
                    for (int k = 0; k < 8; ++k)
                    {
                        if (outFlow[c].m_weight[k] == OutFlow.NOOUT)
                        {
                            fp.Write("{0} ", 0);
                        }
                        //else if(outFlow[c].m_weight[k] > 100)
                        //{
                        //    fp.Write(" {0:f2}", ((float)(255 - outFlow[c].m_weight[k])) / 100);
                        //}
                        else
                        {

                            fp.Write("{0:f2} ", ((float)outFlow[c].m_weight[k]) / 100);
                        }
                    }
                }
                fp.WriteLine();
            }
            fp.Flush();
            fp.Close();
        }
        // Open file and write Slope Length data, close file
        public void WriteSlopeLenFile(string fileName, ref DemData dd, ref bool[] noDataMap, ref float[] slopeLen)
        {
            int rows, cols;
            int i, j;
            rows = dd.imagNrows;
            cols = dd.imagNcols;

            fp = new StreamWriter(fileName);

            if (fp == null)
                LogFileError(fileName, "w");

            fp.WriteLine("ncols         {0}", dd.ncols);
            fp.WriteLine("nrows         {0}", dd.nrows);
            fp.WriteLine("xllcorner     {0}", dd.xllcorner);
            fp.WriteLine("yllcorner     {0}", dd.yllcorner);
            if (dd.cellType)
                fp.WriteLine("cellSize      {0}", dd.cellStep);
            else
                fp.WriteLine("cellSize      {0}", (int)dd.cellStep);

            fp.WriteLine("NODATA_value  -9.9");

            for (i = 2; i < rows - 2; i++)
            {
                for (j = 2; j < cols - 2; j++)
                {
                    if (noDataMap[i * cols + j])
                        fp.Write("-9.9 ");
                    else
                        fp.Write("{0:f3} ", slopeLen[i * cols + j]);
                }
                fp.WriteLine();
            }
            fp.Flush();
            fp.Close();
        }
        public void WriteSlopeAngFile(string fileName, DemData dd, bool[] noDataMap, float[] slopeAng)
        {
            int rows, cols;
            int i, j;
            rows = dd.imagNrows;
            cols = dd.imagNcols;

            fp = new StreamWriter(fileName);
            if (fp == null) // Handle error opening file
                LogFileError(fileName, "w");

            fp.WriteLine("ncols         {0}", dd.ncols);
            fp.WriteLine("nrows         {0}", dd.nrows);
            fp.WriteLine("xllcorner     {0}", dd.xllcorner);
            fp.WriteLine("yllcorner     {0}", dd.yllcorner);
            if (dd.cellType)
                fp.WriteLine("cellSize      {0}", dd.cellStep);
            else
                fp.WriteLine("cellSize      {0}", (int)dd.cellStep);

            fp.WriteLine("NODATA_value  -9.9");
            for (i = 2; i < rows - 2; i++)
            {
                for (j = 2; j < cols - 2; j++)
                    if (noDataMap[i * cols + j])
                        fp.Write("-9.9 ");
                    else
                        fp.Write("{0:f4} ", slopeAng[i * cols + j]);
                fp.WriteLine();
            }

            fp.Flush();
            fp.Close();
        }
        public void WriteSlopeExponentFile(string fileName, DemData dd, bool[] noDataMap, float[] slopeAng)
        {
            int rows, cols;
            int i, j;

            rows = dd.imagNrows;
            cols = dd.imagNcols;

            fp = new StreamWriter(fileName);
            if (fp == null) // Handle error opening file
                LogFileError(fileName, "w");


            fp.WriteLine("ncols         {0}", dd.ncols);
            fp.WriteLine("nrows         {0}", dd.nrows);
            fp.WriteLine("xllcorner     {0}", dd.xllcorner);
            fp.WriteLine("yllcorner     {0}", dd.yllcorner);
            if (dd.cellType)
                fp.WriteLine("cellSize      {0}", dd.cellStep);
            else
                fp.WriteLine("cellSize      {0}", (int)dd.cellStep);

            fp.WriteLine("NODATA_value  {0}", dd.intNoData);

            fp.WriteLine("NODATA_value  -9.9");

            for (i = 2; i < rows - 2; i++)
            {
                for (j = 2; j < cols - 2; j++)
                {
                    if (noDataMap[i * cols + j])
                        fp.Write("-9.9 ");
                    else
                        fp.Write("{0:f2} ", TableLookUp_csle(slopeAng[i * cols + j]));
                }
                fp.WriteLine();
            }
            fp.Flush();
            fp.Close();
        }
        //单流向算法下计算0.5和0.7的点位置
        public void WriteSlopeFactorFile(string fileName, DemData dd, bool[] noDataMap, float[] slopeAng)
        {
            int rows, cols;
            int i, j;
            rows = dd.imagNrows;
            cols = dd.imagNcols;

            fp = new StreamWriter(fileName);
            if (fp == null) // Handle error opening file
                LogFileError(fileName, "w");

            fp.WriteLine("ncols         {0}", dd.ncols);
            fp.WriteLine("nrows         {0}", dd.nrows);
            fp.WriteLine("xllcorner     {0}", dd.xllcorner);
            fp.WriteLine("yllcorner     {0}", dd.yllcorner);
            if (dd.cellType)
                fp.WriteLine("cellSize      {0}", dd.cellStep);
            else
                fp.WriteLine("cellSize      {0}", (int)dd.cellStep);
            fp.WriteLine("NODATA_value  -9.9");

            for (i = 2; i < rows - 2; i++)
            {
                for (j = 2; j < cols - 2; j++)
                {
                    if (noDataMap[i * cols + j])
                        fp.Write("-9.9 ");
                    else
                    {
                        if (slopeAng[i * cols + j] < 2.8624)
                            fp.Write("{0:f1} ", dd.scf_lt5);
                        else
                            fp.Write("{0:f1} ", dd.scf_ge5);
                    }

                }
                fp.WriteLine();
            }
            fp.Flush();
            fp.Close();
        }
        public void WriteDirectionArray(string fileName, ref DemData dd, ref bool[] noDatamMap, ref byte[] outFlow)
        {
            int rows, cols;
            int i, j;
            rows = dd.imagNrows;
            cols = dd.imagNcols;
            fp = new StreamWriter(fileName);
            if (fp == null) // Handle error opening file
                LogFileError(fileName, "w");
            fp.WriteLine("ncols         {0}", dd.ncols);
            fp.WriteLine("nrows         {0}", dd.nrows);
            fp.WriteLine("xllcorner     {0}", dd.xllcorner);
            fp.WriteLine("yllcorner     {0}", dd.yllcorner);
            if (dd.cellType)
                fp.WriteLine("cellSize      {0}", dd.cellStep);
            else
                fp.WriteLine("cellSize      {0}", (int)dd.cellStep);
            //fp.WriteLine("NODATA_value  {0}", dd.intNoData);
            fp.WriteLine("NODATA_value  -9");
            int count = 0;
            for (i = 2; i < rows - 2; i++)
            {
                for (j = 2; j < cols - 2; j++)
                {
                    if (noDatamMap[i * cols + j])
                        fp.Write("-9 ");
                    else
                    {
                        if (outFlow[i * cols + j] == 0)
                        {
                            count++;
                        }
                        fp.Write("{0} ", outFlow[i * cols + j]);
                    }
                }
                fp.WriteLine();
            }
            Debug.WriteLine("count = " + count);
            fp.Flush();
            fp.Close();
        }
        public void Write_Direction_Array(string fileName, ref DemData dd, ref bool[] noDataMap, ref byte[] inMap)
        {
            int rows, cols;
            int i, j;
            rows = dd.imagNrows;
            cols = dd.imagNcols;
            fp = new StreamWriter(fileName);
            if (fp == null) // Handle error opening file
                LogFileError(fileName, "w");
            fp.WriteLine("ncols         {0}", dd.ncols);
            fp.WriteLine("nrows         {0}", dd.nrows);
            fp.WriteLine("xllcorner     {0}", dd.xllcorner);
            fp.WriteLine("yllcorner     {0}", dd.yllcorner);
            if (dd.cellType)
                fp.WriteLine("cellSize      {0}", dd.cellStep);
            else
                fp.WriteLine("cellSize      {0}", (int)dd.cellStep);
            //fp.WriteLine("NODATA_value  {0}", dd.intNoData);
            fp.WriteLine("NODATA_value  -9");

            for (i = 2; i < rows - 2; i++)
            {
                for (j = 2; j < cols - 2; j++)
                {
                    if (noDataMap[i * cols + j])

                        fp.Write("-9 ");
                    else
                        fp.Write("{0} ", (int)inMap[i * cols + j]);
                }
                fp.WriteLine();
            }
            fp.Flush();
            fp.Close();
        }
        public void WriteBoolGrid(string fileName, DemData dd, bool[] noDataMap, bool[] grid)
        {
            int rows, cols;
            int i, j;
            rows = dd.imagNrows;
            cols = dd.imagNcols;

            fp = new StreamWriter(fileName);
            if (fp == null)
                LogFileError(fileName, "w");

            fp.WriteLine("ncols         {0}", dd.ncols);
            fp.WriteLine("nrows         {0}", dd.nrows);
            fp.WriteLine("xllcorner     {0}", dd.xllcorner);
            fp.WriteLine("yllcorner     {0}", dd.yllcorner);
            if (dd.cellType)
                fp.WriteLine("cellSize      {0}", dd.cellStep);
            else
                fp.WriteLine("cellSize      {0}", (int)dd.cellStep);
            fp.WriteLine("NODATA_value  -9");

            for (i = 2; i < rows - 2; i++)
            {
                for (j = 2; j < cols - 2; j++)
                {
                    if (grid[i * cols + j])
                        fp.Write("1 ");
                    else
                        fp.Write("0 ");
                }
                fp.WriteLine();
            }
            fp.Flush();
            fp.Close();
        }
        public void LogCumulativeProgress(int lcp_count, int lcp_p1, int lcp_p2)
        {
            if (lcp_count == 1)
                sw.WriteLine("Beginning cumulative length calculations");
            sw.WriteLine("Pass # {0,-3:d} Part 1 hits = {1,-9:d}	Part # 2 {2,-9:d}", lcp_count, lcp_p1, lcp_p2);
            if (lcp_p1 == 0 && lcp_p2 == 0)
                sw.WriteLine("Cumulative length calculations completed");
        }
        //关闭日志文件
        public void CloseLogFile()
        {
            sw.Flush();
            sw.Close();
        }
        public void WriteSlopeLenFeet(string fileName, DemData dd, bool[] noDataMap, float[] grid)
        {
            int rows, cols;
            int i, j;

            rows = dd.imagNrows;
            cols = dd.imagNcols;

            fp = new StreamWriter(fileName);
            if (fp == null) // Handle error opening file
                LogFileError(fileName, "w");

            fp.WriteLine("ncols         {0}", dd.ncols);
            fp.WriteLine("nrows         {0}", dd.nrows);
            fp.WriteLine("xllcorner     {0}", dd.xllcorner);
            fp.WriteLine("yllcorner     {0}", dd.yllcorner);
            if (dd.cellType)
                fp.WriteLine("cellSize      {0}", dd.cellStep);
            else
                fp.WriteLine("cellSize      {0}", (int)dd.cellStep);

            fp.WriteLine("NODATA_value  -9.9");
            for (i = 2; i < rows - 2; i++)
            {
                for (j = 2; j < cols - 2; j++)
                {
                    if (noDataMap[i * cols + j])
                        fp.Write("-9.9 ");
                    else
                        fp.Write("{0:f3} ", grid[i * cols + j]);
                }
                fp.WriteLine();

            }
            fp.Flush();
            fp.Close();
        }
        public void Write_FloatGrid(string fileName, DemData dd, bool[] noDataMap, float[] grid)
        {
            int rows, cols;
            int i, j;
            rows = dd.imagNrows;
            cols = dd.imagNcols;
            fp = new StreamWriter(fileName);
            if (fp == null) // Handle error opening file
                LogFileError(fileName, "w");


            fp.WriteLine("ncols         {0}", dd.ncols);
            fp.WriteLine("nrows         {0}", dd.nrows);
            fp.WriteLine("xllcorner     {0}", dd.xllcorner);
            fp.WriteLine("yllcorner     {0}", dd.yllcorner);
            if (dd.cellType)
                fp.WriteLine("cellSize      {0}", dd.cellStep);
            else
                fp.WriteLine("cellSize      {0}", (int)dd.cellStep);

            fp.WriteLine("NODATA_value  -9.9");

            for (i = 2; i < rows - 2; i++)
            {
                for (j = 2; j < cols - 2; j++)
                    if (noDataMap[i * cols + j])
                        fp.Write("-9.9 ");
                    else
                        fp.Write("{0:f4} ", grid[i * cols + j]);
                fp.WriteLine();
            }
            fp.Flush();
            fp.Close();
        }
        // Open file and write Rusle LS2 data, close file
        public void Write_LS2(string fileName, DemData dd, bool[] noDataMap, float[] grid)
        {
            int rows, cols;
            int i, j;

            rows = dd.imagNrows;
            cols = dd.imagNcols;
            fp = new StreamWriter(fileName);
            if (fp == null) // Handle error opening file
                LogFileError(fileName, "w");


            fp.WriteLine("ncols         {0}", dd.ncols);
            fp.WriteLine("nrows         {0}", dd.nrows);
            fp.WriteLine("xllcorner     {0}", dd.xllcorner);
            fp.WriteLine("yllcorner     {0}", dd.yllcorner);
            if (dd.cellType)
                fp.WriteLine("cellSize      {0}", dd.cellStep);
            else
                fp.WriteLine("cellSize      {0}", (int)dd.cellStep);

            fp.WriteLine("NODATA_value -9");
            for (i = 2; i < rows - 2; i++)
            {
                for (j = 2; j < cols - 2; j++)
                    if (noDataMap[i * cols + j])
                        fp.Write("-9 ");
                    else if ((int)(grid[i * cols + j] + 0.5) != 0)
                        fp.Write("{0:f2} ", (grid[i * cols + j] + 0.5));
                    else
                        fp.Write("0.01 ");//原始值为1,20110610改为0.01
                fp.WriteLine();
            }
            fp.Flush();
            fp.Close();
        }

        #endregion
        //##############################################



        //                    DemRepair



        //##############################################

        #region DemRepair
        public bool FillSinks(DemData demData, ref bool[] noDataMap, ref float[] demMap)
        {
            bool flag = false;
            int i; /*Loop Counter.*/
            int j; /*Loop Counter.*/
            int rows; /*Number of rows.*/
            int cols; /*Number of columns.*/
            float min; /*Temp value */
            float old; /*temp debugging value */
            int nw, n, ne, w, c, e, sw, s, se;
            rows = demData.imagNrows;
            cols = demData.imagNcols;
            float Min = (float)100000.0;
            min = Min;
            for (i = 2; i < demData.imagNrows - 2; i++)
                for (j = 2; j < demData.imagNcols - 2; j++)
                {
                    c = i * cols + j;
                    nw = c - cols - 1;
                    n = c - cols;
                    ne = c - cols + 1;
                    w = c - 1;
                    e = c + 1;
                    sw = c + cols - 1;
                    s = c + cols;
                    se = c + cols + 1;
                    //按照程序的思路来讲，洼地的定义是本身是有值点，周围的四周必须有值而且周围的值都大于中心点
                    //于是我将程序进行了修改
                    //那么另外一个问题是，假如两个具有相同的值的点相连，并且周围的值都大于这两个点，怎么办呢？程序是解决不了的这个问题
                    //还是说这样的点就不算洼地了呢？？
                    if (noDataMap[c])
                        continue;
                    min = (float)100000.0; //放一个最大值，
                    //判断周围是否有值，只要有一个无值则继续循环
                    if (noDataMap[nw] && noDataMap[n] && noDataMap[ne] &&
                        noDataMap[e] && noDataMap[se] && noDataMap[s]
                        && noDataMap[sw] && noDataMap[w])
                    {
                        continue;
                    }
                    min = demMap[nw] < min ? demMap[nw] : min;
                    min = demMap[n] < min ? demMap[n] : min;
                    min = demMap[ne] < min ? demMap[ne] : min;
                    min = demMap[e] < min ? demMap[e] : min;
                    min = demMap[se] < min ? demMap[se] : min;
                    min = demMap[s] < min ? demMap[s] : min;
                    min = demMap[sw] < min ? demMap[sw] : min;
                    min = demMap[w] < min ? demMap[w] : min;
                    //如果最小值大于中心值，说明是洼地，则进行填充
                    if (min > demMap[c])
                    {
                        flag = true;
                        old = demMap[c];
                        demMap[c] = min;
                        LogFill(i - 2, j - 2, demData.dataPrecision, old, min);
                    }
                }
            return flag;
        }
        public bool AnnulusFill(DemData demData, ref bool[] noDataMap, ref float[] demMap)
        {
            bool flag = false;
            int i; /*Loop Counter.*/
            int j; /*Loop Counter.*/
            int rows; /*Number of rows.*/
            int cols; /*Number of columns.*/
            float min; /*Temp value */
            float old; /*Used for log file */
            int nw, n, ne, w, c, e, sw, s, se;
            int nnww, nnw, nn, nne, nnee;
            int nww, nee, ww, ee, sww, see;
            int ssww, ssw, ss, sse, ssee;
            /*张杰的修改*/
            rows = demData.imagNrows;
            cols = demData.imagNcols;
            for (i = 2; i < rows - 2; i++)
            {
                for (j = 2; j < cols - 2; j++)
                {
                    c = i * cols + j;

                    if (noDataMap[c])
                    {
                        continue;
                    }
                    nw = c - cols - 1;
                    n = c - cols;
                    ne = c - cols + 1;
                    w = c - 1;
                    e = c + 1;
                    sw = c + cols - 1;
                    s = c + cols;
                    se = c + cols + 1;

                    // Do next cell if any adjacent cell contains nodata

                    if (noDataMap[nw] || noDataMap[n] || noDataMap[ne] || noDataMap[w] ||
                        noDataMap[e] || noDataMap[sw] || noDataMap[s] || noDataMap[se])
                    {
                        continue;
                    }

                    min = demMap[nw] < demMap[n] ? demMap[nw] : demMap[n];
                    min = demMap[ne] < min ? demMap[ne] : min;
                    min = demMap[w] < min ? demMap[w] : min;
                    min = demMap[e] < min ? demMap[e] : min;
                    min = demMap[sw] < min ? demMap[sw] : min;
                    min = demMap[s] < min ? demMap[s] : min;
                    min = demMap[se] < min ? demMap[se] : min;

                    // Do next cell unless the case where min == dem[c] 

                    if (GlobalConstants.FUZZ < Math.Abs(min - demMap[c]))
                    {
                        continue;
                    }
                    nn = n - cols;
                    nnww = nn - 2;
                    nnw = nn - 1;
                    nne = nn + 1;
                    nnee = nn + 2;
                    nww = nw - 1;
                    nee = ne + 1;
                    ww = w - 1;
                    ee = e + 1;
                    sww = sw - 1;
                    see = se + 1;
                    ss = s + cols;
                    ssww = ss - 2;
                    ssw = ss - 1;
                    sse = ss + 1;
                    ssee = ss + 2;

                    // Move on to the next cell if the annulus ring contains a nodata cell

                    if (noDataMap[nnww] || noDataMap[nnw] || noDataMap[nn] || noDataMap[nne] ||
                        noDataMap[nnee] || noDataMap[nww] || noDataMap[nee] || noDataMap[ww] ||
                        noDataMap[ee] || noDataMap[sww] || noDataMap[see] || noDataMap[ssww] ||
                        noDataMap[ssw] || noDataMap[ss] || noDataMap[sse] || noDataMap[ssee])
                    {
                        continue;
                    }

                    // Determine the minimum value within the annulus ring.

                    min = demMap[nnww] < demMap[nnw] ? demMap[nnww] : demMap[nnw];
                    min = min < demMap[nn] ? min : demMap[nn];
                    min = min < demMap[nne] ? min : demMap[nne];
                    min = min < demMap[nnee] ? min : demMap[nnee];
                    min = min < demMap[nww] ? min : demMap[nww];
                    min = min < demMap[nee] ? min : demMap[nee];
                    min = min < demMap[ww] ? min : demMap[ww];
                    min = min < demMap[ss] ? min : demMap[ee];
                    min = min < demMap[sww] ? min : demMap[sww];
                    min = min < demMap[see] ? min : demMap[see];
                    min = min < demMap[ssww] ? min : demMap[ssww];
                    min = min < demMap[ssw] ? min : demMap[ssw];
                    min = min < demMap[ss] ? min : demMap[ss];
                    min = min < demMap[sse] ? min : demMap[sse];
                    min = min < demMap[ssee] ? min : demMap[ssee];

                    // If the center cell is lower than all the cells in the annulus ring then
                    // replace this cell value with the minimum value found in the annulus ring.

                    if (min > demMap[c])
                    {
                        flag = true;
                        old = demMap[c];
                        demMap[c] = min;
                        if (demMap[nw] < min) demMap[nw] = min;
                        if (demMap[n] < min) demMap[n] = min;
                        if (demMap[ne] < min) demMap[ne] = min;
                        if (demMap[w] < min) demMap[w] = min;
                        if (demMap[e] < min) demMap[e] = min;
                        if (demMap[sw] < min) demMap[sw] = min;
                        if (demMap[s] < min) demMap[s] = min;
                        if (demMap[se] < min) demMap[se] = min;
                        //Console.WriteLine("i = {0},j = {1},min = {2},dem[3] = {3}", i - 2, j - 2, min, dem[c]);
                        //LogAnnulusFill(i, j, demData.fp_precision, old, min);
                        LogAnnulusFill(i - 2, j - 2, demData.dataPrecision, old, min);
                    }
                }
            }

            return flag;
        }

        #endregion

        //##############################################



        //                    CalcData



        //##############################################
        #region CalcData
        /* zhangjie, 2010.08.06
         * 利用“三阶不带权差分”计算坡度
         */
        public void downAng(DemData demData, bool[] noDataMap, float[] demMap, ref float[] slopeAng)
        {
            float deg = (float)57.29577951308;
            int rows; // Number of rows
            int cols; // Number of columns
            double cellStep; // DEM Cell Size
            int nw, n, ne, w, c, e, sw, s, se;

            rows = demData.imagNrows;
            cols = demData.imagNcols;
            cellStep = demData.cellStep;

            double cellStep_step = demData.cellStep;
            deg = (float)57.29577951308;
            double cellStep_std = 2 * Math.PI * GlobalConstants.earthR * cellStep_step / 360;//20140726
            float cellStepY;//前一行的垂直长度

            float z1, z2, z3, z4, z5, z6, z7, z8, z9;
            float fx;
            float fy;
            // 
            for (int i = 2; i < rows - 2; i++)
            {
                for (int j = 2; j < cols - 2; j++)
                {
                    // 初始化

                    c = i * cols + j;
                    if (noDataMap[c])
                    {
                        slopeAng[c] = (float)0.0;
                        continue;
                    }
                    nw = c - cols - 1;
                    n = c - cols;
                    ne = c - cols + 1;
                    w = c - 1;
                    e = c + 1;
                    sw = c + cols - 1;
                    s = c + cols;
                    se = c + cols + 1;

                    // 数值初始化
                    z1 = z2 = z3 = z4 = z5 = z6 = z7 = z8 = z9 = demMap[c];
                    fx = fy = 0.0f;
                    //西(west)
                    if (noDataMap[w] == false)
                    {
                        z4 = demMap[w];
                    }
                    //西北(north west)
                    if (noDataMap[nw] == false)
                    {
                        z7 = demMap[nw];
                    }
                    //北(north)
                    if (noDataMap[n] == false)
                    {
                        z8 = demMap[n];
                    }
                    // 东北(north east)
                    if (noDataMap[ne] == false)
                    {
                        z9 = demMap[ne];
                    }
                    // 东(east)
                    if (noDataMap[e] == false)
                    {
                        z6 = demMap[e];
                    }
                    // 东南(south east)
                    if (noDataMap[se] == false)
                    {
                        z3 = demMap[se];
                    }
                    // 南(south)
                    if (noDataMap[s] == false)
                    {
                        z2 = demMap[s];
                    }
                    // 西南(south west)
                    if (noDataMap[sw] == false)
                    {
                        z1 = demMap[sw];
                    }
                    
                    //fx = (z7 - z1 + z8 - z2 + z9 - z3) / (6 * cellStep);
                    //fy = (z3 - z1 + z6 - z4 + z9 - z7) / (6 * cellStep);
                    //改于2010.08.13
                    //fx = (z7 - z1 + 2 * (z8 - z2) + z9 - z3) / (8 * cellStep);
                    //fy = (z3 - z1 + 2 * (z6 - z4) + z9 - z7) / (8 * cellStep);

                    //added by WangShuai 20140727
                    cellStepY = (float)cellStep_std * (float)Math.Cos((demData.yllcorner + cellStep_step * (i - 2)) / deg);


                    fx = (z7 - z1 + 2 * (z8 - z2) + z9 - z3) / ( 8 * (float)cellStep_std );
                    fy = (z3 - z1 + 2 * (z6 - z4) + z9 - z7) / (8 * cellStepY );

                    slopeAng[c] = deg * (float)Math.Atan(Math.Sqrt((double)(fx * fx + fy * fy)));
                }
            }
        }
        /* zhangjie,2010.06.14
         * zhhm20101011计算权重,不带截断
         */
        public void downWeight(DemData demData, bool[] noDataMap, float[] demMap,ref OutFlow[] outFlow,ref float[] slopeAng)
        {
            double cellStep = demData.cellStep;
            double diagcellStep = cellStep * (float)1.4142136;
            int rows = demData.imagNrows;
            int cols = demData.imagNcols;
            int nw, n, ne, w, c, e, sw, s, se;
            float total = 0.0f, temp; // 记录总和;
            bool ifcut = false;
            for (int i = 2; i < rows - 2; i++)
            {
                for (int j = 2; j < cols - 2; j++)
                {
                    // Debug.WriteLine("i = " + i + "j = " + j);
                    c = i * cols + j;
                    if (noDataMap[c])
                    {
                        // 如果为无值点，则没有流出。
                        continue;
                    }
                    nw = c - cols - 1;
                    n = c - cols;
                    ne = c - cols + 1;
                    w = c - 1;
                    e = c + 1;
                    sw = c + cols - 1;
                    s = c + cols;
                    se = c + cols + 1;
                    total = 0.0f; // 记录总和

                    // 有值并且要比中心值小
                    // 西北(north west)
                    if (!noDataMap[nw] && demMap[nw] < demMap[c])
                    {
                        // bool ifcut = IsCutDirection(diagcellStep, demMap[c], demMap[nw], demData, slopeAng[nw]);
                        //if (!ifcut)
                        //{
                        //    total += (demMap[c] - demMap[nw]) / 4;
                        //}
                        total += (demMap[c] - demMap[nw]) / 4;
                    }
                    // 北(north)
                    if (!noDataMap[n] && demMap[n] < demMap[c])
                    {
                        //bool ifcut = IsCutDirection(cellStep, demMap[c], demMap[n], demData, slopeAng[n]);
                        //if (!ifcut)
                        //{
                        //    total += (demMap[c] - demMap[n]) / 2;
                        //}
                        total += (demMap[c] - demMap[n]) / 2;
                    }
                    // 东北(north east)
                    if (!noDataMap[ne] && demMap[ne] < demMap[c])
                    {
                        //bool ifcut = IsCutDirection(diagcellStep, demMap[c], demMap[ne], demData, slopeAng[ne]);
                        //if (!ifcut)
                        //{
                        //    total += (demMap[c] - demMap[ne]) / 4;
                        //}
                        total += (demMap[c] - demMap[ne]) / 4;
                    }
                    // 东(east)
                    if (!noDataMap[e] && demMap[e] < demMap[c])
                    {
                        //bool ifcut = IsCutDirection(cellStep, demMap[c], demMap[e], demData, slopeAng[e]);
                        //if (!ifcut)
                        //{
                        //    total += (demMap[c] - demMap[e]) / 2;
                        //}
                        total += (demMap[c] - demMap[e]) / 2;
                    }
                    // 东南(north east)
                    if (!noDataMap[se] && demMap[se] < demMap[c])
                    {
                        //bool ifcut = IsCutDirection(diagcellStep, demMap[c], demMap[se], demData, slopeAng[se]);
                        //if (!ifcut)
                        //{
                        //    total += (demMap[c] - demMap[se]) / 4;
                        //}
                        total += (demMap[c] - demMap[se]) / 4;
                    }
                    // 南(south)
                    if (!noDataMap[s] && demMap[s] < demMap[c])
                    {
                        //bool ifcut = IsCutDirection(cellStep, demMap[c], demMap[s], demData, slopeAng[s]);
                        //if (!ifcut)
                        //{
                        //    total += (demMap[c] - demMap[s]) / 2;
                        //}
                        total += (demMap[c] - demMap[s]) / 2;
                    }
                    // 西南(south west)
                    if (!noDataMap[sw] && demMap[sw] < demMap[c])
                    {
                        //bool ifcut = IsCutDirection(diagcellStep, demMap[c], demMap[sw], demData, slopeAng[sw]);
                        //if (!ifcut)
                        //{
                        //    total += (demMap[c] - demMap[sw]) / 4;
                        //}
                        total += (demMap[c] - demMap[sw]) / 4;
                    }
                    // 西(west)
                    if (!noDataMap[w] && demMap[w] < demMap[c])
                    {
                        //bool ifcut = IsCutDirection(cellStep, demMap[c], demMap[w], demData, slopeAng[w]);
                        //if (!ifcut)
                        //{
                        //    total += (demMap[c] - demMap[w]) / 2;
                        //}
                        total += (demMap[c] - demMap[w]) / 2;
                    }

                    // 计算权值
                    if (total == 0.0f)
                    {
                        // 原则上不可能出现这种情况，因为洼地填充时已经把这种点填充了
                        // 但是由于total要做分母，所以还是判断一下比较好
                        // 

                    }
                    else
                    {
                        // 西北(north west)
                        if (!noDataMap[nw] && demMap[nw] < demMap[c])
                        {
                            //ifcut = IsCutDirection(diagcellStep, demMap[c], demMap[nw], demData, slopeAng[nw]);
                            temp = (demMap[c] - demMap[nw]) / 4;
                            if (ifcut)
                            {
                                // outFlow[c].m_weight[Index.nw] = OutFlow.NOOUT;
                                // Debug.WriteLine("A Cut point");                                
                                // 扩大100倍    ,2010.08.13去掉了0.005
                                outFlow[c].m_weight[Index.nw] = (byte)(255 - (int)(100 * (temp / total)+0.5));
                                //outFlow[c].m_weight[Index.nw] = (float)(255 - (int)(100 * (temp / total) + 0.5));
                                //outFlow[c].m_weight[Index.nw] = -100 * (temp / total);
                            }
                            else
                            {
                                //float temp = (demMap[c] - demMap[nw]) / 4;
                                // 扩大100倍    
                                //outFlow[c].m_weight[Index.nw] = 100 * (temp / total );
                                outFlow[c].m_weight[Index.nw] = (byte)(int)(100 * (temp / total) + 0.5);
                            }
                        }
                        // 北(north)
                        if (!noDataMap[n] && demMap[n] < demMap[c])
                        {
                            //ifcut = IsCutDirection(cellStep, demMap[c], demMap[n], demData, slopeAng[n]);
                            temp = (demMap[c] - demMap[n]) / 2;
                            if (ifcut == true)
                            {
                                // outFlow[c].m_weight[Index.n] = OutFlow.NOOUT;
                                // Debug.WriteLine("A Cut point");
                                //float temp = (demMap[c] - demMap[n]) / 2;
                                outFlow[c].m_weight[Index.n] = (byte)(255 - (int)(100 * (temp / total) + 0.5));
                                //outFlow[c].m_weight[Index.n] = -100 * (temp / total);
                            }
                            else
                            {
                                //float temp = (demMap[c] - demMap[n]) / 2;
                                //outFlow[c].m_weight[Index.n] = 100 * (temp / total );
                                outFlow[c].m_weight[Index.n] = (byte)(int)(100 * (temp / total) + 0.5);
                            }

                        }
                        // 东北(north east)
                        if (!noDataMap[ne] && demMap[ne] < demMap[c])
                        {
                            //ifcut = IsCutDirection(diagcellStep, demMap[c], demMap[ne], demData, slopeAng[ne]);
                            temp = (demMap[c] - demMap[ne]) / 4;
                            if (ifcut == true)
                            {
                                //  outFlow[c].m_weight[Index.ne] = OutFlow.NOOUT;
                                //Debug.WriteLine("A Cut point");
                                //float temp = (demMap[c] - demMap[ne]) / 4;
                                outFlow[c].m_weight[Index.ne] = (byte)(255 - (int)(100 * (temp / total) + 0.5));
                                //outFlow[c].m_weight[Index.ne] = -100 * (temp / total); 
                            }
                            else
                            {
                                //float temp = (demMap[c] - demMap[ne]) / 4;
                                //outFlow[c].m_weight[Index.ne] = 100 * (temp / total ); 
                                outFlow[c].m_weight[Index.ne] = (byte)(int)(100 * (temp / total) + 0.5);
                            }
                        }
                        // 东(east)
                        if (!noDataMap[e] && demMap[e] < demMap[c])
                        {
                            //ifcut = IsCutDirection(cellStep, demMap[c], demMap[e], demData, slopeAng[e]);
                            temp = (demMap[c] - demMap[e]) / 2;
                            if (ifcut == true)
                            {
                                // outFlow[c].m_weight[Index.e] = OutFlow.NOOUT;
                                // Debug.WriteLine("A Cut point");
                                //float temp = (demMap[c] - demMap[e]) / 2;
                                outFlow[c].m_weight[Index.e] = (byte)(255 - (int)(100 * (temp / total) + 0.5));
                                // outFlow[c].m_weight[Index.e] = -100 * (temp / total);
                            }
                            else
                            {
                                //float temp = (demMap[c] - demMap[e]) / 2;
                                //outFlow[c].m_weight[Index.e] = 100 * (temp / total );
                                outFlow[c].m_weight[Index.e] = (byte)(int)(100 * (temp / total) + 0.5);
                            }
                        }
                        // 东南(north east)
                        if (!noDataMap[se] && demMap[se] < demMap[c])
                        {
                            //ifcut = IsCutDirection(diagcellStep, demMap[c], demMap[se], demData, slopeAng[se]);
                            temp = (demMap[c] - demMap[se]) / 4;
                            if (ifcut == true)
                            {
                                // outFlow[c].m_weight[Index.se] = OutFlow.NOOUT;
                                // Debug.WriteLine("A Cut point");
                                //float temp = (demMap[c] - demMap[se]) / 4;
                                outFlow[c].m_weight[Index.se] = (byte)(255 - (int)(100 * (temp / total) + 0.5));
                                //outFlow[c].m_weight[Index.se] = -100 * (temp / total);
                            }
                            else
                            {
                                //float temp = (demMap[c] - demMap[se]) / 4;
                                //outFlow[c].m_weight[Index.se] = 100 * (temp / total );
                                outFlow[c].m_weight[Index.se] = (byte)(int)(100 * (temp / total) + 0.5);
                            }
                        }
                        // 南(south)
                        if (!noDataMap[s] && demMap[s] < demMap[c])
                        {
                            //ifcut = IsCutDirection(cellStep, demMap[c], demMap[s], demData, slopeAng[s]);
                            temp = (demMap[c] - demMap[s]) / 2;
                            if (ifcut == true)
                            {
                                // outFlow[c].m_weight[Index.s] = OutFlow.NOOUT;
                                // Debug.WriteLine("A Cut point");
                                //float temp = (demMap[c] - demMap[s]) / 2;
                                outFlow[c].m_weight[Index.s] = (byte)(255 - (int)(100 * (temp / total) + 0.5));
                                //outFlow[c].m_weight[Index.s] = -100 * (temp / total);
                            }
                            else
                            {
                                //float temp = (demMap[c] - demMap[s]) / 2;
                                //outFlow[c].m_weight[Index.s] = 100 * (temp / total );
                                outFlow[c].m_weight[Index.s] = (byte)(int)(100 * (temp / total) + 0.5);
                            }
                        }
                        // 西南(south west)
                        if (!noDataMap[sw] && demMap[sw] < demMap[c])
                        {
                            //ifcut = IsCutDirection(diagcellStep, demMap[c], demMap[sw], demData, slopeAng[sw]);
                            temp = (demMap[c] - demMap[sw]) / 4;
                            if (ifcut == true)
                            {
                                // outFlow[c].m_weight[Index.sw] = OutFlow.NOOUT;
                                // Debug.WriteLine("A Cut point");
                                //float temp = (demMap[c] - demMap[sw]) / 4;
                                outFlow[c].m_weight[Index.sw] = (byte)(255 - (int)(100 * (temp / total) + 0.5));
                                //outFlow[c].m_weight[Index.sw] = -100 * (temp / total);
                            }
                            else
                            {
                                //float temp = (demMap[c] - demMap[sw]) / 4;
                                outFlow[c].m_weight[Index.sw] = (byte)(int)(100 * (temp / total) + 0.5);
                            }
                        }
                        // 西(west)
                        if (!noDataMap[w] && demMap[w] < demMap[c])
                        {
                            //ifcut = IsCutDirection(cellStep, demMap[c], demMap[w], demData,slopeAng[w]);
                            temp = (demMap[c] - demMap[w]) / 2;
                            if (ifcut == true)
                            {
                                // outFlow[c].m_weight[Index.w] = OutFlow.NOOUT;
                                // Debug.WriteLine("A Cut point");
                                //float temp = (demMap[c] - demMap[w]) / 2;
                                outFlow[c].m_weight[Index.w] = (byte)(255 - (int)(100 * (temp / total) + 0.5));
                                //outFlow[c].m_weight[Index.w] = 100 * (temp / total);
                            }
                            else
                            {
                                //float temp = (demMap[c] - demMap[w]) / 2;
                                outFlow[c].m_weight[Index.w] = (byte)(int)(100 * (temp / total) + 0.5);
                            }
                        }

                    }
                }
            }
        }
        //zhhm20111011计算权重，带截断//flowcut仅仅是为了和不考虑截断的downweight的函数相区别
        public void downWeight(DemData demData, bool[] noDataMap, float[] demMap, ref OutFlow[] outFlow, ref float[] slopeAng,bool flowcut)
        {
            double cellStep = demData.cellStep;
            double diagcellStep = cellStep * (float)1.4142136;
            int rows = demData.imagNrows;
            int cols = demData.imagNcols;
            int nw, n, ne, w, c, e, sw, s, se;
            float total = 0.0f, temp; // 记录总和;
            bool ifcut = false;
            //bool boundary = false;
            for (int i = 2; i < rows - 2; i++)
            {
                for (int j = 2; j < cols - 2; j++)
                {
                    // Debug.WriteLine("i = " + i + "j = " + j);
                    c = i * cols + j;
                    if (noDataMap[c])
                    {
                        // 如果为无值点，则没有流出。
                        continue;
                    }
                    nw = c - cols - 1;
                    n = c - cols;
                    ne = c - cols + 1;
                    w = c - 1;
                    e = c + 1;
                    sw = c + cols - 1;
                    s = c + cols;
                    se = c + cols + 1;
                    total = 0.0f; // 记录总和

                    // 有值并且要比中心值小
                    // 西北(north west)

                    if (!noDataMap[nw] && demMap[nw] < demMap[c])
                    {
                        //ifcut = IsCutDirection(diagcellStep, demMap[c], demMap[nw], demData, slopeAng[nw]);
                        //if (!ifcut)
                        //{
                        //    total += (demMap[c] - demMap[nw]) / 4;
                        //}
                        total += (demMap[c] - demMap[nw]) / 4;
                    }
                    // 北(north)
                    if (!noDataMap[n] && demMap[n] < demMap[c])
                    {
                        //ifcut = IsCutDirection(cellStep, demMap[c], demMap[n], demData, slopeAng[n]);
                        //if (!ifcut)
                        //{
                        //    total += (demMap[c] - demMap[n]) / 2;
                        //}
                        total += (demMap[c] - demMap[n]) / 2;
                    }
                    // 东北(north east)
                    if (!noDataMap[ne] && demMap[ne] < demMap[c])
                    {
                        //ifcut = IsCutDirection(diagcellStep, demMap[c], demMap[ne], demData, slopeAng[ne]);
                        //if (!ifcut)
                        //{
                        //   total += (demMap[c] - demMap[ne]) / 4;
                        //}
                        total += (demMap[c] - demMap[ne]) / 4;
                    }
                    // 东(east)
                    if (!noDataMap[e] && demMap[e] < demMap[c])
                    {
                        //ifcut = IsCutDirection(cellStep, demMap[c], demMap[e], demData, slopeAng[e]);
                        //if (!ifcut)
                        //{
                        //    total += (demMap[c] - demMap[e]) / 2;
                        //}
                        total += (demMap[c] - demMap[e]) / 2;
                    }
                    // 东南(north east)
                    if (!noDataMap[se] && demMap[se] < demMap[c])
                    {
                        //ifcut = IsCutDirection(diagcellStep, demMap[c], demMap[se], demData, slopeAng[se]);
                        //if (!ifcut)
                        //{
                        //    total += (demMap[c] - demMap[se]) / 4;
                        //}
                        total += (demMap[c] - demMap[se]) / 4;
                    }
                    // 南(south)
                    if (!noDataMap[s] && demMap[s] < demMap[c])
                    {
                        //ifcut = IsCutDirection(cellStep, demMap[c], demMap[s], demData, slopeAng[s]);
                        //if (!ifcut)
                        //{
                        //    total += (demMap[c] - demMap[s]) / 2;
                        //}
                        total += (demMap[c] - demMap[s]) / 2;
                    }
                    // 西南(south west)
                    if (!noDataMap[sw] && demMap[sw] < demMap[c])
                    {
                        //ifcut = IsCutDirection(diagcellStep, demMap[c], demMap[sw], demData, slopeAng[sw]);
                        //if (!ifcut)
                        //{
                        //    total += (demMap[c] - demMap[sw]) / 4;
                        //}
                        total += (demMap[c] - demMap[sw]) / 4;
                    }
                    // 西(west)
                    if (!noDataMap[w] && demMap[w] < demMap[c])
                    {
                        //ifcut = IsCutDirection(cellStep, demMap[c], demMap[w], demData, slopeAng[w]);
                        //if (!ifcut)
                        //{
                        //    total += (demMap[c] - demMap[w]) / 2;
                        //}
                        total += (demMap[c] - demMap[w]) / 2;
                    }

                    // 计算权值
                    if (total == 0.0f)
                    {
                        // 原则上不可能出现这种情况，因为洼地填充时已经把这种点填充了
                        // 但是由于total要做分母，所以还是判断一下比较好
                        // 
                        //MessageBox.Show(i.ToString());

                        if (!noDataMap[n] && !noDataMap[ne] && !noDataMap[e] && !noDataMap[se] && !noDataMap[s]
                            && !noDataMap[sw] && !noDataMap[w] && !noDataMap[nw])
                        {
                            if (demMap[c] == demMap[n] && outFlow[n].m_weight[Index.s] != OutFlow.NOOUT - 100)
                            {
                                outFlow[c].m_weight[Index.n] = OutFlow.NOOUT - 100;
                            }
                            else if (demMap[c] == demMap[ne] && outFlow[ne].m_weight[Index.sw] != OutFlow.NOOUT - 100)
                            {
                                outFlow[c].m_weight[Index.ne] = OutFlow.NOOUT - 100;
                            }
                            else if (demMap[c] == demMap[e] && outFlow[e].m_weight[Index.w] != OutFlow.NOOUT - 100)
                            {
                                outFlow[c].m_weight[Index.e] = OutFlow.NOOUT - 100;
                            }
                            else if (demMap[c] == demMap[se] && outFlow[se].m_weight[Index.nw] != OutFlow.NOOUT - 100)
                            {
                                outFlow[c].m_weight[Index.se] = OutFlow.NOOUT - 100;
                            }
                            else if (demMap[c] == demMap[s] && outFlow[s].m_weight[Index.n] != OutFlow.NOOUT - 100)
                            {
                                outFlow[c].m_weight[Index.s] = OutFlow.NOOUT - 100;
                            }
                            else if (demMap[c] == demMap[sw] && outFlow[sw].m_weight[Index.ne] != OutFlow.NOOUT - 100)
                            {
                                outFlow[c].m_weight[Index.sw] = OutFlow.NOOUT - 100;
                            }
                            else if (demMap[c] == demMap[w] && outFlow[w].m_weight[Index.e] != OutFlow.NOOUT - 100)
                            {
                                outFlow[c].m_weight[Index.w] = OutFlow.NOOUT - 100;
                            }
                            else if (demMap[c] == demMap[nw] && outFlow[nw].m_weight[Index.se] != OutFlow.NOOUT - 100)
                            {
                                outFlow[c].m_weight[Index.nw] = OutFlow.NOOUT - 100;
                            }
                            else
                            {
                                //周围是平地且无法流出
                                //fixplatarea(c,cols);
                                bool iteraterly = true;
                                int c_now = c;
                                byte forbiddendir = 9;//没有方向
                                int nw_now, n_now, ne_now, w_now, e_now, sw_now, s_now, se_now;
                                while (iteraterly)
                                {
                                    nw_now = c_now - cols - 1;
                                    n_now = c_now - cols;
                                    ne_now = c_now - cols + 1;
                                    w_now = c_now - 1;
                                    e_now = c_now + 1;
                                    sw_now = c_now + cols - 1;
                                    s_now = c_now + cols;
                                    se_now = c_now + cols + 1;
                                    if (outFlow[c_now].m_weight[Index.nw] == OutFlow.NOOUT &&
                                    outFlow[c_now].m_weight[Index.n] == OutFlow.NOOUT &&
                                    outFlow[c_now].m_weight[Index.ne] == OutFlow.NOOUT &&
                                    outFlow[c_now].m_weight[Index.e] == OutFlow.NOOUT &&
                                    outFlow[c_now].m_weight[Index.se] == OutFlow.NOOUT &&
                                    outFlow[c_now].m_weight[Index.s] == OutFlow.NOOUT &&
                                    outFlow[c_now].m_weight[Index.sw] == OutFlow.NOOUT &&
                                    outFlow[c_now].m_weight[Index.w] == OutFlow.NOOUT)
                                    {
                                        if (demMap[c_now] == demMap[n_now] && outFlow[n_now].m_weight[Index.s] == OutFlow.NOOUT - 100 && forbiddendir != Index.n)
                                        {
                                            outFlow[c_now].m_weight[Index.n] = OutFlow.NOOUT - 100;
                                            outFlow[n_now].m_weight[Index.s] = OutFlow.NOOUT;
                                            forbiddendir = Index.s;
                                            c_now = n_now;
                                        }
                                        else if (demMap[c_now] == demMap[ne_now] && outFlow[ne_now].m_weight[Index.sw] == OutFlow.NOOUT - 100 && forbiddendir != Index.ne)
                                        {
                                            outFlow[c_now].m_weight[Index.ne] = OutFlow.NOOUT - 100;
                                            outFlow[ne_now].m_weight[Index.sw] = OutFlow.NOOUT;
                                            forbiddendir = Index.sw;
                                            c_now = ne_now;
                                        }
                                        else if (demMap[c_now] == demMap[e_now] && outFlow[e_now].m_weight[Index.w] == OutFlow.NOOUT - 100 && forbiddendir != Index.e)
                                        {
                                            outFlow[c_now].m_weight[Index.ne] = OutFlow.NOOUT - 100;
                                            outFlow[n_now].m_weight[Index.w] = OutFlow.NOOUT;
                                            forbiddendir = Index.w;
                                            c_now = e_now;
                                        }
                                        else if (demMap[c_now] == demMap[se_now] && outFlow[se_now].m_weight[Index.nw] == OutFlow.NOOUT - 100 && forbiddendir != Index.se)
                                        {
                                            outFlow[c_now].m_weight[Index.se] = OutFlow.NOOUT - 100;
                                            outFlow[se_now].m_weight[Index.nw] = OutFlow.NOOUT;
                                            forbiddendir = Index.nw;
                                            c_now = se_now;
                                        }
                                        else if (demMap[c_now] == demMap[s_now] && outFlow[s_now].m_weight[Index.n] == OutFlow.NOOUT - 100 && forbiddendir != Index.s)
                                        {
                                            outFlow[c_now].m_weight[Index.s] = OutFlow.NOOUT - 100;
                                            outFlow[s_now].m_weight[Index.n] = OutFlow.NOOUT;
                                            forbiddendir = Index.n;
                                            c_now = s_now;
                                        }
                                        else if (demMap[c_now] == demMap[sw_now] && outFlow[sw_now].m_weight[Index.ne] == OutFlow.NOOUT - 100 && forbiddendir != Index.sw)
                                        {
                                            outFlow[c_now].m_weight[Index.sw] = OutFlow.NOOUT - 100;
                                            outFlow[sw_now].m_weight[Index.ne] = OutFlow.NOOUT;
                                            forbiddendir = Index.ne;
                                            c_now = sw_now;
                                        }
                                        else if (demMap[c_now] == demMap[w_now] && outFlow[w_now].m_weight[Index.e] == OutFlow.NOOUT - 100 && forbiddendir != Index.w)
                                        {
                                            outFlow[c_now].m_weight[Index.w] = OutFlow.NOOUT - 100;
                                            outFlow[w_now].m_weight[Index.e] = OutFlow.NOOUT;
                                            forbiddendir = Index.e;
                                            c_now = w_now;
                                        }
                                        else if (demMap[c_now] == demMap[nw_now] && outFlow[nw_now].m_weight[Index.se] == OutFlow.NOOUT - 100 && forbiddendir != Index.nw)
                                        {
                                            outFlow[c_now].m_weight[Index.nw] = OutFlow.NOOUT - 100;
                                            outFlow[nw_now].m_weight[Index.se] = OutFlow.NOOUT;
                                            forbiddendir = Index.se;
                                            c_now = nw_now;
                                        }
                                        else
                                        {
                                            iteraterly = false;
                                        }

                                    }
                                    else
                                    {
                                        //MessageBox.Show(i.ToString() + ";" + j.ToString());
                                    }
                                }
                            }
                        }
                    }
                    else
                    {
                        // 西北(north west)
                        if (!noDataMap[nw] && demMap[nw] < demMap[c])
                        {
                            //ifcut = IsCutDirection(cellStep, demMap[c], demMap[n], demData, slopeAng[nw]);
                            ifcut = IsCutDirection(slopeAng[c], slopeAng[nw], demData);
                            temp = (demMap[c] - demMap[nw]) / 4;
                            if (ifcut)
                            {
                                // outFlow[c].m_weight[Index.nw] = OutFlow.NOOUT;
                                // Debug.WriteLine("A Cut point");                                
                                // 扩大100倍    ,2010.08.13去掉了0.005
                                outFlow[c].m_weight[Index.nw] = (byte)(255 - (int)(100 * (temp / total)));
                                //outFlow[c].m_weight[Index.nw] = (float)(255 - (int)(100 * (temp / total) + 0.5));
                                //outFlow[c].m_weight[Index.nw] = -100 * (temp / total);
                            }
                            else
                            {
                                //float temp = (demMap[c] - demMap[nw]) / 4;
                                // 扩大100倍    
                                outFlow[c].m_weight[Index.nw] = (byte)(int)(100 * (temp / total));
                            }
                        }
                        // 北(north)
                        if (!noDataMap[n] && demMap[n] < demMap[c])
                        {
                            //ifcut = IsCutDirection(cellStep, demMap[c], demMap[n], demData, slopeAng[n]);
                            ifcut = IsCutDirection(slopeAng[c], slopeAng[n], demData);
                            temp = (demMap[c] - demMap[n]) / 2;
                            if (ifcut)
                            {
                                // outFlow[c].m_weight[Index.n] = OutFlow.NOOUT;
                                // Debug.WriteLine("A Cut point");
                                //float temp = (demMap[c] - demMap[n]) / 2;
                                outFlow[c].m_weight[Index.n] = (byte)(255 - (int)(100 * (temp / total)));
                                //outFlow[c].m_weight[Index.n] = -100 * (temp / total);
                            }
                            else
                            {
                                //float temp = (demMap[c] - demMap[n]) / 2;
                                outFlow[c].m_weight[Index.n] = (byte)(int)(100 * (temp / total));
                            }

                        }
                        // 东北(north east)
                        if (!noDataMap[ne] && demMap[ne] < demMap[c])
                        {
                            //ifcut = IsCutDirection(diagcellStep, demMap[c], demMap[ne], demData, slopeAng[ne]);
                            ifcut = IsCutDirection(slopeAng[c], slopeAng[ne], demData);
                            temp = (demMap[c] - demMap[ne]) / 4;
                            if (ifcut)
                            {
                                //  outFlow[c].m_weight[Index.ne] = OutFlow.NOOUT;
                                //Debug.WriteLine("A Cut point");
                                //float temp = (demMap[c] - demMap[ne]) / 4;
                                outFlow[c].m_weight[Index.ne] = (byte)(255 - (int)(100 * (temp / total)));
                                //outFlow[c].m_weight[Index.ne] = -100 * (temp / total);
                            }
                            else
                            {
                                //float temp = (demMap[c] - demMap[ne]) / 4;
                                outFlow[c].m_weight[Index.ne] = (byte)(int)(100 * (temp / total));
                            }
                        }
                        // 东(east)
                        if (!noDataMap[e] && demMap[e] < demMap[c])
                        {
                            //ifcut = IsCutDirection(cellStep, demMap[c], demMap[e], demData, slopeAng[e]);
                            ifcut = IsCutDirection(slopeAng[c], slopeAng[e], demData);
                            temp = (demMap[c] - demMap[e]) / 2;
                            if (ifcut)
                            {
                                // outFlow[c].m_weight[Index.e] = OutFlow.NOOUT;
                                // Debug.WriteLine("A Cut point");
                                //float temp = (demMap[c] - demMap[e]) / 2;
                                outFlow[c].m_weight[Index.e] = (byte)(255 - (int)(100 * (temp / total)));
                                //outFlow[c].m_weight[Index.e] = -100 * (temp / total);
                            }
                            else
                            {
                                //float temp = (demMap[c] - demMap[e]) / 2;
                                outFlow[c].m_weight[Index.e] = (byte)(int)(100 * (temp / total));
                            }
                        }
                        // 东南(north east)
                        if (!noDataMap[se] && demMap[se] < demMap[c])
                        {
                            //ifcut = IsCutDirection(diagcellStep, demMap[c], demMap[se], demData, slopeAng[se]);
                            ifcut = IsCutDirection(slopeAng[c], slopeAng[se], demData);
                            temp = (demMap[c] - demMap[se]) / 4;
                            if (ifcut)
                            {
                                // outFlow[c].m_weight[Index.se] = OutFlow.NOOUT;
                                // Debug.WriteLine("A Cut point");
                                //float temp = (demMap[c] - demMap[se]) / 4;
                                outFlow[c].m_weight[Index.se] = (byte)(255 - (int)(100 * (temp / total)));
                                //outFlow[c].m_weight[Index.se] = -100 * (temp / total);
                            }
                            else
                            {
                                //float temp = (demMap[c] - demMap[se]) / 4;
                                outFlow[c].m_weight[Index.se] = (byte)(int)(100 * (temp / total));
                            }
                        }
                        // 南(south)
                        if (!noDataMap[s] && demMap[s] < demMap[c])
                        {
                            //ifcut = IsCutDirection(cellStep, demMap[c], demMap[s], demData, slopeAng[s]);
                            ifcut = IsCutDirection(slopeAng[c], slopeAng[s], demData);
                            temp = (demMap[c] - demMap[s]) / 2;
                            if (ifcut)
                            {
                                // outFlow[c].m_weight[Index.s] = OutFlow.NOOUT;
                                // Debug.WriteLine("A Cut point");
                                //float temp = (demMap[c] - demMap[s]) / 2;
                                outFlow[c].m_weight[Index.s] = (byte)(255 - (int)(100 * (temp / total)));
                                //outFlow[c].m_weight[Index.s] = -100 * (temp / total);
                            }
                            else
                            {
                                //float temp = (demMap[c] - demMap[s]) / 2;
                                outFlow[c].m_weight[Index.s] = (byte)(int)(100 * (temp / total));
                            }
                        }
                        // 西南(south west)
                        if (!noDataMap[sw] && demMap[sw] < demMap[c])
                        {
                            //ifcut = IsCutDirection(diagcellStep, demMap[c], demMap[sw], demData, slopeAng[sw]);
                            ifcut = IsCutDirection(slopeAng[c], slopeAng[sw], demData);
                            temp = (demMap[c] - demMap[sw]) / 4;
                            if (ifcut)
                            {
                                // outFlow[c].m_weight[Index.sw] = OutFlow.NOOUT;
                                // Debug.WriteLine("A Cut point");
                                //float temp = (demMap[c] - demMap[sw]) / 4;
                                outFlow[c].m_weight[Index.sw] = (byte)(255 - (int)(100 * (temp / total)));
                                //outFlow[c].m_weight[Index.sw] = -100 * (temp / total);
                            }
                            else
                            {
                                //float temp = (demMap[c] - demMap[sw]) / 4;
                                outFlow[c].m_weight[Index.sw] = (byte)(int)(100 * (temp / total));
                            }
                        }
                        // 西(west)
                        if (!noDataMap[w] && demMap[w] < demMap[c])
                        {
                            //ifcut = IsCutDirection(cellStep, demMap[c], demMap[w], demData, slopeAng[w]);
                            ifcut = IsCutDirection(slopeAng[c], slopeAng[w], demData);
                            temp = (demMap[c] - demMap[w]) / 2;
                            if (ifcut)
                            {
                                // outFlow[c].m_weight[Index.w] = OutFlow.NOOUT;
                                // Debug.WriteLine("A Cut point");
                                //float temp = (demMap[c] - demMap[w]) / 2;
                                outFlow[c].m_weight[Index.w] = (byte)(255 - (int)(100 * (temp / total)));
                                //outFlow[c].m_weight[Index.w] = -100 * (temp / total);
                            }
                            else
                            {
                                //float temp = (demMap[c] - demMap[w]) / 2;
                                outFlow[c].m_weight[Index.w] = (byte)(int)(100 * (temp / total));
                            }
                        }

                    }
                }
            }
        }
        //2011增加了河网过程中处理平坦区域的函数
        public void fixplatarea(int c, int cols)
        {

        }

        //张宏鸣增加河网提取2011.01.25提取河网主要的工作就是将截断加到已有的的权值数组中，使其在后续计算过程中直接使用

        public void CalcChannelNetworks(DemData dd, ref float[] Cumlen_ChannelNetworks,OutFlow[] outflow,bool[] nd)
        {
            int rows; // Number of rows.
            int cols; // Number of columns.
            int count = 0; //记录循环次数
            int hits = 0, hits1 = 0;
            int nw, n, ne, w, c, e, sw, s, se;
            //float inicumarea = 0.01f;//每个单元格的面积
            bool done = false;
            float cumarea;
            //double cellStep;
            //float diagcellStep;

            rows = dd.imagNrows;
            cols = dd.imagNcols;
            //cellStep = dd.cellStep;
            //diagcellStep = (float)Math.Sqrt(2.0) * dd.cellStep;

            double cellStep_step = dd.cellStep;
            double deg = (float)57.29577951308;
            double cellStep_std = 2 * Math.PI * GlobalConstants.earthR * cellStep_step / 360;//20140729

            //Console.WriteLine("{0}", cellStep_std);

            for (int i = 2; i < rows - 2; i++)
            {
                for (int j = 2; j < cols - 2; j++)
                {
                    c = i * cols + j;
                    if (nd[c])
                    {
                        Cumlen_ChannelNetworks[c] = 0.0f;
                        continue;
                    } //如果无值，跳出该次循环

                    //VertcellStep在北和南两个方向使用
                    float VertcellStep = (float)cellStep_std * (float)Math.Cos((dd.yllcorner + cellStep_step * (i - 2)) / deg);
                    Cumlen_ChannelNetworks[c] = VertcellStep * (float)cellStep_std;
                }
            }

            while (!done && count < 10000)
            {
                count++;
                done = true;
                hits = 0;
                for (int i = 2; i < rows - 2; i++)
                {
                    for (int j = 2; j < cols - 2; j++)
                    {
                        c = i * cols + j;
                        if (nd[c])
                        {
                            continue;
                        } //如果无值，跳出该次循环
                        nw = c - cols - 1;
                        n = c - cols;
                        ne = c - cols + 1;
                        w = c - 1;
                        e = c + 1;
                        sw = c + cols - 1;
                        s = c + cols;
                        se = c + cols + 1;
                        cumarea = 0.0f;
                        // 根据权值分配，然后累积
                        // 西
                        if (outflow[w].m_weight[Index.e] != OutFlow.NOOUT)
                        {
                            if (outflow[w].m_weight[Index.e] <= 100)
                                cumarea += ((float)(outflow[w].m_weight[Index.e] * Cumlen_ChannelNetworks[w])) / 100;
                            else
                                cumarea += ((float)((OutFlow.NOOUT - outflow[w].m_weight[Index.e]) * Cumlen_ChannelNetworks[w])) / 100;
                        }
                        // 西北
                        if (outflow[nw].m_weight[Index.se] != OutFlow.NOOUT)
                        {
                            if (outflow[nw].m_weight[Index.se] <= 100)
                                cumarea += ((float)(outflow[nw].m_weight[Index.se] * Cumlen_ChannelNetworks[nw])) / 100;
                            else
                                cumarea += ((float)((OutFlow.NOOUT - outflow[nw].m_weight[Index.se]) * Cumlen_ChannelNetworks[nw])) / 100;
                        }
                        // 北
                        if (outflow[n].m_weight[Index.s] != OutFlow.NOOUT)
                        {
                            if (outflow[n].m_weight[Index.s] <= 100)
                                cumarea += ((float)(outflow[n].m_weight[Index.s] * Cumlen_ChannelNetworks[n])) / 100;
                            else
                                cumarea += ((float)((OutFlow.NOOUT - outflow[n].m_weight[Index.s]) * Cumlen_ChannelNetworks[n])) / 100;

                        }
                        // 东北
                        if (outflow[ne].m_weight[Index.sw] != OutFlow.NOOUT)
                        {
                            if (outflow[ne].m_weight[Index.sw] <= 100)
                                cumarea += ((float)(outflow[ne].m_weight[Index.sw] * Cumlen_ChannelNetworks[ne])) / 100;
                            else
                                cumarea += ((float)((OutFlow.NOOUT - outflow[ne].m_weight[Index.sw]) * Cumlen_ChannelNetworks[ne])) / 100;
                        }
                        // 东
                        if (outflow[e].m_weight[Index.w] != OutFlow.NOOUT)
                        {
                            if (outflow[e].m_weight[Index.w] <= 100)
                                cumarea += (float)(outflow[e].m_weight[Index.w] * Cumlen_ChannelNetworks[e]) / 100;
                            else
                                cumarea += (float)((OutFlow.NOOUT - outflow[e].m_weight[Index.w]) * Cumlen_ChannelNetworks[e]) / 100;
                        }
                        // 东南
                        if (outflow[se].m_weight[Index.nw] != OutFlow.NOOUT)
                        {
                            if (outflow[se].m_weight[Index.nw] <= 100)
                                cumarea += (float)(outflow[se].m_weight[Index.nw] * Cumlen_ChannelNetworks[se]) / 100;
                            else
                                cumarea += (float)((OutFlow.NOOUT - outflow[se].m_weight[Index.nw]) * Cumlen_ChannelNetworks[se]) / 100;
                        }
                        // 南
                        if (outflow[s].m_weight[Index.n] != OutFlow.NOOUT)
                        {
                            if (outflow[s].m_weight[Index.n] <= 100)
                                cumarea += (float)(outflow[s].m_weight[Index.n] * Cumlen_ChannelNetworks[s]) / 100;
                            else
                                cumarea += (float)((OutFlow.NOOUT - outflow[s].m_weight[Index.n]) * Cumlen_ChannelNetworks[s]) / 100;
                        }
                        // 西南
                        if (outflow[sw].m_weight[Index.ne] != OutFlow.NOOUT)
                        {
                            if (outflow[sw].m_weight[Index.ne] <= 100)
                                cumarea += (float)(outflow[sw].m_weight[Index.ne] * Cumlen_ChannelNetworks[sw]) / 100;
                            else
                                cumarea += (float)((OutFlow.NOOUT - outflow[sw].m_weight[Index.ne]) * Cumlen_ChannelNetworks[sw]) / 100;
                        }
                        if (cumarea > 0.0)
                        {
                            float VertcellStep = (float)cellStep_std * (float)Math.Cos((dd.yllcorner + cellStep_step * (i - 2)) / deg);
                            cumarea += VertcellStep * (float)cellStep_std;
                            if (cumarea > Cumlen_ChannelNetworks[c])
                            {
                                hits++;
                                done = false;
                                Cumlen_ChannelNetworks[c] = cumarea;
                            }
                        }
                    }
                }

                if (hits == hits1)
                    count = 10000;
                hits1 = hits;
                hits = 0;
                // 逆向计算
                for (int i = rows - 3; i >= 2; i--)
                {
                    // SECOND PART
                    for (int j = cols - 3; j >= 2; j--)
                    {
                        c = i * cols + j;
                        if (nd[c])
                        {
                            continue;
                        } //如果无值，跳出该次循环
                        nw = c - cols - 1;
                        n = c - cols;
                        ne = c - cols + 1;
                        w = c - 1;
                        e = c + 1;
                        sw = c + cols - 1;
                        s = c + cols;
                        se = c + cols + 1;
                        cumarea = 0.0f;
                        // 根据权值分配，然后累积
                        // 西
                        if (outflow[w].m_weight[Index.e] != OutFlow.NOOUT)
                        {
                            if (outflow[w].m_weight[Index.e] <= 100)
                                cumarea += ((float)(outflow[w].m_weight[Index.e] * Cumlen_ChannelNetworks[w])) / 100;
                            else
                                cumarea += ((float)((OutFlow.NOOUT - outflow[w].m_weight[Index.e]) * Cumlen_ChannelNetworks[w])) / 100;
                        }
                        // 西北
                        if (outflow[nw].m_weight[Index.se] != OutFlow.NOOUT)
                        {
                            if (outflow[nw].m_weight[Index.se] <= 100)
                                cumarea += ((float)(outflow[nw].m_weight[Index.se] * Cumlen_ChannelNetworks[nw])) / 100;
                            else
                                cumarea += ((float)((OutFlow.NOOUT - outflow[nw].m_weight[Index.se]) * Cumlen_ChannelNetworks[nw])) / 100;
                        }
                        // 北
                        if (outflow[n].m_weight[Index.s] != OutFlow.NOOUT)
                        {
                            if (outflow[n].m_weight[Index.s] <= 100)
                                cumarea += ((float)(outflow[n].m_weight[Index.s] * Cumlen_ChannelNetworks[n])) / 100;
                            else
                                cumarea += ((float)((OutFlow.NOOUT - outflow[n].m_weight[Index.s]) * Cumlen_ChannelNetworks[n])) / 100;

                        }
                        // 东北
                        if (outflow[ne].m_weight[Index.sw] != OutFlow.NOOUT)
                        {
                            if (outflow[ne].m_weight[Index.sw] <= 100)
                                cumarea += ((float)(outflow[ne].m_weight[Index.sw] * Cumlen_ChannelNetworks[ne])) / 100;
                            else
                                cumarea += ((float)((OutFlow.NOOUT - outflow[ne].m_weight[Index.sw]) * Cumlen_ChannelNetworks[ne])) / 100;
                        }
                        // 东
                        if (outflow[e].m_weight[Index.w] != OutFlow.NOOUT)
                        {
                            if (outflow[e].m_weight[Index.w] <= 100)
                                cumarea += (float)(outflow[e].m_weight[Index.w] * Cumlen_ChannelNetworks[e]) / 100;
                            else
                                cumarea += (float)((OutFlow.NOOUT - outflow[e].m_weight[Index.w]) * Cumlen_ChannelNetworks[e]) / 100;
                        }
                        // 东南
                        if (outflow[se].m_weight[Index.nw] != OutFlow.NOOUT)
                        {
                            if (outflow[se].m_weight[Index.nw] <= 100)
                                cumarea += (float)(outflow[se].m_weight[Index.nw] * Cumlen_ChannelNetworks[se]) / 100;
                            else
                                cumarea += (float)((OutFlow.NOOUT - outflow[se].m_weight[Index.nw]) * Cumlen_ChannelNetworks[se]) / 100;
                        }
                        // 南
                        if (outflow[s].m_weight[Index.n] != OutFlow.NOOUT)
                        {
                            if (outflow[s].m_weight[Index.n] <= 100)
                                cumarea += (float)(outflow[s].m_weight[Index.n] * Cumlen_ChannelNetworks[s]) / 100;
                            else
                                cumarea += (float)((OutFlow.NOOUT - outflow[s].m_weight[Index.n]) * Cumlen_ChannelNetworks[s]) / 100;
                        }
                        // 西南
                        if (outflow[sw].m_weight[Index.ne] != OutFlow.NOOUT)
                        {
                            if (outflow[sw].m_weight[Index.ne] <= 100)
                                cumarea += (float)(outflow[sw].m_weight[Index.ne] * Cumlen_ChannelNetworks[sw]) / 100;
                            else
                                cumarea += (float)((OutFlow.NOOUT - outflow[sw].m_weight[Index.ne]) * Cumlen_ChannelNetworks[sw]) / 100;
                        }
                        if (cumarea > 0.0)
                        {
                            float VertcellStep = (float)cellStep_std * (float)Math.Cos((dd.yllcorner + cellStep_step * (i - 2)) / deg);
                            cumarea += VertcellStep * (float)cellStep_std;
                            if (cumarea > Cumlen_ChannelNetworks[c])
                            {
                                hits++;
                                done = false;
                                Cumlen_ChannelNetworks[c] = cumarea;
                            }
                        }
                    }
                }
            }
            LogCumulativeProgress(count, hits1, hits);
        }
        //20110126张宏鸣增加河网提取后直接修改权值文件，使河网的部分完全体现在权值文件中，省下内存空间
        public void RedownWeight(DemData demData, float threshold, float[] Cumlen_ChannelNetworks, ref OutFlow[] outflow, bool[] nd)
        {

            int rows = demData.imagNrows;
            int cols = demData.imagNcols;
            int nw, n, ne, w, c, e, sw, s, se;
            //threshold = (threshold / 100) / (demData.cellStep * demData.cellStep);//annotated in 20140729
            //在计算汇流时，默认每个单元格为0.01平方米，此处进行转换，threshold变为到底是几个单元格为阈值
            for (int i = 2; i < rows - 2; i++)
            {
                for (int j = 2; j < cols - 2; j++)
                {
                    c = i * cols + j;
                    if (nd[c])
                    {
                        //Cumlen_ChannelNetworks[c] = 0.0f;
                        continue;
                    } //如果无值，跳出该次循环
                    nw = c - cols - 1;
                    n = c - cols;
                    ne = c - cols + 1;
                    w = c - 1;
                    e = c + 1;
                    sw = c + cols - 1;
                    s = c + cols;
                    se = c + cols + 1;
                    //outflow[c] = inicumarea;
                    //西
                    if (outflow[e].m_weight[Index.w] != OutFlow.NOOUT && outflow[e].m_weight[Index.w] <= 100 && Cumlen_ChannelNetworks[c] >= threshold)
                    {
                        outflow[e].m_weight[Index.w] = (byte)(OutFlow.NOOUT - outflow[e].m_weight[Index.w]);
                    }
                    // 西北
                    if (outflow[se].m_weight[Index.nw] != OutFlow.NOOUT && outflow[se].m_weight[Index.nw] <= 100 && Cumlen_ChannelNetworks[c] >= threshold)
                    {
                        outflow[se].m_weight[Index.nw] = (byte)(OutFlow.NOOUT - outflow[se].m_weight[Index.nw]);
                    }
                    // 北
                    if (outflow[s].m_weight[Index.n] != OutFlow.NOOUT && outflow[s].m_weight[Index.n] <= 100 && Cumlen_ChannelNetworks[c] >= threshold)
                    {
                        outflow[s].m_weight[Index.n] = (byte)(OutFlow.NOOUT - outflow[s].m_weight[Index.n]);
                    }
                    // 东北
                    if (outflow[sw].m_weight[Index.ne] != OutFlow.NOOUT && outflow[sw].m_weight[Index.ne] <= 100 && Cumlen_ChannelNetworks[c] >= threshold)
                    {
                        outflow[sw].m_weight[Index.ne] = (byte)(OutFlow.NOOUT - outflow[sw].m_weight[Index.ne]);
                    }
                    // 东
                    if (outflow[w].m_weight[Index.e] != OutFlow.NOOUT && outflow[w].m_weight[Index.e] <= 100 && Cumlen_ChannelNetworks[c] >= threshold)
                    {
                        outflow[w].m_weight[Index.e] = (byte)(OutFlow.NOOUT - outflow[w].m_weight[Index.e]);
                    }
                    // 东南
                    if (outflow[nw].m_weight[Index.se] != OutFlow.NOOUT && outflow[nw].m_weight[Index.se] <= 100 && Cumlen_ChannelNetworks[c] >= threshold)
                    {
                        outflow[nw].m_weight[Index.se] = (byte)(OutFlow.NOOUT - outflow[nw].m_weight[Index.se]);
                    }
                    // 南
                    if (outflow[n].m_weight[Index.s] != OutFlow.NOOUT && outflow[n].m_weight[Index.s] <= 100 && Cumlen_ChannelNetworks[c] >= threshold)
                    {
                        outflow[n].m_weight[Index.s] = (byte)(OutFlow.NOOUT - outflow[n].m_weight[Index.s]);
                    }
                    // 西南
                    if (outflow[ne].m_weight[Index.sw] != OutFlow.NOOUT && outflow[ne].m_weight[Index.sw] <= 100 && Cumlen_ChannelNetworks[c] >= threshold)
                    {
                        outflow[ne].m_weight[Index.sw] = (byte)(OutFlow.NOOUT - outflow[ne].m_weight[Index.sw]);
                    }
                }
            }
        }



        /* zhangjie,2010.06.20
         * zhangjie,2010.07.03修改
         * 判断多流向截断方向
         */
        public bool IsCutDirection(float cell, float centerDEM,float otherDEM,DemData demData,float otherAng)
        {
            float deg = (float)57.29577951308;
            // 计算坡度
            float angle = deg * (float)Math.Atan((centerDEM - otherDEM) / cell);
            float slpEndFactor = angle < 2.8624 ? demData.scf_lt5 : demData.scf_ge5;
            bool ifcut = otherAng < angle * slpEndFactor;
            return ifcut;
        }
        //张宏鸣20140326 用曲面坡测试发现上一个截断判断方法没有效果（单流向算法明显截断），故进行了修改
        public bool IsCutDirection(float slopeAng,float otherAng,DemData demData)
        {
            //float deg = (float)57.29577951308;
            //// 计算坡度
            //float angle = deg * (float)Math.Atan((centerDEM - otherDEM) / cell);
            //float slpEndFactor = angle < 2.8624 ? demData.scf_lt5 : demData.scf_ge5;
            //bool ifcut = otherAng < angle * slpEndFactor;
            //return ifcut;
            float slpEndFactor = slopeAng < 2.8624 ? demData.scf_lt5 : demData.scf_ge5;
            bool ifcut = otherAng < slopeAng * slpEndFactor;
            return ifcut;
        }
        
        

        public void SetInFlowByWeigth(DemData dd, ref bool[] noDataMap, ref OutFlow[] outFlow, ref byte[] inMap)
        {

            int rows; // Number of rows.
            int cols; // Number of columns.
            int nw, n, ne, w, c, e, sw, s, se;
            rows = dd.imagNrows;
            cols = dd.imagNcols;
            for (int i = 2; i < rows - 2; i++)
            {
                for (int j = 2; j < cols - 2; j++)
                {
                    c = i * cols + j;
                    inMap[c] = 0;
                    if (noDataMap[c])
                    {
                        continue;
                    }
                    nw = c - cols - 1;
                    n = c - cols;
                    ne = c - cols + 1;
                    w = c - 1;
                    e = c + 1;
                    sw = c + cols - 1;
                    s = c + cols;
                    se = c + cols + 1;
                    //2010.08.14只要有一个方向截断就出现全部断点
                    //西北
                    //if (outFlow[nw].m_weight[Index.se] <= (byte)100 && outFlow[nw].m_weight[Index.se] >= (byte)0)
                    //{
                    //    inMap[c] += GlobalConstants.NW;
                    //}
                    //else if(outFlow[nw].m_weight[Index.se] != OutFlow.NOOUT)
                    //{
                    //    inMap[c] = 0;
                    //    continue;
                    //}
                    ////北
                    //if (outFlow[n].m_weight[Index.s] <= (byte)100 && outFlow[n].m_weight[Index.s] >= (byte)0)
                    //{
                    //    inMap[c] += GlobalConstants.N;
                    //}
                    //else if (outFlow[n].m_weight[Index.s]!=OutFlow.NOOUT)
                    //{
                    //    inMap[c] = 0;
                    //    continue;
                    //}
                    ////东北
                    //if (outFlow[ne].m_weight[Index.sw] <= (byte)100 && outFlow[ne].m_weight[Index.sw] >= (byte)0)
                    //{
                    //    inMap[c] += GlobalConstants.NE;
                    //}
                    //else if (outFlow[ne].m_weight[Index.sw] != OutFlow.NOOUT)
                    //{
                    //    inMap[c] = 0;
                    //    continue;
                    //}
                    ////东
                    //if (outFlow[e].m_weight[Index.w] <= (byte)100 && outFlow[e].m_weight[Index.w] >= (byte)0)
                    //{
                    //    inMap[c] += GlobalConstants.E;
                    //}
                    //else if (outFlow[e].m_weight[Index.w] != OutFlow.NOOUT)
                    //{
                    //    inMap[c] = 0;
                    //    continue;
                    //}
                    ////东南
                    //if (outFlow[se].m_weight[Index.nw] <= (byte)100 && outFlow[se].m_weight[Index.nw] >= (byte)0)
                    //{
                    //    inMap[c] += GlobalConstants.SE;
                    //}
                    //else if (outFlow[se].m_weight[Index.nw] != OutFlow.NOOUT)
                    //{
                    //    inMap[c] = 0;
                    //    continue;
                    //}
                    ////南
                    //if (outFlow[s].m_weight[Index.n] <= (byte)100 && outFlow[s].m_weight[Index.n] >= (byte)0)
                    //{   
                    //    inMap[c] += GlobalConstants.S;
                    //}
                    //else if (outFlow[s].m_weight[Index.n] != OutFlow.NOOUT)
                    //{
                    //    inMap[c] = 0;
                    //    continue;
                    //}
                    ////西南
                    //if (outFlow[sw].m_weight[Index.ne] <= (byte)100 && outFlow[sw].m_weight[Index.ne] >= (byte)0)
                    //{
                    //    inMap[c] += GlobalConstants.SW;
                    //}
                    //else if (outFlow[sw].m_weight[Index.ne] != OutFlow.NOOUT)
                    //{
                    //    inMap[c] = 0;
                    //    continue;
                    //}
                    ////西
                    //if (outFlow[w].m_weight[Index.e] <= (byte)100 && outFlow[w].m_weight[Index.e] >= (byte)0)
                    //{
                    //    inMap[c] += GlobalConstants.W;
                    //}
                    //else if (outFlow[w].m_weight[Index.e] != OutFlow.NOOUT)
                    //{
                    //    inMap[c] = 0;
                    //    continue;
                    //}
                    //西北
                    if (outFlow[nw].m_weight[Index.se] <= (byte)100 && outFlow[nw].m_weight[Index.se] > (byte)0)
                        inMap[c] += GlobalConstants.NW;
                    //北
                    if (outFlow[n].m_weight[Index.s] <= (byte)100 && outFlow[n].m_weight[Index.s] > (byte)0)
                        inMap[c] += GlobalConstants.N;
                    //东北
                    if (outFlow[ne].m_weight[Index.sw] <= (byte)100 && outFlow[ne].m_weight[Index.sw] > (byte)0)
                        inMap[c] += GlobalConstants.NE;
                    //东
                    if (outFlow[e].m_weight[Index.w] <= (byte)100 && outFlow[e].m_weight[Index.w] > (byte)0)
                        inMap[c] += GlobalConstants.E;
                    //东南
                    if (outFlow[se].m_weight[Index.nw] <= (byte)100 && outFlow[se].m_weight[Index.nw] > (byte)0)
                        inMap[c] += GlobalConstants.SE;
                    //南
                    if (outFlow[s].m_weight[Index.n] <= (byte)100 && outFlow[s].m_weight[Index.n] > (byte)0)
                        inMap[c] += GlobalConstants.S;
                    //西南
                    if (outFlow[sw].m_weight[Index.ne] <= (byte)100 && outFlow[sw].m_weight[Index.ne] > (byte)0)
                        inMap[c] += GlobalConstants.SW;
                    //西
                    if (outFlow[w].m_weight[Index.e] <= (byte)100 && outFlow[w].m_weight[Index.e] > (byte)0)
                        inMap[c] += GlobalConstants.W;
                }
            }
        }


        public void InitCumulativeLength(DemData dd, float[] demMap, bool[] noDataMap,ref float[] cumlen,ref float[] inicumlen ,byte[] inFlow,bool flowcut)
        {
            int i; //  Loop Counter.
            int j; //  Loop Counter.
            int c; //  Cell Index value  
            int rows; //  Number of rows.
            int cols; //  Number of columns. 
            double cellorth; //  Width of cell in cardinal direction
            rows = dd.imagNrows;
            cols = dd.imagNcols;
            float deg = (float)57.29577951308;

            cellorth = dd.cellStep; //单元格长度
            double cellStep = dd.cellStep;
            int nw, n, ne, w, e, sw, s, se;
            float A = 0;
            float z1, z2, z3, z4, z5, z6, z7, z8, z9;
            float fx;
            float fy;

            double cellStep_step = dd.cellStep;
            deg = (float)57.29577951308;
            double cellStep_std = 2 * Math.PI * GlobalConstants.earthR * cellStep_step / 360;//20140726
            float cellStepY;

            for (i = 2; i < rows - 2; i++)
            {
                for (j = 2; j < cols - 2; j++)
                {

                    c = i * cols + j;
                    cumlen[c] = (float)0.0;
                    if (noDataMap[c] == true)
                    {
                        continue;
                    }
                    nw = c - cols - 1;
                    n = c - cols;
                    ne = c - cols + 1;
                    w = c - 1;
                    e = c + 1;
                    sw = c + cols - 1;
                    s = c + cols;
                    se = c + cols + 1;

                    // 数值初始化
                    z1 = demMap[c];
                    z1 = z2 = z3 = z4 = z5 = z6 = z7 = z8 = z9 = demMap[c];
                    fx = fy = 0.0f;
                    //西(west)
                    if (noDataMap[w] == false)
                    {
                        z4 = demMap[w];
                    }
                    //西北(north west)
                    if (noDataMap[nw] == false)
                    {
                        z7 = demMap[nw];
                    }
                    //北(north)
                    if (noDataMap[n] == false)
                    {
                        z8 = demMap[n];
                    }
                    // 东北(north east)
                    if (noDataMap[ne] == false)
                    {
                        z9 = demMap[ne];
                    }
                    // 东(east)
                    if (noDataMap[e] == false)
                    {
                        z6 = demMap[e];
                    }
                    // 东南(south east)
                    if (noDataMap[se] == false)
                    {
                        z3 = demMap[se];
                    }
                    // 南(south)
                    if (noDataMap[s] == false)
                    {
                        z2 = demMap[s];
                    }
                    // 西南(south west)
                    if (noDataMap[sw] == false)
                    {
                        z1 = demMap[sw];
                    }
                    //fx = (z7 - z1 + z8 - z2 + z9 - z3) / (6 * cellStep);
                    //fy = (z3 - z1 + z6 - z4 + z9 - z7) / (6 * cellStep);
                    //改于2010.08.13
                    //fx = (z7 - z1 + 2 * (z8 - z2) + z9 - z3) / (8 * cellStep);
                    //fy = (z3 - z1 + 2 * (z6 - z4) + z9 - z7) / (8 * cellStep);

                    //added by WangShuai 20140727
                    cellStepY = (float)cellStep_std * (float)Math.Cos((dd.yllcorner + cellStep_step * (i - 2)) / deg);


                    fx = (z7 - z1 + 2 * (z8 - z2) + z9 - z3) / (8 * (float)cellStep_std);
                    fy = (z3 - z1 + 2 * (z6 - z4) + z9 - z7) / (8 * cellStepY);

                    if (fx == 0.0f)
                    {

                        if (flowcut)
                        {
                            if (inFlow[c] == 0)
                            {
                                cumlen[c] = cellStepY / 2;
                            }
                            else
                            {
                                cumlen[c] = cellStepY;
                            }
                        }
                        else
                        {
                            cumlen[c] = cellStepY;
                        }
                        inicumlen[c] = cumlen[c];
                    }
                    else
                    {

                        // A = 270°+ arctan ( fy / fx ) - 90°fx / |fx|
                        A = 270 + deg * (float)Math.Atan(fy / fx) - 90 * (fx / Math.Abs(fx)); // A代表坡向

                        //while (true)
                        //{
                        //    if (A > 360)
                        //    {
                        //        A = A - 360; // 这种情况应该没有
                        //    }
                        //    else
                        //        break;
                        //else
                        //{
                        //    if (A >= 315)
                        //        A = A;
                        //    else if (A >= 225)
                        //        A = Math.Abs(270 - A);
                        //    else if (A >= 135)
                        //        A = A;
                        //    else if (A >= 45)
                        //        A = Math.Abs(90 - A);
                        //    break;
                        //}20110629去掉改后面为sin+cos
                        //}

                        /*if (A > 45 && A < 135 || A > 225 && A < 315)
                        {
                            Debug.WriteLine("A = " + A);
                        }
                        if ((float)Math.Abs(Math.Cos(Math.PI * A / 180.0)) < 0.7)
                        {
                            Debug.WriteLine("cos(a) = " + (float)Math.Abs(Math.Cos(Math.PI * A / 180.0)));
                        }*/
                        //20110629去掉，改为sin+cos
                        //cumlen[c] = cellStep / (float)Math.Abs(Math.Cos(Math.PI * A / 180.0));

                        cumlen[c] = (float)cellStep_std * ((float)Math.Abs(Math.Cos(Math.PI * A / 180.0)) + (float)Math.Abs(Math.Sin(Math.PI * A / 180.0)));

                        //added by WangShuai 20140727
                        //cumlen[c] = (float)Math.Abs(cellStepY / (float)Math.Abs(Math.Sin(Math.PI * A / 180.0)));

                        if (flowcut)//如果截断
                        {
                            if (inFlow[c] == 0)
                            {
                                cumlen[c] = cumlen[c] / 2;
                            }
                        }
                        inicumlen[c] = cumlen[c];
                        //}
                        //else//没有截断
                        //{
                        //    inicumlen[c] = cumlen[c];
                        //}

                    }
                }
            }
        }
        //累积最大值
        //public void CalcCumulativeLength(DemData dd, OutFlow[] outflow, bool[] nd, ref float[] cumlen, float[] inicumlen)
        //{
        //    int rows; // Number of rows.
        //    int cols; // Number of columns.
        //    int count = 0; //记录循环次数
        //    int hits = 0, hits1 = 0;
        //    int nw, n, ne, w, c, e, sw, s, se;
        //    bool done = false;
        //    float cumlength;
        //    float maxlength;//用于记录周围最大坡长
        //    float currentlength;//用于记录当前方向上的坡长
        //    double cellStep;
        //    float diagcellStep;

        //    rows = dd.imagNrows;
        //    cols = dd.imagNcols;
        //    cellStep = dd.cellStep;
        //    diagcellStep = (float)Math.Sqrt(2.0) * dd.cellStep;
        //    int fixnum = (int)(dd.imagNrows - 2) * (dd.imagNcols) /1000;
        //    float[] array_fix = new float[fixnum];
        //    //float setmax = 0;
        //    float setmin = dd.cellStep;
        //    //float classify_num = 10;
        //    while (!done && count < 10000)
        //    {
        //        count++;
        //        done = true;
        //        hits = 0;   
        //        for (int i = 2; i < rows - 2; i++)
        //        {
        //            for (int j = 2; j < cols - 2; j++)
        //            {
        //                c = i * cols + j;
        //                if (nd[c])
        //                {
        //                    continue;
        //                } //如果无值，跳出该次循环
        //                nw = c - cols - 1;
        //                n = c - cols;
        //                ne = c - cols + 1;
        //                w = c - 1;
        //                e = c + 1;
        //                sw = c + cols - 1;
        //                s = c + cols;
        //                se = c + cols + 1;
        //                cumlength = 0.0f;
        //                maxlength = 0.0f;
        //                currentlength = 0.0f;
        //                // 根据权值分配，然后累积
        //                // 西
        //                //if (i == 125)
        //                //{
        //                //   MessageBox.Show(j.ToString());
        //                //}
        //                if (outflow[w].m_weight[Index.e] != OutFlow.NOOUT
        //                    && outflow[w].m_weight[Index.e] <= (byte)100 && outflow[w].m_weight[Index.e] > (byte)0)
        //                    {
        //                        currentlength= ((float)(outflow[w].m_weight[Index.e] * cumlen[w])) / 100;
        //                        cumlength += currentlength;
        //                        if (maxlength < currentlength)
        //                        {
        //                            maxlength = currentlength;
        //                        }
        //                    }
        //                    //else
        //                    //{
        //                    //    cumlength -= ((float)((255-outflow[w].m_weight[Index.e]) * cumlen[w])) / 100;
        //                    //}
        //                // 西北
        //                if (outflow[nw].m_weight[Index.se] != OutFlow.NOOUT
        //                    && outflow[nw].m_weight[Index.se] <= (byte)100 && outflow[nw].m_weight[Index.se] > (byte)0)
        //                {
        //                    currentlength = ((float)(outflow[nw].m_weight[Index.se] * cumlen[nw])) / 100;
        //                    cumlength += currentlength;
        //                    if (maxlength < currentlength)
        //                    {
        //                        maxlength = currentlength;
        //                    }
        //                }
        //                // 北
        //                if (outflow[n].m_weight[Index.s] != OutFlow.NOOUT
        //                     && outflow[n].m_weight[Index.s] <= (byte)100 && outflow[n].m_weight[Index.s] > (byte)0)
        //                {
        //                    currentlength = ((float)(outflow[n].m_weight[Index.s] * cumlen[n])) / 100;
        //                    cumlength += currentlength;
        //                    if (maxlength < currentlength)
        //                    {
        //                        maxlength = currentlength;
        //                    }
        //                }
        //                // 东北
        //                if (outflow[ne].m_weight[Index.sw] != OutFlow.NOOUT
        //                     && outflow[ne].m_weight[Index.sw] <= (byte)100 && outflow[ne].m_weight[Index.sw] > (byte)0)
        //                {
        //                    currentlength = ((float)(outflow[ne].m_weight[Index.sw] * cumlen[ne])) / 100;
        //                    cumlength += currentlength;
        //                    if (maxlength < currentlength)
        //                    {
        //                        maxlength = currentlength;
        //                    }
        //                }
        //                // 东
        //                if (outflow[e].m_weight[Index.w] != OutFlow.NOOUT
        //                    && outflow[e].m_weight[Index.w] <= (byte)100 && outflow[e].m_weight[Index.w] > (byte)0)
        //                {
        //                    currentlength = (float)(outflow[e].m_weight[Index.w] * cumlen[e]) / 100;
        //                    cumlength += currentlength;
        //                    if (maxlength < currentlength)
        //                    {
        //                        maxlength = currentlength;
        //                    }
        //                }
        //                // 东南
        //                if (outflow[se].m_weight[Index.nw] != OutFlow.NOOUT
        //                    && outflow[se].m_weight[Index.nw] <= (byte)100 && outflow[se].m_weight[Index.nw] > (byte)0)
        //                {
        //                    currentlength = (float)(outflow[se].m_weight[Index.nw] * cumlen[se]) / 100;
        //                    cumlength += currentlength;
        //                    if (maxlength < currentlength)
        //                    {
        //                        maxlength = currentlength;
        //                    }
        //                }
        //                // 南
        //                if (outflow[s].m_weight[Index.n] != OutFlow.NOOUT
        //                    && outflow[s].m_weight[Index.n] <= (byte)100 && outflow[s].m_weight[Index.n] > (byte)0)
        //                {
        //                    currentlength = (float)(outflow[s].m_weight[Index.n] * cumlen[s]) / 100;
        //                    cumlength += currentlength;
        //                    if (maxlength < currentlength)
        //                    {
        //                        maxlength = currentlength;
        //                    }
        //                }
        //                // 西南
        //                if (outflow[sw].m_weight[Index.ne] != OutFlow.NOOUT
        //                    && outflow[sw].m_weight[Index.ne] <= (byte)100 && outflow[sw].m_weight[Index.ne] > (byte)0)
        //                {
        //                    currentlength = (float)(outflow[sw].m_weight[Index.ne] * cumlen[sw]) / 100;
        //                    cumlength += currentlength;
        //                    if (maxlength < currentlength)
        //                    {
        //                        maxlength = currentlength;
        //                    }
        //                }
        //                if (cumlength > 0.0)
        //                { 
        //                    // 这里值得探讨
        //                    //2010.08.13删除张宏鸣
        //                    //float cum = 0.0f;
        //                    //for (int k = 0; k < 8; k++)
        //                    //{
        //                    //    if (outflow[c].m_weight[k] != OutFlow.NOOUT)
        //                    //    {
        //                    //        if (k % 2 == 0)                                  
        //                    //            // 对角线方向
        //                    //            cum += (float)(diagcellStep * outflow[c].m_weight[k])/100;                                  
        //                    //        else 
        //                    //            cum += (float)(cellStep * outflow[c].m_weight[k])/100;                                   
        //                    //    }
        //                    //}
        //                    if (cumlength > maxlength)
        //                    {
        //                        cumlength = maxlength + inicumlen[c];
        //                    }
        //                    else
        //                    {
        //                        cumlength += inicumlen[c];
        //                    }
        //                    if (cumlength > cumlen[c])
        //                    {
        //                        hits++;
        //                        done = false;
        //                        cumlen[c] = cumlength;
        //                    }                            
        //                }// if
        //                //找到最大值
        //                //if (cumlen[c] > setmax)
        //                //{
        //                //    setmax = cumlen[c];
        //                //}
        //                //if (cumlen[c] < setmin)
        //                //{
        //                //    setmin = cumlen[c];
        //                //}
        //            }
        //        }// for

        //        if (hits == hits1)
        //            count = 10000;
        //        hits1 = hits;
        //        hits = 0;
        //        // 逆向计算
        //        for (int i = rows - 3; i >= 2; i--)
        //        {
        //            // SECOND PART
        //            for (int j = cols - 3; j >= 2; j--)
        //            {
        //                c = i * cols + j;
        //                if (nd[c])
        //                {
        //                    continue;
        //                } //如果无值，跳出该次循环
        //                nw = c - cols - 1;
        //                n = c - cols;
        //                ne = c - cols + 1;
        //                w = c - 1;
        //                e = c + 1;
        //                sw = c + cols - 1;
        //                s = c + cols;
        //                se = c + cols + 1;
        //                cumlength = 0.0f;
        //                maxlength = 0.0f;
        //                currentlength = 0.0f;
        //                // 根据权值分配，然后累积
        //                // 西
        //                if (outflow[w].m_weight[Index.e] != OutFlow.NOOUT
        //                    && outflow[w].m_weight[Index.e] <= (byte)100 && outflow[w].m_weight[Index.e] > (byte)0)
        //                {
        //                    currentlength = (float)(outflow[w].m_weight[Index.e] * cumlen[w]) / 100;
        //                    cumlength += currentlength;
        //                    if (maxlength < currentlength)
        //                    {
        //                        maxlength = currentlength;
        //                    }
        //                }
        //                // 西北
        //                if (outflow[nw].m_weight[Index.se] != OutFlow.NOOUT
        //                    && outflow[nw].m_weight[Index.se] <= (byte)100 && outflow[nw].m_weight[Index.se] > (byte)0)
        //                {
        //                    currentlength = (float)(outflow[nw].m_weight[Index.se] * cumlen[nw]) / 100;
        //                    cumlength += currentlength;
        //                    if (maxlength < currentlength)
        //                    {
        //                        maxlength = currentlength;
        //                    }
        //                }
        //                // 北
        //                if (outflow[n].m_weight[Index.s] != OutFlow.NOOUT
        //                    && outflow[n].m_weight[Index.s] <= (byte)100 && outflow[n].m_weight[Index.s] > (byte)0)
        //                {
        //                    currentlength = (float)(outflow[n].m_weight[Index.s] * cumlen[n]) / 100;
        //                    cumlength += currentlength;
        //                    if (maxlength < currentlength)
        //                    {
        //                        maxlength = currentlength;
        //                    }
        //                }
        //                // 东北
        //                if (outflow[ne].m_weight[Index.sw] != OutFlow.NOOUT
        //                    && outflow[ne].m_weight[Index.sw] <= (byte)100 && outflow[ne].m_weight[Index.sw] > (byte)0)
        //                {
        //                    currentlength = (float)(outflow[ne].m_weight[Index.sw] * cumlen[ne]) / 100;
        //                    cumlength += currentlength;
        //                    if (maxlength < currentlength)
        //                    {
        //                        maxlength = currentlength;
        //                    }
        //                }
        //                // 东
        //                if (outflow[e].m_weight[Index.w] != OutFlow.NOOUT
        //                    && outflow[e].m_weight[Index.w] <= (byte)100 && outflow[e].m_weight[Index.w] > (byte)0)
        //                {
        //                    currentlength = (float)(outflow[e].m_weight[Index.w] * cumlen[e]) / 100; cumlength += currentlength;
        //                    if (maxlength < currentlength)
        //                    {
        //                        maxlength = currentlength;
        //                    }
        //                }
        //                // 东南
        //                if (outflow[se].m_weight[Index.nw] != OutFlow.NOOUT
        //                    && outflow[se].m_weight[Index.nw] <= (byte)100 && outflow[se].m_weight[Index.nw] > (byte)0)
        //                {
        //                    currentlength = (float)(outflow[se].m_weight[Index.nw] * cumlen[se]) / 100;
        //                    cumlength += currentlength;
        //                    if (maxlength < currentlength)
        //                    {
        //                        maxlength = currentlength;
        //                    }
        //                }
        //                // 南
        //                if (outflow[s].m_weight[Index.n] != OutFlow.NOOUT
        //                    && outflow[s].m_weight[Index.n] <= (byte)100 && outflow[s].m_weight[Index.n] > (byte)0)
        //                {
        //                    currentlength = (float)(outflow[s].m_weight[Index.n] * cumlen[s]) / 100;
        //                    cumlength += currentlength;
        //                    if (maxlength < currentlength)
        //                    {
        //                        maxlength = currentlength;
        //                    }
        //                }
        //                // 西南
        //                if (outflow[sw].m_weight[Index.ne] != OutFlow.NOOUT
        //                    && outflow[sw].m_weight[Index.ne] <= (byte)100 && outflow[sw].m_weight[Index.ne] > (byte)0)
        //                {
        //                    currentlength = (float)(outflow[sw].m_weight[Index.ne] * cumlen[sw]) / 100;
        //                    cumlength += currentlength;
        //                    if (maxlength < currentlength)
        //                    {
        //                        maxlength = currentlength;
        //                    }
        //                }
        //                if (cumlength > 0.0)
        //                {
        //                    // 这里值得探讨
        //                    //张宏鸣2010.08.13注释掉
        //                    //float cum = 0.0f;
        //                    //for (int k = 0; k < 8; ++k)
        //                    //{
        //                    //    if (outflow[c].m_weight[k] != OutFlow.NOOUT)
        //                    //    {
        //                    //        if (k % 2 == 0)
        //                    //            // 对角线方向
        //                    //            cum += (float)(diagcellStep * outflow[c].m_weight[k])/100;
        //                    //        else
        //                    //            cum += (float)(cellStep * outflow[c].m_weight[k])/100;
        //                    //    }
        //                    //}
        //                    //cumlength += inicumlen[c];
        //                    if (cumlength > maxlength)
        //                    {
        //                        cumlength = maxlength + inicumlen[c];
        //                    }
        //                    else
        //                    {
        //                        cumlength += inicumlen[c];
        //                    }
        //                    if (cumlength > cumlen[c])
        //                    {
        //                        hits++;
        //                        done = false;
        //                        cumlen[c] = cumlength;
        //                    }
        //                }// if
        //                //找到最大值
        //                //if (cumlen[c] > setmax)
        //                //{
        //                //    setmax = cumlen[c];
        //                //}
        //                //if (cumlen[c] < setmin)
        //                //{
        //                //    setmin = cumlen[c];
        //                //}
        //            }
        //        }// for
        //    }// while
        //    LogCumulativeProgress(count, hits1, hits);  
        //}

        //累积所有
        public void CalcCumulativeLength(DemData dd, OutFlow[] outflow, bool[] nd, ref float[] cumlen, float[] inicumlen)
        {
            int rows; // Number of rows.
            int cols; // Number of columns.
            int count = 0; //记录循环次数
            int hits = 0, hits1 = 0;
            int nw, n, ne, w, c, e, sw, s, se;
            bool done = false;
            float cumlength;
            //float maxlength;//用于记录周围最大坡长
            //float currentlength;//用于记录当前方向上的坡长
            double cellStep;
            double diagcellStep;

            rows = dd.imagNrows;
            cols = dd.imagNcols;
            cellStep = dd.cellStep;
            diagcellStep = (float)Math.Sqrt(2.0) * dd.cellStep;
            int fixnum = (int)(dd.imagNrows - 2) * (dd.imagNcols) / 1000;
            float[] array_fix = new float[fixnum];
            //float setmax = 0;
            double setmin = dd.cellStep;
            //float classify_num = 10;
            while (!done && count < 10000)
            {
                count++;
                done = true;
                hits = 0;
                for (int i = 2; i < rows - 2; i++)
                {
                    for (int j = 2; j < cols - 2; j++)
                    {
                        c = i * cols + j;
                        if (nd[c])
                        {
                            continue;
                        } //如果无值，跳出该次循环
                        nw = c - cols - 1;
                        n = c - cols;
                        ne = c - cols + 1;
                        w = c - 1;
                        e = c + 1;
                        sw = c + cols - 1;
                        s = c + cols;
                        se = c + cols + 1;
                        cumlength = 0.0f;

                        // 根据权值分配，然后累积
                        // 西
                        //if (i == 125)
                        //{
                        //   MessageBox.Show(j.ToString());
                        //}
                        if (outflow[w].m_weight[Index.e] != OutFlow.NOOUT
                            && outflow[w].m_weight[Index.e] <= (byte)100 && outflow[w].m_weight[Index.e] > (byte)0)
                        {
                            cumlength += ((float)(outflow[w].m_weight[Index.e] * cumlen[w])) / 100;
                        }
                        else if (outflow[w].m_weight[Index.e] > (byte)100)
                        {
                            cumlength -= ((float)((255 - outflow[w].m_weight[Index.e]) * cumlen[w])) / 100;
                        }
                        // 西北
                        if (outflow[nw].m_weight[Index.se] != OutFlow.NOOUT
                            && outflow[nw].m_weight[Index.se] <= (byte)100 && outflow[nw].m_weight[Index.se] > (byte)0)
                        {
                            cumlength += ((float)(outflow[nw].m_weight[Index.se] * cumlen[nw])) / 100;
                        }
                        else if (outflow[nw].m_weight[Index.se] > (byte)100)
                        {
                            cumlength -= ((float)((255 - outflow[nw].m_weight[Index.se]) * cumlen[nw])) / 100;
                        }
                        // 北
                        if (outflow[n].m_weight[Index.s] != OutFlow.NOOUT
                             && outflow[n].m_weight[Index.s] <= (byte)100 && outflow[n].m_weight[Index.s] > (byte)0)
                        {
                            cumlength += ((float)(outflow[n].m_weight[Index.s] * cumlen[n])) / 100;
                        }
                        else if (outflow[n].m_weight[Index.s] > (byte)100)
                        {
                            cumlength -= ((float)((255 - outflow[n].m_weight[Index.s]) * cumlen[n])) / 100;
                        }
                        // 东北
                        if (outflow[ne].m_weight[Index.sw] != OutFlow.NOOUT
                             && outflow[ne].m_weight[Index.sw] <= (byte)100 && outflow[ne].m_weight[Index.sw] > (byte)0)
                        {
                            cumlength += ((float)(outflow[ne].m_weight[Index.sw] * cumlen[ne])) / 100;
                        }
                        else if (outflow[ne].m_weight[Index.sw] > (byte)100)
                        {
                            cumlength -= ((float)((255 - outflow[ne].m_weight[Index.sw]) * cumlen[ne])) / 100;
                        }
                        // 东
                        if (outflow[e].m_weight[Index.w] != OutFlow.NOOUT
                            && outflow[e].m_weight[Index.w] <= (byte)100 && outflow[e].m_weight[Index.w] > (byte)0)
                        {
                            cumlength += (float)(outflow[e].m_weight[Index.w] * cumlen[e]) / 100;

                        }
                        else if (outflow[e].m_weight[Index.w] > (byte)100)
                        {
                            cumlength -= ((float)((255 - outflow[e].m_weight[Index.w]) * cumlen[e])) / 100;
                        }

                        // 东南
                        if (outflow[se].m_weight[Index.nw] != OutFlow.NOOUT
                            && outflow[se].m_weight[Index.nw] <= (byte)100 && outflow[se].m_weight[Index.nw] > (byte)0)
                        {
                            cumlength += (float)(outflow[se].m_weight[Index.nw] * cumlen[se]) / 100;
                        }
                        else if (outflow[se].m_weight[Index.nw] > (byte)100)
                        {
                            cumlength -= ((float)((255 - outflow[se].m_weight[Index.nw]) * cumlen[se])) / 100;
                        }
                        // 南
                        if (outflow[s].m_weight[Index.n] != OutFlow.NOOUT
                            && outflow[s].m_weight[Index.n] <= (byte)100 && outflow[s].m_weight[Index.n] > (byte)0)
                        {
                            cumlength += (float)(outflow[s].m_weight[Index.n] * cumlen[s]) / 100;
                        }
                        else if (outflow[s].m_weight[Index.n] > (byte)100)
                        {
                            cumlength -= ((float)((255 - outflow[s].m_weight[Index.n]) * cumlen[s])) / 100;
                        }
                        // 西南
                        if (outflow[sw].m_weight[Index.ne] != OutFlow.NOOUT
                            && outflow[sw].m_weight[Index.ne] <= (byte)100 && outflow[sw].m_weight[Index.ne] > (byte)0)
                        {
                            cumlength += (float)(outflow[sw].m_weight[Index.ne] * cumlen[sw]) / 100;
                        }
                        else if (outflow[sw].m_weight[Index.ne] > (byte)100)
                        {
                            cumlength -= ((float)((255 - outflow[sw].m_weight[Index.ne]) * cumlen[sw])) / 100;
                        }
                        if (cumlength > 0.0)
                        {
                            // 这里值得探讨
                            //2010.08.13删除张宏鸣
                            //float cum = 0.0f;
                            //for (int k = 0; k < 8; k++)
                            //{
                            //    if (outflow[c].m_weight[k] != OutFlow.NOOUT)
                            //    {
                            //        if (k % 2 == 0)                                  
                            //            // 对角线方向
                            //            cum += (float)(diagcellStep * outflow[c].m_weight[k])/100;                                  
                            //        else 
                            //            cum += (float)(cellStep * outflow[c].m_weight[k])/100;                                   
                            //    }
                            //}
                            cumlength += inicumlen[c];
                            if (cumlength > cumlen[c])
                            {
                                hits++;
                                done = false;
                                cumlen[c] = cumlength;
                            }

                        }
                    }
                }// for

                if (hits == hits1)
                    count = 10000;
                hits1 = hits;
                hits = 0;
                // 逆向计算
                for (int i = rows - 3; i >= 2; i--)
                {
                    // SECOND PART
                    for (int j = cols - 3; j >= 2; j--)
                    {
                        c = i * cols + j;
                        if (nd[c])
                        {
                            continue;
                        } //如果无值，跳出该次循环
                        nw = c - cols - 1;
                        n = c - cols;
                        ne = c - cols + 1;
                        w = c - 1;
                        e = c + 1;
                        sw = c + cols - 1;
                        s = c + cols;
                        se = c + cols + 1;
                        cumlength = 0.0f;
                        // 根据权值分配，然后累积
                        // 西
                        if (outflow[w].m_weight[Index.e] != OutFlow.NOOUT
                            && outflow[w].m_weight[Index.e] <= (byte)100 && outflow[w].m_weight[Index.e] > (byte)0)
                        {
                            cumlength += (float)(outflow[w].m_weight[Index.e] * cumlen[w]) / 100;
                        }
                        else if (outflow[w].m_weight[Index.e] > (byte)100)
                        {
                            cumlength -= ((float)((255 - outflow[w].m_weight[Index.e]) * cumlen[w])) / 100;
                        }
                        // 西北
                        if (outflow[nw].m_weight[Index.se] != OutFlow.NOOUT
                            && outflow[nw].m_weight[Index.se] <= (byte)100 && outflow[nw].m_weight[Index.se] > (byte)0)
                        {
                            cumlength += (float)(outflow[nw].m_weight[Index.se] * cumlen[nw]) / 100;
                        }
                        else if (outflow[nw].m_weight[Index.se] > (byte)100)
                        {
                            cumlength -= ((float)((255 - outflow[nw].m_weight[Index.se]) * cumlen[nw])) / 100;
                        }
                        // 北
                        if (outflow[n].m_weight[Index.s] != OutFlow.NOOUT
                            && outflow[n].m_weight[Index.s] <= (byte)100 && outflow[n].m_weight[Index.s] > (byte)0)
                        {
                            cumlength += (float)(outflow[n].m_weight[Index.s] * cumlen[n]) / 100;
                        }
                        else if (outflow[n].m_weight[Index.s] > (byte)100)
                        {
                            cumlength -= ((float)((255 - outflow[n].m_weight[Index.s]) * cumlen[n])) / 100;
                        }
                        // 东北
                        if (outflow[ne].m_weight[Index.sw] != OutFlow.NOOUT
                            && outflow[ne].m_weight[Index.sw] <= (byte)100 && outflow[ne].m_weight[Index.sw] > (byte)0)
                        {
                            cumlength += (float)(outflow[ne].m_weight[Index.sw] * cumlen[ne]) / 100;
                        }
                        else if (outflow[ne].m_weight[Index.sw] > (byte)100)
                        {
                            cumlength -= ((float)((255 - outflow[ne].m_weight[Index.sw]) * cumlen[ne])) / 100;
                        }
                        // 东
                        if (outflow[e].m_weight[Index.w] != OutFlow.NOOUT
                            && outflow[e].m_weight[Index.w] <= (byte)100 && outflow[e].m_weight[Index.w] > (byte)0)
                        {
                            cumlength += (float)(outflow[e].m_weight[Index.w] * cumlen[e]) / 100;
                        }
                        else if (outflow[e].m_weight[Index.w] > (byte)100)
                        {
                            cumlength -= ((float)((255 - outflow[e].m_weight[Index.w]) * cumlen[e])) / 100;
                        }
                        // 东南
                        if (outflow[se].m_weight[Index.nw] != OutFlow.NOOUT
                            && outflow[se].m_weight[Index.nw] <= (byte)100 && outflow[se].m_weight[Index.nw] > (byte)0)
                        {
                            cumlength += (float)(outflow[se].m_weight[Index.nw] * cumlen[se]) / 100;
                        }
                        else if (outflow[se].m_weight[Index.nw] > (byte)100)
                        {
                            cumlength -= ((float)((255 - outflow[se].m_weight[Index.nw]) * cumlen[se])) / 100;
                        }
                        // 南
                        if (outflow[s].m_weight[Index.n] != OutFlow.NOOUT
                            && outflow[s].m_weight[Index.n] <= (byte)100 && outflow[s].m_weight[Index.n] > (byte)0)
                        {
                            cumlength += (float)(outflow[s].m_weight[Index.n] * cumlen[s]) / 100;
                        }
                        else if (outflow[s].m_weight[Index.n] > (byte)100)
                        {
                            cumlength -= ((float)((255 - outflow[s].m_weight[Index.n]) * cumlen[s])) / 100;
                        }
                        // 西南
                        if (outflow[sw].m_weight[Index.ne] != OutFlow.NOOUT
                            && outflow[sw].m_weight[Index.ne] <= (byte)100 && outflow[sw].m_weight[Index.ne] > (byte)0)
                        {
                            cumlength += (float)(outflow[sw].m_weight[Index.ne] * cumlen[sw]) / 100;
                        }
                        else if (outflow[sw].m_weight[Index.ne] > (byte)100)
                        {
                            cumlength -= ((float)((255 - outflow[sw].m_weight[Index.ne]) * cumlen[sw])) / 100;
                        }
                        if (cumlength > 0.0)
                        {
                            cumlength += inicumlen[c];
                            if (cumlength > cumlen[c])
                            {
                                hits++;
                                done = false;
                                cumlen[c] = cumlength;
                            }
                        }
                    }
                }// for
            }// while
            LogCumulativeProgress(count, hits1, hits);
        }

        //累积最大
        public void CalcCumulativeLength(DemData dd, OutFlow[] outflow, bool[] nd, ref float[] cumlen, float[] inicumlen, float LessMax)
        {
            int rows; // Number of rows.
            int cols; // Number of columns.
            int count = 0; //记录循环次数
            int hits = 0, hits1 = 0;
            int nw, n, ne, w, c, e, sw, s, se;
            bool done = false;
            float cumlength;

            //float maxlength;//用于记录周围最大坡长
            //float currentlength;//用于记录当前方向上的坡长
            double cellStep;
            double diagcellStep;

            rows = dd.imagNrows;
            cols = dd.imagNcols;
            cellStep = dd.cellStep;
            diagcellStep = (float)Math.Sqrt(2.0) * dd.cellStep;
            int fixnum = (int)(dd.imagNrows - 2) * (dd.imagNcols) / 1000;
            float[] array_fix = new float[fixnum];
            //float setmax = 0;
            double setmin = dd.cellStep;
            //float classify_num = 10;
            while (!done && count < 10000)
            {
                count++;
                done = true;
                hits = 0;
                for (int i = 2; i < rows - 2; i++)
                {
                    for (int j = 2; j < cols - 2; j++)
                    {
                        c = i * cols + j;
                        if (nd[c])
                        {
                            continue;
                        } //如果无值，跳出该次循环
                        nw = c - cols - 1;
                        n = c - cols;
                        ne = c - cols + 1;
                        w = c - 1;
                        e = c + 1;
                        sw = c + cols - 1;
                        s = c + cols;
                        se = c + cols + 1;
                        cumlength = 0.0f;
                        LessMax = 0;//用于存储所有流入最大值
                        // 根据权值分配，然后累积
                        // 西
                        //if (i == 125)
                        //{
                        //   MessageBox.Show(j.ToString());
                        //}
                        if (outflow[w].m_weight[Index.e] != OutFlow.NOOUT
                            && outflow[w].m_weight[Index.e] <= (byte)100 && outflow[w].m_weight[Index.e] > (byte)0)
                        {

                            if (LessMax < cumlen[w])
                                LessMax = cumlen[w];
                            cumlength += ((float)(outflow[w].m_weight[Index.e] * cumlen[w])) / 100;

                        }
                        else if (outflow[w].m_weight[Index.e] > (byte)100)
                        {
                            if (LessMax < cumlen[w])
                                LessMax = cumlen[w];
                            cumlength -= ((float)((255 - outflow[w].m_weight[Index.e]) * cumlen[w])) / 100;
                        }
                        // 西北
                        if (outflow[nw].m_weight[Index.se] != OutFlow.NOOUT
                            && outflow[nw].m_weight[Index.se] <= (byte)100 && outflow[nw].m_weight[Index.se] > (byte)0)
                        {
                            if (LessMax < cumlen[nw])
                                LessMax = cumlen[nw];
                            cumlength += ((float)(outflow[nw].m_weight[Index.se] * cumlen[nw])) / 100;
                        }
                        else if (outflow[nw].m_weight[Index.se] > (byte)100)
                        {
                            if (LessMax < cumlen[nw])
                                LessMax = cumlen[nw];
                            cumlength -= ((float)((255 - outflow[nw].m_weight[Index.se]) * cumlen[nw])) / 100;
                        }
                        // 北
                        if (outflow[n].m_weight[Index.s] != OutFlow.NOOUT
                             && outflow[n].m_weight[Index.s] <= (byte)100 && outflow[n].m_weight[Index.s] > (byte)0)
                        {
                            if (LessMax < cumlen[n])
                                LessMax = cumlen[n];
                            cumlength += ((float)(outflow[n].m_weight[Index.s] * cumlen[n])) / 100;
                        }
                        else if (outflow[n].m_weight[Index.s] > (byte)100)
                        {
                            if (LessMax < cumlen[n])
                                LessMax = cumlen[n];
                            cumlength -= ((float)((255 - outflow[n].m_weight[Index.s]) * cumlen[n])) / 100;
                        }
                        // 东北
                        if (outflow[ne].m_weight[Index.sw] != OutFlow.NOOUT
                             && outflow[ne].m_weight[Index.sw] <= (byte)100 && outflow[ne].m_weight[Index.sw] > (byte)0)
                        {
                            if (LessMax < cumlen[ne])
                                LessMax = cumlen[ne];
                            cumlength += ((float)(outflow[ne].m_weight[Index.sw] * cumlen[ne])) / 100;
                        }
                        else if (outflow[ne].m_weight[Index.sw] > (byte)100)
                        {
                            if (LessMax < cumlen[ne])
                                LessMax = cumlen[ne];
                            cumlength -= ((float)((255 - outflow[ne].m_weight[Index.sw]) * cumlen[ne])) / 100;
                        }
                        // 东
                        if (outflow[e].m_weight[Index.w] != OutFlow.NOOUT
                            && outflow[e].m_weight[Index.w] <= (byte)100 && outflow[e].m_weight[Index.w] > (byte)0)
                        {
                            if (LessMax < cumlen[e])
                                LessMax = cumlen[e];
                            cumlength += (float)(outflow[e].m_weight[Index.w] * cumlen[e]) / 100;

                        }
                        else if (outflow[e].m_weight[Index.w] > (byte)100)
                        {
                            if (LessMax < cumlen[e])
                                LessMax = cumlen[e];
                            cumlength -= ((float)((255 - outflow[e].m_weight[Index.w]) * cumlen[e])) / 100;
                        }

                        // 东南
                        if (outflow[se].m_weight[Index.nw] != OutFlow.NOOUT
                            && outflow[se].m_weight[Index.nw] <= (byte)100 && outflow[se].m_weight[Index.nw] > (byte)0)
                        {
                            if (LessMax < cumlen[se])
                                LessMax = cumlen[se];
                            cumlength += (float)(outflow[se].m_weight[Index.nw] * cumlen[se]) / 100;
                        }
                        else if (outflow[se].m_weight[Index.nw] > (byte)100)
                        {
                            if (LessMax < cumlen[se])
                                LessMax = cumlen[se];
                            cumlength -= ((float)((255 - outflow[se].m_weight[Index.nw]) * cumlen[se])) / 100;
                        }
                        // 南
                        if (outflow[s].m_weight[Index.n] != OutFlow.NOOUT
                            && outflow[s].m_weight[Index.n] <= (byte)100 && outflow[s].m_weight[Index.n] > (byte)0)
                        {
                            if (LessMax < cumlen[s])
                                LessMax = cumlen[s];
                            cumlength += (float)(outflow[s].m_weight[Index.n] * cumlen[s]) / 100;
                        }
                        else if (outflow[s].m_weight[Index.n] > (byte)100)
                        {
                            if (LessMax < cumlen[s])
                                LessMax = cumlen[s];
                            cumlength -= ((float)((255 - outflow[s].m_weight[Index.n]) * cumlen[s])) / 100;
                        }
                        // 西南
                        if (outflow[sw].m_weight[Index.ne] != OutFlow.NOOUT
                            && outflow[sw].m_weight[Index.ne] <= (byte)100 && outflow[sw].m_weight[Index.ne] > (byte)0)
                        {
                            if (LessMax < cumlen[sw])
                                LessMax = cumlen[sw];
                            cumlength += (float)(outflow[sw].m_weight[Index.ne] * cumlen[sw]) / 100;
                        }
                        else if (outflow[sw].m_weight[Index.ne] > (byte)100)
                        {
                            if (LessMax < cumlen[sw])
                                LessMax = cumlen[sw];
                            cumlength -= ((float)((255 - outflow[sw].m_weight[Index.ne]) * cumlen[sw])) / 100;
                        }
                        if (cumlength > 0.0)
                        {
                            // 这里值得探讨
                            //2010.08.13删除张宏鸣
                            //float cum = 0.0f;
                            //for (int k = 0; k < 8; k++)
                            //{
                            //    if (outflow[c].m_weight[k] != OutFlow.NOOUT)
                            //    {
                            //        if (k % 2 == 0)                                  
                            //            // 对角线方向
                            //            cum += (float)(diagcellStep * outflow[c].m_weight[k])/100;                                  
                            //        else 
                            //            cum += (float)(cellStep * outflow[c].m_weight[k])/100;                                   
                            //    }
                            //}
                            if (cumlength < LessMax)
                                cumlength += inicumlen[c];
                            else
                                cumlength = LessMax + inicumlen[c];

                            if (cumlength > cumlen[c])
                            {
                                hits++;
                                done = false;
                                cumlen[c] = cumlength;
                            }

                        }
                    }
                }// for

                if (hits == hits1)
                    count = 10000;
                hits1 = hits;
                hits = 0;
                // 逆向计算
                for (int i = rows - 3; i >= 2; i--)
                {
                    // SECOND PART
                    for (int j = cols - 3; j >= 2; j--)
                    {
                        c = i * cols + j;
                        if (nd[c])
                        {
                            continue;
                        } //如果无值，跳出该次循环
                        nw = c - cols - 1;
                        n = c - cols;
                        ne = c - cols + 1;
                        w = c - 1;
                        e = c + 1;
                        sw = c + cols - 1;
                        s = c + cols;
                        se = c + cols + 1;
                        cumlength = 0.0f;
                        LessMax = 0;
                        // 根据权值分配，然后累积
                        // 西
                        if (outflow[w].m_weight[Index.e] != OutFlow.NOOUT
                            && outflow[w].m_weight[Index.e] <= (byte)100 && outflow[w].m_weight[Index.e] > (byte)0)
                        {
                            if (LessMax < cumlen[w])
                                LessMax = cumlen[w];
                            cumlength += (float)(outflow[w].m_weight[Index.e] * cumlen[w]) / 100;
                        }
                        else if (outflow[w].m_weight[Index.e] > (byte)100)
                        {
                            if (LessMax < cumlen[w])
                                LessMax = cumlen[w];
                            cumlength -= ((float)((255 - outflow[w].m_weight[Index.e]) * cumlen[w])) / 100;
                        }
                        // 西北
                        if (outflow[nw].m_weight[Index.se] != OutFlow.NOOUT
                            && outflow[nw].m_weight[Index.se] <= (byte)100 && outflow[nw].m_weight[Index.se] > (byte)0)
                        {
                            if (LessMax < cumlen[nw])
                                LessMax = cumlen[nw];
                            cumlength += (float)(outflow[nw].m_weight[Index.se] * cumlen[nw]) / 100;
                        }
                        else if (outflow[nw].m_weight[Index.se] > (byte)100)
                        {
                            if (LessMax < cumlen[nw])
                                LessMax = cumlen[nw];
                            cumlength -= ((float)((255 - outflow[nw].m_weight[Index.se]) * cumlen[nw])) / 100;
                        }
                        // 北
                        if (outflow[n].m_weight[Index.s] != OutFlow.NOOUT
                            && outflow[n].m_weight[Index.s] <= (byte)100 && outflow[n].m_weight[Index.s] > (byte)0)
                        {
                            if (LessMax < cumlen[n])
                                LessMax = cumlen[n];
                            cumlength += (float)(outflow[n].m_weight[Index.s] * cumlen[n]) / 100;
                        }
                        else if (outflow[n].m_weight[Index.s] > (byte)100)
                        {
                            if (LessMax < cumlen[n])
                                LessMax = cumlen[n];
                            cumlength -= ((float)((255 - outflow[n].m_weight[Index.s]) * cumlen[n])) / 100;
                        }
                        // 东北
                        if (outflow[ne].m_weight[Index.sw] != OutFlow.NOOUT
                            && outflow[ne].m_weight[Index.sw] <= (byte)100 && outflow[ne].m_weight[Index.sw] > (byte)0)
                        {
                            if (LessMax < cumlen[ne])
                                LessMax = cumlen[ne];
                            cumlength += (float)(outflow[ne].m_weight[Index.sw] * cumlen[ne]) / 100;
                        }
                        else if (outflow[ne].m_weight[Index.sw] > (byte)100)
                        {
                            if (LessMax < cumlen[ne])
                                LessMax = cumlen[ne];
                            cumlength -= ((float)((255 - outflow[ne].m_weight[Index.sw]) * cumlen[ne])) / 100;
                        }
                        // 东
                        if (outflow[e].m_weight[Index.w] != OutFlow.NOOUT
                            && outflow[e].m_weight[Index.w] <= (byte)100 && outflow[e].m_weight[Index.w] > (byte)0)
                        {
                            if (LessMax < cumlen[e])
                                LessMax = cumlen[e];
                            cumlength += (float)(outflow[e].m_weight[Index.w] * cumlen[e]) / 100;
                        }
                        else if (outflow[e].m_weight[Index.w] > (byte)100)
                        {
                            if (LessMax < cumlen[e])
                                LessMax = cumlen[e];
                            cumlength -= ((float)((255 - outflow[e].m_weight[Index.w]) * cumlen[e])) / 100;
                        }
                        // 东南
                        if (outflow[se].m_weight[Index.nw] != OutFlow.NOOUT
                            && outflow[se].m_weight[Index.nw] <= (byte)100 && outflow[se].m_weight[Index.nw] > (byte)0)
                        {
                            if (LessMax < cumlen[se])
                                LessMax = cumlen[se];
                            cumlength += (float)(outflow[se].m_weight[Index.nw] * cumlen[se]) / 100;
                        }
                        else if (outflow[se].m_weight[Index.nw] > (byte)100)
                        {
                            if (LessMax < cumlen[se])
                                LessMax = cumlen[se];
                            cumlength -= ((float)((255 - outflow[se].m_weight[Index.nw]) * cumlen[se])) / 100;
                        }
                        // 南
                        if (outflow[s].m_weight[Index.n] != OutFlow.NOOUT
                            && outflow[s].m_weight[Index.n] <= (byte)100 && outflow[s].m_weight[Index.n] > (byte)0)
                        {
                            if (LessMax < cumlen[s])
                                LessMax = cumlen[s];
                            cumlength += (float)(outflow[s].m_weight[Index.n] * cumlen[s]) / 100;
                        }
                        else if (outflow[s].m_weight[Index.n] > (byte)100)
                        {
                            if (LessMax < cumlen[s])
                                LessMax = cumlen[s];
                            cumlength -= ((float)((255 - outflow[s].m_weight[Index.n]) * cumlen[s])) / 100;
                        }
                        // 西南
                        if (outflow[sw].m_weight[Index.ne] != OutFlow.NOOUT
                            && outflow[sw].m_weight[Index.ne] <= (byte)100 && outflow[sw].m_weight[Index.ne] > (byte)0)
                        {
                            if (LessMax < cumlen[sw])
                                LessMax = cumlen[sw];
                            cumlength += (float)(outflow[sw].m_weight[Index.ne] * cumlen[sw]) / 100;
                        }
                        else if (outflow[sw].m_weight[Index.ne] > (byte)100)
                        {
                            if (LessMax < cumlen[sw])
                                LessMax = cumlen[sw];
                            cumlength -= ((float)((255 - outflow[sw].m_weight[Index.ne]) * cumlen[sw])) / 100;
                        }
                        if (cumlength > 0.0)
                        {
                            if (cumlength < LessMax)
                                cumlength += inicumlen[c];
                            else
                                cumlength = LessMax + inicumlen[c];
                            if (cumlength > cumlen[c])
                            {
                                hits++;
                                done = false;
                                cumlen[c] = cumlength;
                            }
                        }
                    }
                }// for
            }// while
            LogCumulativeProgress(count, hits1, hits);
        }
        #endregion
        #region

        ////累积周围平均坡长算法
        //public void CalcCumulativeLength_New(DemData dd, byte[] outflow, bool[] nd, bool[] breakflow, float[] cumlen)
        //{
        //    try
        //    {
        //        int rows; /*Number of rows.*/
        //        int cols; /*Number of columns.*/
        //        int count_while = 0; //记录循环次数
        //        int hits, hits1 = 0;
        //        int nw, n, ne, w, c, e, sw, s, se, count;
        //        bool done = false;
        //        float cumlength;
        //        float diagcellStep;
        //        string outflow_array;

        //        rows = dd.imagNrows;
        //        cols = dd.imagNcols;

        //        diagcellStep = (float)Math.Sqrt(2.0) * dd.cellStep;
        //        while (!done && count_while < 10000)
        //        {
        //            count_while++;
        //            done = true;
        //            hits = 0;
        //            for (int i = 2; i < rows - 2; i++)
        //            {
        //                for (int j = 2; j < cols - 2; j++)
        //                {
        //                    c = i * cols + j;
        //                    if (nd[c])
        //                    {
        //                        continue;
        //                    } //如果无值，跳出该次循环

        //                    cumlength = (float)0.0; // 累计坡长为0.0
        //                    count = 0;
        //                    outflow_array = "";

        //                    nw = c - cols - 1;
        //                    n = c - cols;
        //                    ne = c - cols + 1;
        //                    w = c - 1;
        //                    e = c + 1;
        //                    sw = c + cols - 1;
        //                    s = c + cols;
        //                    se = c + cols + 1;

        //                    //西
        //                    if (outflow[w] == GlobalConstants.E && !breakflow[w] && cumlen[w] > cumlength)
        //                    {
        //                        //cumlength = cumlen[w];
        //                        outflow_array = outflow_array + "w";
        //                        count++;
        //                    }
        //                    //西北
        //                    if (outflow[nw] == GlobalConstants.SE && !breakflow[nw] && cumlen[nw] > cumlength)
        //                    {
        //                        //cumlength = cumlen[nw];
        //                        if(outflow_array.Length>0)
        //                            outflow_array = outflow_array + ",nw";
        //                        else
        //                            outflow_array = outflow_array + "nw";
        //                        count++;
        //                    }
        //                    //北                          
        //                    if (outflow[n] == GlobalConstants.S && !breakflow[n] && cumlen[n] > cumlength)
        //                    {
        //                        //cumlength = cumlen[n];
        //                        if (outflow_array.Length > 0)
        //                            outflow_array = outflow_array + ",n";
        //                        else
        //                            outflow_array = outflow_array + "n";
        //                        count++;
        //                    }
        //                    //东北
        //                    if (outflow[ne] == GlobalConstants.SW && !breakflow[ne] && cumlen[ne] > cumlength)
        //                    {
        //                        //cumlength = cumlen[ne];
        //                        if (outflow_array.Length > 0)
        //                            outflow_array = outflow_array + ",ne";
        //                        else
        //                            outflow_array = outflow_array + "ne";
        //                        count++;
        //                    }
        //                    //东
        //                    if (outflow[e] == GlobalConstants.W && !breakflow[e] && cumlen[e] > cumlength)
        //                    {
        //                        //cumlength = cumlen[e];
        //                        if (outflow_array.Length > 0)
        //                            outflow_array = outflow_array + ",e";
        //                        else
        //                            outflow_array = outflow_array + "e";
        //                        count++;
        //                    }
        //                    //东南
        //                    if (outflow[se] == GlobalConstants.NW && !breakflow[se] && cumlen[se] > cumlength)
        //                    {
        //                        //cumlength = cumlen[se];
        //                        if (outflow_array.Length > 0)
        //                            outflow_array = outflow_array + ",se";
        //                        else
        //                            outflow_array = outflow_array + "se";
        //                        count++;
        //                    }
        //                    //南
        //                    if (outflow[s] == GlobalConstants.N && !breakflow[s] && cumlen[s] > cumlength)
        //                    {
        //                        //cumlength = cumlen[s];
        //                        if (outflow_array.Length > 0)
        //                            outflow_array = outflow_array + ",s";
        //                        else
        //                            outflow_array = outflow_array + "s";
        //                        count++;
        //                    }
        //                    //西南
        //                    if (outflow[sw] == GlobalConstants.NE && !breakflow[sw] && cumlen[sw] > cumlength)
        //                    {
        //                        //cumlength = cumlen[sw];
        //                        if (outflow_array.Length > 0)
        //                        outflow_array = outflow_array + ",sw";
        //                        else
        //                        outflow_array = outflow_array + "sw";
        //                        count++;
        //                    }
        //                    if (outflow_array.Length > 0)
        //                    {
        //                        string[] cumlength_array = outflow_array.Split(',');
        //                        for (int x = 0; x < cumlength_array.Length; x++)
        //                        {
        //                            if (cumlength_array[x] == "w")
        //                                cumlength += cumlen[w];
        //                            else if (cumlength_array[x] == "nw")
        //                                cumlength += cumlen[nw];
        //                            else if (cumlength_array[x] == "e")
        //                                cumlength += cumlen[w];
        //                            else if (cumlength_array[x] == "ne")
        //                                cumlength += cumlen[w];
        //                            else if (cumlength_array[x] == "e")
        //                                cumlength += cumlen[w];
        //                            else if (cumlength_array[x] == "se")
        //                                cumlength += cumlen[w];
        //                            else if (cumlength_array[x] == "s")
        //                                cumlength += cumlen[w];
        //                            else if (cumlength_array[x] == "sw")
        //                                cumlength += cumlen[w];
        //                            if (count != 0)
        //                                cumlength = cumlength / count;
        //                        }
        //                    }
        //                    if (cumlength > 0.0)
        //                    {
        //                        if (outflow[c] == GlobalConstants.N || outflow[c] == GlobalConstants.E || outflow[c] == GlobalConstants.S ||
        //                            outflow[c] == GlobalConstants.W)
        //                            cumlength += dd.cellStep;
        //                        else if (outflow[c] == GlobalConstants.NE || outflow[c] == GlobalConstants.NW || outflow[c] == GlobalConstants.SE ||
        //                                 outflow[c] == GlobalConstants.SW)
        //                            cumlength += diagcellStep;
        //                        if (cumlength > cumlen[c])
        //                        {
        //                            hits++;
        //                            done = false;
        //                            cumlen[c] = cumlength;
        //                        }
        //                    }
        //                } // END for(i = 0; i < rows; i++) FIRST PART
        //            } // END for(j = 0; j < cols, j++)	  FIRST PART

        //            if (hits == hits1)
        //                count = 10000;

        //            hits1 = hits;
        //            hits = 0;
        //            //为什么要反方向重新计算呢？
        //            for (int i = rows - 3; i >= 2; i--)
        //            {
        //                // SECOND PART
        //                for (int j = cols - 3; j >= 2; j--)
        //                {
        //                    // SECOND PART
        //                    c = i * cols + j;
        //                    if (nd[c])
        //                    {
        //                        continue;
        //                    }
        //                    cumlength = (float)0.0;
        //                    outflow_array = "";
        //                    count = 0;

        //                    nw = c - cols - 1;
        //                    n = c - cols;
        //                    ne = c - cols + 1;
        //                    w = c - 1;
        //                    e = c + 1;
        //                    sw = c + cols - 1;
        //                    s = c + cols;
        //                    se = c + cols + 1;
        //                    //西北
        //                    if (outflow[nw] == GlobalConstants.SE && !breakflow[nw] && cumlen[nw] > cumlength)
        //                    {
        //                        //cumlength = cumlen[nw];
        //                        outflow_array = outflow_array + "nw";
        //                        count++;
        //                    }//北
        //                    if (outflow[n] == GlobalConstants.S && !breakflow[n] && cumlen[n] > cumlength)
        //                    {
        //                        //cumlength = cumlen[n];
        //                        if (outflow_array.Length > 0)
        //                        outflow_array = outflow_array + ",n";
        //                        else
        //                        outflow_array = outflow_array + "n";
        //                        count++;
        //                    }//东北
        //                    if (outflow[ne] == GlobalConstants.SW && !breakflow[ne] && cumlen[ne] > cumlength)
        //                    {
        //                        //cumlength = cumlen[ne];
        //                        if (outflow_array.Length > 0)
        //                        outflow_array = outflow_array + ",ne";
        //                        else
        //                        outflow_array = outflow_array + "ne";
        //                        count++;
        //                    }//西
        //                    if (outflow[w] == GlobalConstants.E && !breakflow[w] && cumlen[w] > cumlength)
        //                    {
        //                        //cumlength = cumlen[w];
        //                        if (outflow_array.Length > 0)
        //                        outflow_array = outflow_array + ",w";
        //                        else
        //                        outflow_array = outflow_array + "w";
        //                        count++;
        //                    } //东
        //                    if (outflow[e] == GlobalConstants.W && !breakflow[e] && cumlen[e] > cumlength)
        //                    {
        //                        //cumlength = cumlen[e];
        //                        if (outflow_array.Length > 0)
        //                        outflow_array = outflow_array + ",e";
        //                        else
        //                        outflow_array = outflow_array + "e";
        //                        count++;
        //                    }//西南
        //                    if (outflow[sw] == GlobalConstants.NE && !breakflow[sw] && cumlen[sw] > cumlength)
        //                    {
        //                        //cumlength = cumlen[sw];
        //                        if (outflow_array.Length > 0)
        //                        outflow_array = outflow_array + ",sw";
        //                        else
        //                        outflow_array = outflow_array + "sw";
        //                        count++;
        //                    }//南
        //                    if (outflow[s] == GlobalConstants.N && !breakflow[s] && cumlen[s] > cumlength)
        //                    {
        //                        //cumlength = cumlen[s];
        //                        if (outflow_array.Length > 0)
        //                         outflow_array = outflow_array + ",s";
        //                        else
        //                         outflow_array = outflow_array + "s";
        //                        count++;
        //                    }//东南
        //                    if (outflow[se] == GlobalConstants.NW && !breakflow[se] && cumlen[se] > cumlength)
        //                    {
        //                        //cumlength = cumlen[se];
        //                        if (outflow_array.Length > 0)
        //                            outflow_array = outflow_array + ",se";
        //                        else
        //                            outflow_array = outflow_array + "se";
        //                        count++;
        //                    }
        //                    if (outflow_array.Length > 0)
        //                    {
        //                        string[] cumlength_array = outflow_array.Split(',');
        //                        for (int x = 0; x < cumlength_array.Length; x++)
        //                        {
        //                            if (cumlength_array[x] == "w")
        //                                cumlength += cumlen[w];
        //                            else if (cumlength_array[x] == "nw")
        //                                cumlength += cumlen[nw];
        //                            else if (cumlength_array[x] == "e")
        //                                cumlength += cumlen[w];
        //                            else if (cumlength_array[x] == "ne")
        //                                cumlength += cumlen[w];
        //                            else if (cumlength_array[x] == "e")
        //                                cumlength += cumlen[w];
        //                            else if (cumlength_array[x] == "se")
        //                                cumlength += cumlen[w];
        //                            else if (cumlength_array[x] == "s")
        //                                cumlength += cumlen[w];
        //                            else if (cumlength_array[x] == "sw")
        //                                cumlength += cumlen[w];
        //                            if (count != 0)
        //                                cumlength = cumlength / count;
        //                        }
        //                    }
        //                    if (cumlength > 0.0)
        //                    {
        //                        if (outflow[c] == GlobalConstants.N || outflow[c] == GlobalConstants.E || outflow[c] == GlobalConstants.S ||
        //                            outflow[c] == GlobalConstants.W)
        //                            cumlength += dd.cellStep;
        //                        else if (outflow[c] == GlobalConstants.NE || outflow[c] == GlobalConstants.NW || outflow[c] == GlobalConstants.SE ||
        //                                 outflow[c] == GlobalConstants.SW)
        //                            cumlength += diagcellStep;
        //                        if (cumlength > cumlen[c])
        //                        {
        //                            done = false;
        //                            hits++;
        //                            cumlen[c] = cumlength;
        //                        }
        //                    }
        //                } // END for(i = 0; i < rows; i++)  SECOND PART
        //            } // END for(j = 0; j < cols, j++)  SECOND PART
        //            LogCumulativeProgress(count_while, hits1, hits);
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        // 
        //        MessageBox.Show(ex.ToString());
        //    }

        //}
        //public void ConvertLengthToFeet(DemData dd, float[] slp_len_cum, float[] slp_lgth_ft)
        //{
        //    int i; /*Loop Counter.*/
        //    int j; /*Loop Counter.*/
        //    int c;
        //    int rows; /*Number of rows.*/
        //    int cols; /*Number of columns.*/
        //    /*张杰的修改*/
        //    rows = dd.imagNrows;
        //    cols = dd.imagNcols;

        //    for (i = 2; i < rows - 2; i++)
        //    {
        //        for (j = 2; j < cols - 2; j++)
        //        {
        //            c = i * cols + j;
        //            slp_lgth_ft[c] = slp_len_cum[c] / (float)0.3048;
        //        }
        //    }
        //}
        public void Calculate_L(DemData dd, float[] slopeAng, float[] slp_lgth_ft, float[] ruslel,int rusle_csle)
        {
            int i; /*Loop Counter.*/
            int j; /*Loop Counter.*/
            int c;
            int rows; /*Number of rows.*/
            int cols; /*Number of columns.*/
            rows = dd.imagNrows;
            cols = dd.imagNcols;
            if (rusle_csle == 1)
                for (i = 2; i < rows - 2; i++)
                {
                    for (j = 2; j < cols - 2; j++)
                    {
                        c = i * cols + j;
                        ruslel[c] = (float)Math.Pow(slp_lgth_ft[c] / (float)22.1, TableLookUp_csle(slopeAng[c])); //x的y次幂
                    }
                }
            else
                for (i = 2; i < rows - 2; i++)
                {
                    for (j = 2; j < cols - 2; j++)
                    {
                        c = i * cols + j;
                        ruslel[c] = (float)Math.Pow(slp_lgth_ft[c] / (float)22.1, TableLookUp_rusle(slopeAng[c])); //x的y次幂
                    }
                }
        }
        public void Calculate_CLSE_L_Feet(DemData dd, float[] slopeAng, float[] slp_lgth_ft, float[] ruslel)
        {
            int i; /*Loop Counter.*/
            int j; /*Loop Counter.*/
            int c;
            int rows; /*Number of rows.*/
            int cols; /*Number of columns.*/
            rows = dd.imagNrows;
            cols = dd.imagNcols;
            for (i = 2; i < rows - 2; i++)
            {
                for (j = 2; j < cols - 2; j++)
                {
                    c = i * cols + j;
                    ruslel[c] = (float)Math.Pow(slp_lgth_ft[c] / (float)72.6, TableLookUp_csle(slopeAng[c])); //x的y次幂
                } // END for(i = 0; i < rows; i++) 
            } // END for(j = 0; j < cols, j++)  
        }
        public void Calculate_S(DemData dd, float[] downSlpAng, float[] rusles,int rusle_csle)
        {
            int i; //	Loop Counter
            int j; //	Loop Counter
            int c;
            int rows; //	Number of rows
            int cols; //	Number of columns
            float deg;
            deg = (float)57.2958; //	ASK RICK
            rows = dd.imagNrows;
            cols = dd.imagNcols;
            if (rusle_csle == 1)
                for (i = 2; i < rows - 2; i++)
                {
                    for (j = 2; j < cols - 2; j++)
                    {
                        c = i * cols + j;
                        if (downSlpAng[c] >= 10)
                            rusles[c] = (float)(21.9 * (Math.Sin(downSlpAng[c] / deg)) - (float)0.96);
                        else if (downSlpAng[c] >= 5)
                            rusles[c] = (float)(16.8 * (Math.Sin(downSlpAng[c] / deg)) - (float)0.50);
                        else
                            rusles[c] = (float)(10.8 * (Math.Sin(downSlpAng[c] / deg)) + (float)0.03);
                    }
                }
            else
                for (i = 2; i < rows - 2; i++)
                {
                    for (j = 2; j < cols - 2; j++)
                    {
                        c = i * cols + j;
                        if (downSlpAng[c] >= 5.1428)
                            rusles[c] = (float)(16.8 * (Math.Sin(downSlpAng[c] / deg)) - (float)0.50);
                        else
                            rusles[c] = (float)(10.8 * (Math.Sin(downSlpAng[c] / deg)) + (float)0.03);
                    }
                }
        }
        //没有修改为Rusle的公式
        //public void Calculate_RUSLE_S(DemData dd, float[] downSlpAng, float[] rusles)
        //{
        //    int i; //	Loop Counter
        //    int j; //	Loop Counter
        //    int c;
        //    int rows; //	Number of rows
        //    int cols; //	Number of columns
        //    float deg;
        //    deg = (float)57.2958; //	ASK RICK
        //    rows = dd.imagNrows;
        //    cols = dd.imagNcols;
        //    for (i = 2; i < rows - 2; i++)
        //    {
        //        for (j = 2; j < cols - 2; j++)
        //        {
        //            c = i * cols + j;
        //            if (downSlpAng[c] >= 14.04)
        //                rusles[c] = (float)(21.91 * (Math.Sin(downSlpAng[c] / deg)) - (float)0.96);
        //            else if (downSlpAng[c] >= 5)
        //                rusles[c] = (float)(16.8 * (Math.Sin(downSlpAng[c] / deg)) - (float)0.50);
        //            else
        //                rusles[c] = (float)(10.8 * (Math.Sin(downSlpAng[c] / deg)) + (float)0.03);

        //        } // END for(i = 0; i < rows; i++) 
        //    } // END for(j = 0; j < cols, j++)  
        //}
        public void Calculate_CSLE_LS2(DemData dd, float[] ruslel, float[] rusles, float[] ruslels2)
        {
            int i; /*Loop Counter.*/
            int j; /*Loop Counter.*/
            int c;
            int rows; /*Number of rows.*/
            int cols; /*Number of columns.*/
            rows = dd.imagNrows;
            cols = dd.imagNcols;
            for (i = 2; i < rows - 2; i++)
            {
                for (j = 2; j < cols - 2; j++)
                {
                    c = i * cols + j;
                    //ruslels2[c] = (float)((int)(ruslel[c] * rusles[c] * 100 + 0.5));
                    //ruslels2[c] = (float)((int)(ruslel[c] * rusles[c] * 100 + 0.5)/100);
                    ruslels2[c] = ruslel[c] * rusles[c];
                }
            }
        }
        #endregion

        //##############################################



        //                    CalcLib



        //##############################################

        #region CalcLib

        public float TableLookUp_csle(float v)//CLSE
        {
            double temp = 0.56;

            if (v <= 1)
                temp = 0.2;
            else if (v < 3)
                temp = 0.3;
            else if (v < 5)
                temp = 0.4;
            else
                temp = 0.5;
            return (float)temp;
        }
        public float TableLookUp_rusle(float v)//RUSEL
        {
            double temp = 0.56;

            if (v <= 0.101)
                temp = 0.01;
            else if (v < 0.2)
                temp = 0.02;
            else if (v < 0.4)
                temp = 0.04;
            else if (v < 0.85)
                temp = 0.08;
            else if (v < 1.4)
                temp = 0.14;
            else if (v < 2.0)
                temp = 0.18;
            else if (v < 2.6)
                temp = 0.22;
            else if (v < 3.1)
                temp = 0.25;
            else if (v < 3.7)
                temp = 0.28;
            else if (v < 5.2)
                temp = 0.32;
            else if (v < 6.3)
                temp = 0.35;
            else if (v < 7.4)
                temp = 0.37;
            else if (v < 8.6)
                temp = 0.40;
            else if (v < 10.3)
                temp = 0.41;
            else if (v < 12.9)
                temp = 0.44;
            else if (v < 15.7)
                temp = 0.47;
            else if (v < 20.0)
                temp = 0.49;
            else if (v < 25.8)
                temp = 0.52;
            else if (v < 31.5)
                temp = 0.54;
            else if (v < 37.2)
                temp = 0.55;
            return (float)temp;
        }

        #endregion

        public void FreeMemory()
        {
            GC.Collect();
            GC.WaitForPendingFinalizers();
            GC.Collect();
        }
    }
}